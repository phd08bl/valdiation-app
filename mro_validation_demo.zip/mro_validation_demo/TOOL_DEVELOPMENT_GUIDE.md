# Tool Development Guide (End-to-End)

This guide explains how to implement a new validation tool and plug it into the demo.
It assumes the repo layout under `mro_validation_demo/`.

## 1) Create the tool folder and file

1. Choose a unique tool ID, e.g. `answer_relevance`.
2. Create the folder: `mro_validation_demo/tools/<tool_id>/`.
3. Copy the template:
   - From: `mro_validation_demo/tool_templates/tool_template.py`
   - To: `mro_validation_demo/tools/<tool_id>/tool.py`
4. Replace placeholders in the new file:
   - `tool_id`, `name`, `version`, `description`, `module_group`
   - `metadata()` (owner/status/tags/limitations)
   - `default_config()` and `config_schema()` as needed
   - `run_one(...)` evaluation logic

## 2) Implement the tool contract correctly

Every tool must:
- Export a module-level `TOOL` variable (instance of `BaseTool`).
- Implement `default_config()` and `run_one(...)`.
- Return `ToolResult` with:
  - `tool_id`, `overall_score` (float), `pass_fail` ("PASS" or "FAIL")
  - Optional `metrics` and `evidence` (list of `EvidenceItem`).

Reference contract: `mro_validation_demo/mro_validation_sdk/base.py`.

## 3) Use the correct record fields

The dataset records are loaded from `mro_validation_demo/data/dataset.jsonl`.
Each record is a JSON object with fields like:
- `id`, `input`, `answer`, `context`, `expected`

Your `run_one(...)` should read from these fields (do not mutate `record`).

## 4) Add the tool to the UI module groups

Add the new tool ID into the correct group in:
- `mro_validation_demo/app.py` -> `MODULE_GROUPS_ALL`

If the tool ID is not listed there, it will not show in the UI filter lists.

## 5) Coverage and access modes (recommended)

If the tool requires deeper access:
- Implement `coverage_status(system_type, access_mode)` and return:
  - `available`, `limited`, or `unavailable`
- Optionally add `coverage_notes(...)` for user-facing guidance.

## 6) Config schema (recommended)

`config_schema()` drives the UI fields in the Tool Workbench.
If omitted, the UI will auto-generate fields from your config dict,
but you will lose labels and field types.

## 7) Validate and smoke test

In the UI:
1. Open "3) Tool Workbench".
2. Select your tool and click "Load tool + presets".
3. Set config values and "Save preset".
4. Run "Smoke Test (3 samples)".

This verifies that:
- The tool loads
- Config schema renders
- `run_one(...)` executes without errors

## 8) Common failure points to avoid

- Missing `TOOL` export (tool not discoverable).
- `tool_id` mismatch between class and `ToolResult`.
- Non-numeric `overall_score` or missing PASS/FAIL.
- Tool ID not added to `MODULE_GROUPS_ALL`.
- Exceptions in `run_one(...)` that stop suite runs.

## 9) Checklist

Use: `mro_validation_demo/TOOLS_CHECKLIST.md` to track ownership and status.

## 10) Optional testing approach

If you want a quick local test without UI:
- Run a suite using the runner functions in `mro_validation_demo/core/runner.py`.
  (Example: `run_tool_standalone(...)` with a small record limit.)

