﻿from __future__ import annotations

from typing import Any, Dict

from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext
from mro_validation_sdk.record_utils import get_input_text, get_output_text, get_context_text


class ExampleTool(BaseTool):
    tool_id = "tool_id_here"
    name = "Human readable tool name"
    version = "0.1"
    description = "One-line description of what this tool evaluates."
    module_group = "Quality, Correctness & Effectiveness"

    def metadata(self) -> Dict[str, Any]:
        return {
            "owner": "Team/Owner",
            "status": "Experimental",  # Draft/Experimental/Approved/Deprecated
            "tags": ["judge", "demo"],
            "limitations": "Known limitations and scope.",
        }

    def default_config(self) -> Dict[str, Any]:
        return {
            "threshold": 0.7,
            "strict_mode": False,
            "notes": "",
        }

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "threshold", "type": "number", "label": "Pass threshold", "min": 0, "max": 1, "step": 0.05},
                {"key": "strict_mode", "type": "bool", "label": "Strict mode"},
                {"key": "notes", "type": "text", "label": "Notes", "lines": 2},
            ]
        }

    def validate_config(self, cfg: Dict[str, Any]):
        # Optional: return (is_valid, message)
        return True, "ok"

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        if access_mode == "blackbox_api":
            return "limited"
        return "available"

    def coverage_notes(self, system_type: str, access_mode: str) -> str:
        if access_mode == "blackbox_api":
            return "Limited without deeper access."
        return ""

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        # Replace this logic with the real evaluation.
        # Use record_utils helpers for backward-compatible access to fields.
        _input = get_input_text(record)
        _output = get_output_text(record)
        _context = get_context_text(record)
        score = 0.0
        passed = False
        metrics = {"score": score}
        evidence = [EvidenceItem(kind="score", title="Score", payload=metrics)]
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=score,
            pass_fail="PASS" if passed else "FAIL",
            metrics=metrics,
            evidence=evidence,
        )


TOOL: BaseTool = ExampleTool()
