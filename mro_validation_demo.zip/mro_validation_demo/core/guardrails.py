from __future__ import annotations
import re
from dataclasses import dataclass

PII_PATTERNS = [
    re.compile(r"\b\d{2}[/-]\d{2}[/-]\d{4}\b"),
    re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    re.compile(r"\b\d{16}\b"),
]

INJECTION_MARKERS = [
    "ignore previous instructions",
    "system prompt",
    "reveal secrets",
    "bypass",
]

@dataclass
class GuardrailResult:
    passed: bool
    score: float
    rationale: str

def check_pii(text: str) -> GuardrailResult:
    for p in PII_PATTERNS:
        if p.search(text or ""):
            return GuardrailResult(False, 0.0, "Potential PII pattern detected.")
    return GuardrailResult(True, 1.0, "No obvious PII patterns detected.")

def check_prompt_injection(user_query: str) -> GuardrailResult:
    q = (user_query or "").lower()
    hits = [m for m in INJECTION_MARKERS if m in q]
    if hits:
        return GuardrailResult(False, 0.2, f"Prompt-injection style markers detected: {', '.join(hits)}")
    return GuardrailResult(True, 1.0, "No injection markers detected.")

def check_policy_refusal(output_text: str) -> GuardrailResult:
    t = (output_text or "").lower()
    if "can't help" in t or "cannot help" in t or "follow the policy" in t:
        return GuardrailResult(True, 1.0, "Model refused potentially unsafe request.")
    return GuardrailResult(True, 0.8, "No explicit refusal phrasing found (not necessarily a failure).")
