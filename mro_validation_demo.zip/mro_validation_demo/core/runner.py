from __future__ import annotations

import json
from dataclasses import asdict
from typing import Any, Dict, List, Optional

from mro_validation_sdk import ToolContext
from mro_validation_sdk.base import ToolResult

from core.discovery import discover_tools as _discover_tools
from core.store import (
    upsert_run,
    upsert_trace,
    add_evaluation,
    get_active_tool_preset_config,
    get_tool_config,
)

# Registry
_DISCOVERY = _discover_tools("tools")
TOOL_REGISTRY_OBJ = _DISCOVERY.tools
TOOL_LOAD_ERRORS = _DISCOVERY.errors
TOOL_REGISTRY = {tid: getattr(t, "description", "") for tid, t in TOOL_REGISTRY_OBJ.items()}


def list_runs(project_id: str, db_path: str):
    from core.store import list_runs as _list
    return _list(project_id, db_path=db_path)


def list_traces_for_run(run_id: str, db_path: str):
    from core.store import list_traces_for_run as _list
    return _list(run_id, db_path=db_path)


def get_trace(trace_id: str, db_path: str):
    from core.store import get_trace as _get
    return _get(trace_id, db_path=db_path)


def discover_available_tools(path: str = "tools"):
    """Compatibility wrapper for UI code that wants to refresh tool discovery."""
    d = _discover_tools(path)
    return d.tools, d.errors


# Name used by app.py (kept for backwards compatibility)
def discover_tools(path: str = "tools"):
    return discover_available_tools(path)


def _load_dataset(dataset_path: str) -> List[dict]:
    rows = []
    with open(dataset_path, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def _resolve_tool_config(project_id: str, tool_id: str, db_path: str, use_saved_presets: bool) -> Dict[str, Any]:
    if use_saved_presets:
        cfg = get_active_tool_preset_config(project_id, tool_id, db_path=db_path)
        if cfg:
            return cfg
    cfg = get_tool_config(project_id, tool_id, db_path=db_path)
    if cfg:
        return cfg
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    return tool.default_config() if tool and hasattr(tool, "default_config") else {}


def run_tool_standalone(
    *,
    project_id: str,
    dataset_path: str,
    db_path: str,
    system_type: str,
    access_mode: str,
    api_base_url: Optional[str],
    tool_id: str,
    limit_records: int = 3,
    override_tool_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return run_suite(
        project_id=project_id,
        dataset_path=dataset_path,
        db_path=db_path,
        system_type=system_type,
        access_mode=access_mode,
        api_base_url=api_base_url,
        selected_tools=[tool_id],
        use_saved_presets=False,
        override_tool_configs={tool_id: (override_tool_config or {})},
        run_mode="tool_standalone",
        limit_records=limit_records,
    )


def run_suite(
    *,
    project_id: str,
    dataset_path: str,
    db_path: str,
    system_type: str,
    access_mode: str,
    api_base_url: Optional[str],
    selected_tools: List[str],
    use_saved_presets: bool = True,
    override_tool_configs: Optional[Dict[str, Dict[str, Any]]] = None,
    run_mode: str = "suite",
    limit_records: Optional[int] = None,
) -> Dict[str, Any]:
    override_tool_configs = override_tool_configs or {}

    dataset = _load_dataset(dataset_path)
    if limit_records is not None:
        dataset = dataset[: max(0, int(limit_records))]

    # snapshot configs for evidence
    tool_configs_snapshot: Dict[str, Dict[str, Any]] = {}
    for tid in selected_tools:
        if tid in override_tool_configs:
            tool_configs_snapshot[tid] = override_tool_configs[tid] or {}
        else:
            tool_configs_snapshot[tid] = _resolve_tool_config(project_id, tid, db_path, use_saved_presets)

    # deterministic-ish run id from metadata
    run_id = f"run_{abs(hash(json.dumps({'p':project_id,'sys':system_type,'am':access_mode,'tools':selected_tools,'mode':run_mode,'cfg':tool_configs_snapshot}, sort_keys=True))) % (10**10)}"

    tool_status = {tid: "pending" for tid in selected_tools}
    tool_errors: Dict[str, str] = {}
    run_log: List[str] = []

    run_meta = {
        "system_type": system_type,
        "access_mode": access_mode,
        "api_base_url": api_base_url,
        "selected_tools": selected_tools,
        "run_mode": run_mode,
        "limit_records": limit_records,
        "use_saved_presets": use_saved_presets,
        "tool_configs_snapshot": tool_configs_snapshot,
        "tool_status": tool_status,
        "tool_errors": tool_errors,
        "records_total": len(dataset),
        "records_processed": 0,
        "run_log": run_log,
    }
    upsert_run(project_id=project_id, run_id=run_id, status="running", pass_rate=0.0, total=0, run_metadata=run_meta, db_path=db_path)

    ctx = ToolContext(project_id=project_id, system_type=system_type, access_mode=access_mode, api_base_url=api_base_url, db_path=db_path)

    total = 0
    pass_count = 0

    for rec in dataset:
        trace_id = f"trace_{run_id}_{rec.get('id', total)}"
        trace_payload = {
            "record": rec,
            "spans": [],
            "evaluations": [],
        }
        # Create the trace row before evaluations so FK constraints pass.
        upsert_trace(
            run_id=run_id,
            trace_id=trace_id,
            input_preview=str(rec.get("input", ""))[:200],
            overall_score=0.0,
            pass_fail="PENDING",
            trace_json=trace_payload,
            db_path=db_path,
        )

        record_scores = []
        record_pass = True

        for tool_id in selected_tools:
            tool = TOOL_REGISTRY_OBJ.get(tool_id)
            if tool is None:
                continue
            if tool_status.get(tool_id) == "pending":
                tool_status[tool_id] = "running"
                run_log.append(f"Started tool {tool_id}")

            cfg = tool_configs_snapshot.get(tool_id, {})
            try:
                res: ToolResult = tool.run_one(rec, cfg, ctx)
            except Exception as exc:
                tool_status[tool_id] = "error"
                tool_errors[tool_id] = str(exc)
                run_log.append(f"Tool {tool_id} failed: {exc}")
                record_pass = False
                continue

            trace_payload["evaluations"].append({
                "tool_id": res.tool_id,
                "pass_fail": res.pass_fail,
                "overall_score": res.overall_score,
                "metrics": res.metrics,
                "evidence": [asdict(e) for e in res.evidence],
            })

            # store evaluation row
            add_evaluation(trace_id=trace_id, tool_id=res.tool_id, evaluation_json={
                "pass_fail": res.pass_fail,
                "overall_score": res.overall_score,
                "metrics": res.metrics,
                "evidence": [asdict(e) for e in res.evidence],
            }, db_path=db_path)

            record_scores.append(float(res.overall_score))
            if str(res.pass_fail).upper() != "PASS":
                record_pass = False

        overall_score = sum(record_scores) / len(record_scores) if record_scores else 0.0
        pass_fail = "PASS" if record_pass else "FAIL"

        upsert_trace(
            run_id=run_id,
            trace_id=trace_id,
            input_preview=str(rec.get("input", ""))[:200],
            overall_score=overall_score,
            pass_fail=pass_fail,
            trace_json=trace_payload,
            db_path=db_path,
        )

        total += 1
        if record_pass:
            pass_count += 1
        run_meta["records_processed"] = total

    pass_rate = (pass_count / total) if total else 0.0
    for tid in selected_tools:
        if tool_status.get(tid) == "running":
            tool_status[tid] = "done"
            run_log.append(f"Completed tool {tid}")
    upsert_run(project_id=project_id, run_id=run_id, status="completed", pass_rate=pass_rate, total=total, run_metadata=run_meta, db_path=db_path)

    return {
        "run_id": run_id,
        "project_id": project_id,
        "system_type": system_type,
        "access_mode": access_mode,
        "status": "completed",
        "pass_rate": pass_rate,
        "total": total,
    }
