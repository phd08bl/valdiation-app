from __future__ import annotations
from contextlib import contextmanager
from typing import Any, Dict, Optional, Generator

from .schemas import Span, now_ms, new_id
from . import config as app_config
from .store import insert_span

@contextmanager
def span(
    trace_id: str,
    name: str,
    payload: Optional[Dict[str, Any]] = None,
    parent_span_id: Optional[str] = None,
    db_path: Optional[str] = None,
) -> Generator[str, None, None]:
    """Context manager to record a span. Returns span_id."""
    db_path = db_path or app_config.db_path()
    start = now_ms()
    span_id = new_id("span")
    try:
        yield span_id
    finally:
        end = now_ms()
        insert_span(Span(
            span_id=span_id,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            name=name,
            start_ms=start,
            end_ms=end,
            payload=payload or {},
        ), db_path=db_path)
