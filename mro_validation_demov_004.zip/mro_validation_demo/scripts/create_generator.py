from __future__ import annotations

import argparse
import os
from pathlib import Path


TEMPLATE = """from __future__ import annotations

from typing import Any, Dict, List

from mro_validation_sdk.generators import BaseGenerator, GeneratorContext
from mro_validation_sdk.scenarios import ScenarioCase


class {class_name}(BaseGenerator):
    generator_id = "{generator_id}"
    name = "{name}"
    description = "{description}"
    supported_system_types = {{ "foundation_llm", "rag", "agentic", "multi_agent" }}
    supported_objectives = {{ "quality", "policy", "security", "rag_grounding", "agent_planning" }}

    def config_schema(self) -> Dict[str, Any]:
        return {{
            "fields": [
                {{"key": "num_cases", "type": "number", "label": "Target cases"}},
            ]
        }}

    def generate(self, seed_cases: List[ScenarioCase], cfg: Dict[str, Any], ctx: GeneratorContext) -> List[ScenarioCase]:
        # TODO: implement generation logic.
        return seed_cases


GENERATOR = {class_name}()
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="Scaffold a new generator plugin.")
    parser.add_argument("--id", required=True, help="Generator ID (e.g., my_generator_v0)")
    parser.add_argument("--name", required=True, help="Display name")
    parser.add_argument("--description", default="Custom generator", help="Short description")
    parser.add_argument("--dir", default="generators", help="Generators root folder")
    args = parser.parse_args()

    slug = args.id.replace("-", "_")
    gen_dir = Path(args.dir) / slug
    gen_dir.mkdir(parents=True, exist_ok=True)

    class_name = "".join([p.capitalize() for p in slug.split("_")]) + "Generator"
    code = TEMPLATE.format(
        class_name=class_name,
        generator_id=args.id,
        name=args.name,
        description=args.description.replace('"', "'"),
    )

    (gen_dir / "__init__.py").write_text("# Generator package\\n", encoding="utf-8")
    (gen_dir / "generator.py").write_text(code, encoding="utf-8")
    print(f"Created generator scaffold at {gen_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
