from __future__ import annotations

import argparse
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent
TOOLS_DIR = BASE_DIR / "tools"
TEMPLATE_PATH = BASE_DIR / "tool_templates" / "tool_template.py"
CHECKLIST_PATH = BASE_DIR / "TOOLS_CHECKLIST.md"
APP_PATH = BASE_DIR / "app.py"


def _render_template(tool_id: str, name: str, description: str, module_group: str) -> str:
    tpl = TEMPLATE_PATH.read_text(encoding="utf-8")
    tpl = tpl.replace('tool_id = "tool_id_here"', f'tool_id = "{tool_id}"')
    tpl = tpl.replace('name = "Human readable tool name"', f'name = "{name}"')
    tpl = tpl.replace('description = "One-line description of what this tool evaluates."', f'description = "{description}"')
    tpl = tpl.replace('module_group = "Quality, Correctness & Effectiveness"', f'module_group = "{module_group}"')
    return tpl


def _write_tool_files(tool_id: str, name: str, description: str, module_group: str) -> None:
    tool_dir = TOOLS_DIR / tool_id
    tool_dir.mkdir(parents=True, exist_ok=True)
    (tool_dir / "__init__.py").write_text("", encoding="utf-8")
    (tool_dir / "tool.py").write_text(_render_template(tool_id, name, description, module_group), encoding="utf-8")
    (tool_dir / "README.md").write_text(
        "\n".join(
            [
                f"# {name}",
                "",
                f"Tool ID: `{tool_id}`",
                "",
                "## Purpose",
                description,
                "",
                "## Development Notes",
                "- Implement `run_on_evidence` and adjust `required_evidence` for this tool.",
                "- Keep tool logic pure (no DB writes, no API calls).",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (tool_dir / "expected_outputs.json").write_text(
        "{\n  \"expected\": {\n    \"pass_fail\": \"PASS\",\n    \"overall_score\": 0.0,\n    \"metrics\": {}\n  }\n}\n",
        encoding="utf-8",
    )


def _update_checklist(tool_id: str, module_group: str) -> None:
    if not CHECKLIST_PATH.exists():
        return
    lines = CHECKLIST_PATH.read_text(encoding="utf-8").splitlines()
    out = []
    inserted = False
    i = 0
    while i < len(lines):
        line = lines[i]
        out.append(line)
        if line.strip() == f"## {module_group}":
            # Skip table header lines and insert after header if not present
            if i + 2 < len(lines) and lines[i + 1].startswith("| tool_id |"):
                header = lines[i + 1]
                divider = lines[i + 2]
                out.append(header)
                out.append(divider)
                i += 2
            # Insert row if not already present
            if all(tool_id not in l for l in lines):
                out.append(f"| {tool_id} |  |  |  |  |  |  |")
                inserted = True
        i += 1
    if inserted:
        CHECKLIST_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")


def _update_app_module_groups(tool_id: str, module_group: str) -> None:
    if not APP_PATH.exists():
        return
    lines = APP_PATH.read_text(encoding="utf-8").splitlines()
    out = []
    in_group = False
    group_found = False
    inserted = False
    for idx, line in enumerate(lines):
        out.append(line)
        if line.strip().startswith(f"\"{module_group}\""):
            group_found = True
            in_group = True
            continue
        if in_group and line.strip().startswith("]"):
            # Insert tool before closing list
            if not inserted and all(f"\"{tool_id}\"" not in l for l in lines):
                out.insert(len(out) - 1, f"        \"{tool_id}\",")
                inserted = True
            in_group = False
    if group_found and inserted:
        APP_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Scaffold a new tool.")
    parser.add_argument("--tool_id", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--description", required=True)
    parser.add_argument("--module_group", required=True)
    args = parser.parse_args()

    _write_tool_files(args.tool_id, args.name, args.description, args.module_group)
    _update_checklist(args.tool_id, args.module_group)
    _update_app_module_groups(args.tool_id, args.module_group)
    print(f"Created tool scaffold for {args.tool_id}")


if __name__ == "__main__":
    main()
