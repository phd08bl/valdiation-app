# Generator plugins live under generators/<id>/generator.py
