# Package marker for the basic scenario generator.
