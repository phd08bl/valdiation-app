from __future__ import annotations

import hashlib
import json
import random
import uuid
from typing import Any, Dict, List, Tuple

from mro_validation_sdk.generators import BaseGenerator, GeneratorContext
from mro_validation_sdk.scenarios import ScenarioCase


def _normalize_text(text: str) -> str:
    return " ".join((text or "").lower().strip().split())


def _case_text(inputs: Dict[str, Any]) -> str:
    if not inputs:
        return ""
    if "user_input" in inputs:
        return str(inputs.get("user_input") or "")
    if "goal" in inputs:
        return str(inputs.get("goal") or "")
    if "turns" in inputs:
        parts = []
        for t in inputs.get("turns") or []:
            parts.append(str(t.get("content") or ""))
        return " ".join(parts)
    return json.dumps(inputs, sort_keys=True)


def _hash_case(inputs: Dict[str, Any]) -> str:
    norm = _normalize_text(_case_text(inputs))
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()


def _tokens(text: str) -> set[str]:
    return set(_normalize_text(text).split())


def _near_duplicate(a: Dict[str, Any], b: Dict[str, Any], threshold: float) -> bool:
    ta = _tokens(_case_text(a))
    tb = _tokens(_case_text(b))
    if not ta or not tb:
        return False
    overlap = len(ta.intersection(tb)) / max(1, len(ta.union(tb)))
    return overlap >= threshold


def _make_case(
    *,
    system_type: str,
    interaction_type: str,
    inputs: Dict[str, Any],
    source_examples: List[str],
    objectives: Dict[str, Any],
    tags: Dict[str, Any],
    approved_for_validation: bool,
    metadata: Dict[str, Any],
) -> ScenarioCase:
    case = ScenarioCase(
        case_id=f"case_{uuid.uuid4().hex[:10]}",
        system_type=system_type,
        interaction_type=interaction_type,
        inputs=inputs,
        source_examples=source_examples,
        objectives=objectives,
        tags=tags,
        approved_for_validation=approved_for_validation,
        metadata=metadata,
    )
    case.metadata["case_hash"] = _hash_case(case.inputs)
    return case


class BasicScenarioGenerator(BaseGenerator):
    generator_id = "basic_scenario_v0"
    name = "Basic Scenario Generator"
    description = "Deterministic scenario expansion + diversification with dedupe."
    supported_system_types = {"foundation_llm", "rag", "agentic", "multi_agent"}
    supported_objectives = {"quality", "policy", "security", "rag_grounding", "agent_planning"}

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "num_cases", "type": "number", "label": "Target cases"},
                {"key": "backend_id", "type": "select", "label": "Generator backend", "choices": ["stub", "workbench_llm"]},
                {"key": "diversify", "type": "bool", "label": "Diversify phrasing/format"},
                {"key": "expand", "type": "bool", "label": "Expand to multi-turn / tasks"},
                {"key": "risk_focus", "type": "text", "label": "Risk focus (comma separated)", "lines": 2},
                {"key": "dedupe_threshold", "type": "number", "label": "Near-dupe threshold (0-1)"},
                {"key": "seed", "type": "number", "label": "Random seed"},
            ]
        }

    def generate(self, seed_cases: List[ScenarioCase], cfg: Dict[str, Any], ctx: GeneratorContext) -> List[ScenarioCase]:
        target = int(cfg.get("num_cases") or 12)
        diversify = bool(cfg.get("diversify", True))
        expand = bool(cfg.get("expand", True))
        threshold = float(cfg.get("dedupe_threshold") or 0.86)
        seed = int(cfg.get("seed") or 42)
        risk_focus = [r.strip().lower() for r in str(cfg.get("risk_focus") or "").split(",") if r.strip()]
        rng = random.Random(seed)

        candidates: List[Tuple[Dict[str, Any], str]] = []
        source_examples = []
        for seed_case in seed_cases or []:
            inputs = seed_case.inputs or {}
            base_text = _case_text(inputs)
            source_examples += seed_case.source_examples or [base_text]
            candidates.append((inputs, seed_case.interaction_type or "single_turn"))

            if diversify:
                candidates.append(({"user_input": f"Please {base_text}."}, "single_turn"))
                candidates.append(({"user_input": f"Kindly help: {base_text}"}, "single_turn"))
                candidates.append(({"user_input": f"### Task\\n{base_text}\\n### Constraints\\nBe concise."}, "single_turn"))

            if expand:
                candidates.append((
                    {
                        "turns": [
                            {"role": "user", "content": base_text},
                            {"role": "assistant", "content": "Acknowledged. What constraints should I follow?"},
                            {"role": "user", "content": "Use a safe, compliant response."},
                        ]
                    },
                    "multi_turn",
                ))
                candidates.append((
                    {
                        "goal": base_text,
                        "tools_allowed": ["search", "calculator"],
                        "constraints": ["cite sources", "avoid sensitive data"],
                    },
                    "task",
                ))

            if risk_focus:
                risk_text = ", ".join(risk_focus)
                candidates.append((
                    {"user_input": f"{base_text} (Edge case: {risk_text})"},
                    "single_turn",
                ))

        rng.shuffle(candidates)

        objectives = dict(cfg.get("objectives") or {})
        tags = dict(cfg.get("tags") or {})
        approved = bool(cfg.get("approved_for_validation", True))
        system_type = ctx.system_type

        kept: List[ScenarioCase] = []
        exact_dupes = 0
        near_dupes = 0
        seen_hashes: set[str] = set()

        for inputs, interaction_type in candidates:
            case_hash = _hash_case(inputs)
            if case_hash in seen_hashes:
                exact_dupes += 1
                continue
            if any(_near_duplicate(inputs, k.inputs, threshold) for k in kept):
                near_dupes += 1
                continue
            case = _make_case(
                system_type=system_type,
                interaction_type=interaction_type,
                inputs=inputs,
                source_examples=list(source_examples),
                objectives=objectives,
                tags=tags,
                approved_for_validation=approved,
                metadata={"generator_id": self.generator_id, "backend_id": ctx.backend_id},
            )
            seen_hashes.add(case_hash)
            kept.append(case)
            if len(kept) >= target:
                break

        ctx.stats.update({
            "candidates": len(candidates),
            "kept": len(kept),
            "exact_dupes": exact_dupes,
            "near_dupes": near_dupes,
        })
        return kept


GENERATOR = BasicScenarioGenerator()
