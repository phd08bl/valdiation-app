from __future__ import annotations
import hashlib
from typing import Any, Dict
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext
from mro_validation_sdk.record_utils import get_latency_ms


class LatencyTrackerTool(BaseTool):
    tool_id = "latency_tracker"
    name = "Latency Tracker"
    version = "0.2"
    description = "Tracks observed latency against an SLA threshold."
    module_group = "System Performance, Cost & Efficiency"

    def metadata(self) -> Dict[str, Any]:
        return {
            "owner": "SRE",
            "status": "Approved",
            "tags": ["latency", "monitoring", "ops"],
            "limitations": "Demo uses synthetic latency if not present in record.",
        }

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        return "available"

    def default_config(self) -> Dict[str, Any]:
        return {"sla_ms": 2000, "alert_threshold": 1.2}

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "sla_ms", "type": "number", "label": "SLA (ms)", "min": 100, "max": 10000, "step": 100},
                {"key": "alert_threshold", "type": "number", "label": "Alert multiplier", "min": 1.0, "max": 3.0, "step": 0.1},
            ]
        }

    def _synthetic_latency(self, record_id: str) -> float:
        digest = hashlib.md5(record_id.encode("utf-8")).hexdigest()
        bucket = int(digest[:6], 16) % 2000
        return 800 + bucket

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        latency_ms = get_latency_ms(record)
        if latency_ms is None:
            latency_ms = self._synthetic_latency(record.get("id", "0"))
        latency_ms = float(latency_ms)
        sla = float(config.get("sla_ms", 2000))
        alert = float(config.get("alert_threshold", 1.2))
        fail = latency_ms > sla * alert
        score = max(0.0, min(1.0, 1.0 - (latency_ms - sla) / max(sla, 1.0))) if latency_ms > sla else 1.0
        payload = {"latency_ms": latency_ms, "sla_ms": sla, "alert_threshold": alert}
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=score,
            pass_fail="FAIL" if fail else "PASS",
            metrics=payload,
            evidence=[EvidenceItem(kind="metric", title="Latency observation", payload=payload)],
        )


TOOL: BaseTool = LatencyTrackerTool()
