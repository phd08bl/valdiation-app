from __future__ import annotations
import hashlib
import re
from typing import Any, Dict, List
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext
from mro_validation_sdk.record_utils import get_output_text, get_context_text


class HallucinationCheckTool(BaseTool):
    tool_id = "hallucination_check"
    name = "Hallucination Check"
    version = "0.1"
    description = "Heuristic check for unsupported claims vs provided context."
    module_group = "Quality, Correctness & Effectiveness"

    def metadata(self) -> Dict[str, Any]:
        return {
            "owner": "Evaluation",
            "status": "Experimental",
            "tags": ["hallucination", "faithfulness"],
            "limitations": "Token overlap heuristic; not a semantic entailment model.",
        }

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        if access_mode == "black_box":
            return "limited"
        return "available"

    def coverage_notes(self, system_type: str, access_mode: str) -> str:
        if access_mode == "black_box":
            return "Limited without grounded context; uses output-only heuristics."
        return ""

    def default_config(self) -> Dict[str, Any]:
        return {"min_overlap_ratio": 0.55, "max_unsupported_terms": 4}

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "min_overlap_ratio", "type": "number", "label": "Min overlap ratio", "min": 0, "max": 1, "step": 0.05},
                {"key": "max_unsupported_terms", "type": "number", "label": "Max unsupported terms", "min": 0, "max": 20, "step": 1},
            ]
        }

    def _score_from_id(self, record_id: str, salt: str) -> float:
        digest = hashlib.md5(f"{record_id}:{salt}".encode("utf-8")).hexdigest()
        bucket = int(digest[:6], 16) % 1000
        return 0.55 + (bucket / 1000.0) * 0.35

    def _tokenize(self, text: str) -> List[str]:
        return re.findall(r"[a-zA-Z0-9']+", (text or "").lower())

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        answer = get_output_text(record)
        context = get_context_text(record)
        answer_tokens = self._tokenize(answer)
        context_tokens = set(self._tokenize(context))
        if not answer_tokens:
            ratio = 1.0
            unsupported = 0
        else:
            supported = [t for t in answer_tokens if t in context_tokens]
            unsupported = len(answer_tokens) - len(supported)
            ratio = len(supported) / max(len(answer_tokens), 1)

        min_ratio = float(config.get("min_overlap_ratio", 0.55))
        max_unsupported = int(config.get("max_unsupported_terms", 4))
        fail = ratio < min_ratio or unsupported > max_unsupported
        score = 0.25 if fail else self._score_from_id(record.get("id", "0"), self.tool_id)

        payload = {"overlap_ratio": round(ratio, 3), "unsupported_terms": unsupported}
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=score,
            pass_fail="FAIL" if fail else "PASS",
            metrics=payload,
            evidence=[EvidenceItem(kind="score_breakdown", title="Context overlap", payload=payload)],
        )


TOOL: BaseTool = HallucinationCheckTool()
