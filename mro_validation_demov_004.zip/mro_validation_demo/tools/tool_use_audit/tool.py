from __future__ import annotations
import hashlib
import re
from typing import Any, Dict
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext
from mro_validation_sdk.record_utils import get_output_text, get_tool_calls


class ToolUseAuditTool(BaseTool):
    tool_id = "tool_use_audit"
    name = "Tool Use Audit"
    version = "0.1"
    description = "Checks for explicit tool-use mentions or action traces in the answer."
    module_group = "Agent Planning, Control & Tool-Use"

    def metadata(self) -> Dict[str, Any]:
        return {
            "owner": "Agentic Ops",
            "status": "Experimental",
            "tags": ["tool-use", "actions"],
            "limitations": "Keyword-based detection only.",
        }

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        if system_type not in ("Agentic AI", "Multi-Agent System", "Low/No-code Agent"):
            return "limited"
        if access_mode == "black_box":
            return "limited"
        return "available"

    def coverage_notes(self, system_type: str, access_mode: str) -> str:
        if access_mode == "black_box":
            return "Limited to output-level tool markers."
        return ""

    def default_config(self) -> Dict[str, Any]:
        return {"require_tool_calls": False, "min_tool_calls": 1}

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "require_tool_calls", "type": "bool", "label": "Require tool calls"},
                {"key": "min_tool_calls", "type": "number", "label": "Minimum tool calls", "min": 0, "max": 10, "step": 1},
            ]
        }

    def _score_from_id(self, record_id: str, salt: str) -> float:
        digest = hashlib.md5(f"{record_id}:{salt}".encode("utf-8")).hexdigest()
        bucket = int(digest[:6], 16) % 1000
        return 0.6 + (bucket / 1000.0) * 0.3

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        answer = get_output_text(record) or ""
        calls = get_tool_calls(record)
        if calls:
            tool_count = len(calls)
        else:
            tool_count = len(re.findall(r"\btool[:\s_]", answer.lower()))
        require_calls = bool(config.get("require_tool_calls", False))
        min_calls = int(config.get("min_tool_calls", 1))
        fail = require_calls and tool_count < min_calls
        score = 0.35 if fail else self._score_from_id(record.get("id", "0"), self.tool_id)
        payload = {"tool_calls_detected": tool_count, "min_required": min_calls}
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=score,
            pass_fail="FAIL" if fail else "PASS",
            metrics=payload,
            evidence=[EvidenceItem(kind="finding", title="Tool use markers", payload=payload)],
        )


TOOL: BaseTool = ToolUseAuditTool()
