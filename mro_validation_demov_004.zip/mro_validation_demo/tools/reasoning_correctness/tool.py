from __future__ import annotations
import hashlib
from typing import Any, Dict
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext


class ReasoningCorrectnessTool(BaseTool):
    tool_id = "reasoning_correctness"
    name = "Reasoning Correctness"
    version = "0.1"
    description = "Demo judge for Reasoning Correctness."
    module_group = "Agent Planning, Control & Tool-Use"

    def metadata(self) -> Dict[str, Any]:
        return {
            "owner": "Demo Team",
            "status": "Experimental",
            "tags": ['judge','demo','agent'],
            "limitations": "Heuristic demo judge; not a production evaluator.",
        }

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        if system_type not in ['Agentic AI', 'Low/No-code Agent', 'Multi-Agent System']:
            return 'unavailable'
        if access_mode == 'black_box':
            return 'limited'
        return 'available'

    def coverage_notes(self, system_type: str, access_mode: str) -> str:
        if system_type not in ['Agentic AI', 'Low/No-code Agent', 'Multi-Agent System']:
            return 'Agentic systems only.'
        if access_mode == 'black_box':
            return 'Limited without trace-level access.'
        return ''

    def default_config(self) -> Dict[str, Any]:
        return {"threshold": 0.7, "strict_mode": False}

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "threshold", "type": "number", "label": "Pass threshold", "min": 0, "max": 1, "step": 0.05},
                {"key": "strict_mode", "type": "bool", "label": "Strict mode"},
                {"key": "notes", "type": "text", "label": "Notes", "lines": 2},
            ]
        }

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        rid = str(record.get("id", "0"))
        digest = hashlib.md5(f"{rid}:{self.tool_id}".encode("utf-8")).hexdigest()
        base = int(digest[:6], 16) % 1000
        score = 0.5 + (base / 1000.0) * 0.5
        if config.get("strict_mode"):
            score = max(0.0, score - 0.1)
        threshold = float(config.get("threshold", 0.7))
        passed = score >= threshold
        metrics = {"score": round(score, 3), "threshold": threshold}
        evidence = [EvidenceItem(kind="score", title="Score breakdown", payload=metrics)]
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=round(score, 3),
            pass_fail="PASS" if passed else "FAIL",
            metrics=metrics,
            evidence=evidence,
        )


TOOL: BaseTool = ReasoningCorrectnessTool()
