from __future__ import annotations
from typing import Any, Dict, List
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext
from mro_validation_sdk.record_utils import get_output_text, get_context_text

class RagGroundednessTool(BaseTool):
    tool_id = "rag_groundedness_stub"
    name = "RAG Groundedness (Stub)"
    version = "0.1"
    description = "Toy groundedness proxy: checks whether output mentions provided citations/context."

    supported_system_types: List[str] = ["RAG", "Agentic AI", "Multi-Agent System"]

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        # Full for trace/white_box, limited for blackbox in demo
        if access_mode == "black_box":
            return "limited"
        return "available"

    def default_config(self) -> Dict[str, Any]:
        return {"min_overlap_terms": 1}

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        output = (get_output_text(record) or "").lower()
        context = (get_context_text(record) or "").lower()
        terms = [t for t in context.split() if len(t) > 5][:20]
        overlap = sum(1 for t in terms if t in output)
        min_terms = int(config.get("min_overlap_terms", 1))
        ok = overlap >= min_terms if terms else True
        score = 1.0 if ok else 0.0
        payload = {"overlap_terms": overlap, "min_overlap_terms": min_terms, "coverage": self.coverage_status(ctx.system_type, ctx.access_mode)}
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=score,
            pass_fail="PASS" if ok else "FAIL",
            metrics=payload,
            evidence=[EvidenceItem(kind="rag_proxy", title="Groundedness proxy", payload=payload)],
        )

TOOL: BaseTool = RagGroundednessTool()
