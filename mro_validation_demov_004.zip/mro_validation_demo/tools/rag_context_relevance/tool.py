from __future__ import annotations
import hashlib
import re
from typing import Any, Dict, List
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext
from mro_validation_sdk.record_utils import get_output_text, get_context_text


class RagContextRelevanceTool(BaseTool):
    tool_id = "rag_context_relevance"
    name = "RAG Context Relevance"
    version = "0.1"
    description = "Estimates how relevant retrieved context is to the answer."
    module_group = "RAG & Knowledge Evaluation"

    def metadata(self) -> Dict[str, Any]:
        return {
            "owner": "RAG Ops",
            "status": "Experimental",
            "tags": ["rag", "retrieval", "relevance"],
            "limitations": "Keyword overlap proxy; no semantic embeddings used.",
        }

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        if system_type not in ("RAG", "Agentic AI", "Multi-Agent System", "Low/No-code Agent"):
            return "unavailable"
        if access_mode == "black_box":
            return "limited"
        return "available"

    def coverage_notes(self, system_type: str, access_mode: str) -> str:
        if system_type not in ("RAG", "Agentic AI", "Multi-Agent System", "Low/No-code Agent"):
            return "Requires retrieved context."
        if access_mode == "black_box":
            return "Limited without access to retrieval traces."
        return ""

    def default_config(self) -> Dict[str, Any]:
        return {"min_relevance_ratio": 0.5, "min_shared_terms": 3}

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "min_relevance_ratio", "type": "number", "label": "Min relevance ratio", "min": 0, "max": 1, "step": 0.05},
                {"key": "min_shared_terms", "type": "number", "label": "Min shared terms", "min": 0, "max": 20, "step": 1},
            ]
        }

    def _score_from_id(self, record_id: str, salt: str) -> float:
        digest = hashlib.md5(f"{record_id}:{salt}".encode("utf-8")).hexdigest()
        bucket = int(digest[:6], 16) % 1000
        return 0.6 + (bucket / 1000.0) * 0.35

    def _tokens(self, text: str) -> List[str]:
        return re.findall(r"[a-zA-Z0-9']+", (text or "").lower())

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        answer = get_output_text(record)
        context = get_context_text(record)
        answer_tokens = self._tokens(answer)
        context_tokens = set(self._tokens(context))
        shared = [t for t in answer_tokens if t in context_tokens]
        ratio = len(shared) / max(len(answer_tokens), 1)
        shared_terms = len(set(shared))

        min_ratio = float(config.get("min_relevance_ratio", 0.5))
        min_shared = int(config.get("min_shared_terms", 3))
        fail = ratio < min_ratio or shared_terms < min_shared
        score = 0.3 if fail else self._score_from_id(record.get("id", "0"), self.tool_id)
        payload = {"relevance_ratio": round(ratio, 3), "shared_terms": shared_terms}
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=score,
            pass_fail="FAIL" if fail else "PASS",
            metrics=payload,
            evidence=[EvidenceItem(kind="score_breakdown", title="Context relevance", payload=payload)],
        )


TOOL: BaseTool = RagContextRelevanceTool()
