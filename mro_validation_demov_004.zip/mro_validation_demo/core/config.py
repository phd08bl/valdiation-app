from __future__ import annotations

import os
from pathlib import Path


def _env(key: str, default: str) -> str:
    val = os.getenv(key)
    return val.strip() if val else default


def base_dir() -> str:
    return str(Path(__file__).resolve().parent.parent)


def runs_dir() -> str:
    return _env("MRO_RUNS_DIR", str(Path(base_dir()) / "runs"))


def db_path() -> str:
    return _env("MRO_DB_PATH", str(Path(runs_dir()) / "mro_demo.sqlite"))


def dataset_path() -> str:
    return _env("MRO_DATASET_PATH", str(Path(base_dir()) / "data" / "dataset.jsonl"))


def reports_dir() -> str:
    return _env("MRO_REPORTS_DIR", str(Path(runs_dir()) / "reports"))


def fixtures_dir() -> str:
    return _env("MRO_FIXTURES_DIR", str(Path(base_dir()) / "fixtures"))

