from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from mro_validation_sdk.scenarios import ScenarioCase, ScenarioDataset
from core import config as app_config


DEFAULT_DB = app_config.db_path()


def _connect(db_path: str = DEFAULT_DB) -> sqlite3.Connection:
    dir_name = os.path.dirname(db_path)
    if dir_name:
        os.makedirs(dir_name, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


SCHEMA_SQL = [
    """
    CREATE TABLE IF NOT EXISTS scenario_datasets (
        dataset_id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        created_ts TEXT NOT NULL,
        generator_config_json TEXT,
        lineage_json TEXT,
        case_count INTEGER NOT NULL DEFAULT 0,
        version TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS scenario_dataset_cases (
        dataset_id TEXT NOT NULL,
        case_id TEXT NOT NULL,
        case_json TEXT NOT NULL,
        case_hash TEXT,
        approved_for_validation INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY (dataset_id, case_id),
        FOREIGN KEY(dataset_id) REFERENCES scenario_datasets(dataset_id) ON DELETE CASCADE
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_scenario_datasets_project_id ON scenario_datasets(project_id)",
    "CREATE INDEX IF NOT EXISTS idx_scenario_cases_dataset_id ON scenario_dataset_cases(dataset_id)",
    "CREATE INDEX IF NOT EXISTS idx_scenario_cases_hash ON scenario_dataset_cases(case_hash)",
]


def init_db(db_path: str = DEFAULT_DB) -> None:
    with _connect(db_path) as conn:
        for stmt in SCHEMA_SQL:
            conn.execute(stmt)
        conn.commit()


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hash_case(case: ScenarioCase) -> str:
    payload = json.dumps(case.inputs or {}, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def create_dataset(dataset: ScenarioDataset, db_path: str = DEFAULT_DB) -> str:
    init_db(db_path)
    dataset_id = dataset.dataset_id or f"ds_{uuid.uuid4().hex[:10]}"
    cases = dataset.cases or []
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO scenario_datasets(dataset_id, project_id, name, description, created_ts, generator_config_json, lineage_json, case_count, version)
            VALUES (?,?,?,?,?,?,?,?,?)
            """,
            (
                dataset_id,
                dataset.project_id,
                dataset.name,
                dataset.description,
                dataset.created_ts or _iso_now(),
                json.dumps(dataset.generator_config or {}),
                json.dumps(dataset.lineage or {}),
                len(cases),
                dataset.version or "dataset.v0",
            ),
        )
        rows = []
        for c in cases:
            case_hash = c.metadata.get("case_hash") if isinstance(c.metadata, dict) else None
            if not case_hash:
                case_hash = _hash_case(c)
            rows.append(
                (
                    dataset_id,
                    c.case_id,
                    json.dumps(c.to_dict()),
                    case_hash,
                    1 if c.approved_for_validation else 0,
                )
            )
        if rows:
            conn.executemany(
                """
                INSERT INTO scenario_dataset_cases(dataset_id, case_id, case_json, case_hash, approved_for_validation)
                VALUES (?,?,?,?,?)
                """,
                rows,
            )
        conn.commit()
    return dataset_id


def list_datasets(project_id: str, db_path: str = DEFAULT_DB) -> List[Dict[str, Any]]:
    init_db(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT dataset_id, project_id, name, description, created_ts, case_count, version
            FROM scenario_datasets
            WHERE project_id=?
            ORDER BY created_ts DESC
            """,
            (project_id,),
        ).fetchall()
        return [dict(r) for r in rows]


def load_dataset(dataset_id: str, db_path: str = DEFAULT_DB) -> ScenarioDataset:
    init_db(db_path)
    with _connect(db_path) as conn:
        row = conn.execute(
            """
            SELECT dataset_id, project_id, name, description, created_ts, generator_config_json, lineage_json, version
            FROM scenario_datasets WHERE dataset_id=?
            """,
            (dataset_id,),
        ).fetchone()
        if not row:
            raise KeyError(f"Dataset not found: {dataset_id}")
        case_rows = conn.execute(
            """
            SELECT case_json FROM scenario_dataset_cases WHERE dataset_id=? ORDER BY case_id ASC
            """,
            (dataset_id,),
        ).fetchall()
        cases = [ScenarioCase.from_dict(json.loads(r["case_json"])) for r in case_rows]
        return ScenarioDataset(
            dataset_id=row["dataset_id"],
            project_id=row["project_id"],
            name=row["name"],
            description=row["description"] or "",
            created_ts=row["created_ts"],
            cases=cases,
            generator_config=json.loads(row["generator_config_json"] or "{}"),
            lineage=json.loads(row["lineage_json"] or "{}"),
            version=row["version"] or "dataset.v0",
        )


def duplicate_dataset(dataset_id: str, db_path: str = DEFAULT_DB) -> str:
    ds = load_dataset(dataset_id, db_path=db_path)
    ds.dataset_id = f"ds_{uuid.uuid4().hex[:10]}"
    ds.created_ts = _iso_now()
    ds.name = f"{ds.name} (copy)"
    return create_dataset(ds, db_path=db_path)


def delete_dataset(dataset_id: str, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute("DELETE FROM scenario_dataset_cases WHERE dataset_id=?", (dataset_id,))
        conn.execute("DELETE FROM scenario_datasets WHERE dataset_id=?", (dataset_id,))
        conn.commit()


def delete_datasets_for_project(project_id: str, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute("SELECT dataset_id FROM scenario_datasets WHERE project_id=?", (project_id,)).fetchall()
        dataset_ids = [r["dataset_id"] for r in rows]
        if dataset_ids:
            conn.executemany("DELETE FROM scenario_dataset_cases WHERE dataset_id=?", [(d,) for d in dataset_ids])
            conn.executemany("DELETE FROM scenario_datasets WHERE dataset_id=?", [(d,) for d in dataset_ids])
        conn.commit()


def export_dataset(dataset_id: str, path: str, db_path: str = DEFAULT_DB) -> str:
    ds = load_dataset(dataset_id, db_path=db_path)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for c in ds.cases:
            f.write(json.dumps(c.to_dict()) + "\n")
    return path
