from __future__ import annotations

import argparse
import json
import uuid
from typing import Any, Dict, List

from mro_validation_sdk.generators import GeneratorContext
from mro_validation_sdk.scenarios import ScenarioCase

from core.generators.registry import discover_generators


def _load_seeds(path: str) -> List[ScenarioCase]:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    seeds: List[ScenarioCase] = []
    for item in raw or []:
        if isinstance(item, ScenarioCase):
            seeds.append(item)
            continue
        if isinstance(item, dict):
            inputs = item.get("inputs") if "inputs" in item else item
            seeds.append(
                ScenarioCase(
                    case_id=item.get("case_id") or f"seed_{uuid.uuid4().hex[:6]}",
                    system_type=item.get("system_type") or "foundation_llm",
                    interaction_type=item.get("interaction_type") or "single_turn",
                    inputs=dict(inputs or {}),
                    source_examples=item.get("source_examples") or [],
                    objectives=item.get("objectives") or {},
                    tags=item.get("tags") or {},
                    approved_for_validation=bool(item.get("approved_for_validation", True)),
                    metadata=item.get("metadata") or {},
                )
            )
            continue
        seeds.append(
            ScenarioCase(
                case_id=f"seed_{uuid.uuid4().hex[:6]}",
                system_type="foundation_llm",
                interaction_type="single_turn",
                inputs={"user_input": str(item)},
                source_examples=[str(item)],
                objectives={},
                tags={},
                approved_for_validation=True,
                metadata={},
            )
        )
    return seeds


def run(generator_id: str, seed_file: str, cfg: Dict[str, Any]) -> int:
    discovered = discover_generators("generators")
    if discovered.errors:
        print("Generator load errors:")
        for err in discovered.errors:
            print(f" - {err}")
    gen = discovered.generators.get(generator_id)
    if gen is None:
        print(f"FAIL: generator_id '{generator_id}' not found.")
        return 1

    seeds = _load_seeds(seed_file)
    system_type = seeds[0].system_type if seeds else "foundation_llm"
    ctx = GeneratorContext(
        project_id="local_test",
        system_type=system_type,
        backend_id=str(cfg.get("backend_id") or "stub"),
        run_id=f"gen_{uuid.uuid4().hex[:6]}",
    )
    try:
        out = gen.generate(seeds, cfg, ctx)
    except Exception as exc:
        print(f"FAIL: generator execution error: {exc}")
        return 1

    print(f"OK: generated {len(out)} cases with {generator_id}")
    if ctx.stats:
        print("Stats:")
        for k, v in ctx.stats.items():
            print(f" - {k}: {v}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a scenario generator against seed inputs.")
    parser.add_argument("--generator_id", required=True, help="Generator ID to run")
    parser.add_argument("--seed_file", required=True, help="Seed JSON file")
    parser.add_argument("--cfg", default="{}", help="Generator config JSON")
    args = parser.parse_args()
    cfg = json.loads(args.cfg)
    return run(args.generator_id, args.seed_file, cfg)


if __name__ == "__main__":
    raise SystemExit(main())
