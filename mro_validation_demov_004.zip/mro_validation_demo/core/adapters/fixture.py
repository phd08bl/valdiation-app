from __future__ import annotations

import json
from typing import Any, Dict, Set

from mro_validation_sdk.evidence import EvidenceBundle

from .base import BaseAdapter


class FixtureAdapter(BaseAdapter):
    adapter_id = "fixture"
    name = "Fixture Adapter"

    def supported_access_modes(self) -> Set[str]:
        return {"black_box", "traced", "white_box"}

    def build_evidence(
        self,
        *,
        record: Dict[str, Any] | None,
        system_type: str,
        access_mode: str,
        cfg: Dict[str, Any],
    ) -> EvidenceBundle:
        fixture_path = cfg.get("fixture_path") if cfg else None
        if not fixture_path and record:
            fixture_path = record.get("fixture_path")
        if not fixture_path:
            raise ValueError("FixtureAdapter requires fixture_path in config or record.")
        with open(fixture_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        bundle = EvidenceBundle.from_dict(data)
        ok, msg = bundle.validate()
        if not ok:
            raise ValueError(f"Invalid EvidenceBundle: {msg}")
        return bundle
