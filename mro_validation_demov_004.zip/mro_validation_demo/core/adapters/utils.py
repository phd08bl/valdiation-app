from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from mro_validation_sdk.evidence import (
    EvidenceAgent,
    EvidenceRAG,
    EvidenceRequest,
    EvidenceResponse,
    EvidenceTrace,
    EvidenceBundle,
    build_request,
)
from mro_validation_sdk.record_utils import (
    get_input_text,
    get_output_text,
    get_latency_ms,
    get_token_usage,
    get_tool_calls,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_rag_from_record(record: Dict[str, Any]) -> Optional[EvidenceRAG]:
    retrieved = []
    contexts = record.get("retrieved_contexts") or record.get("contexts") or []
    if isinstance(contexts, list):
        for idx, item in enumerate(contexts):
            if isinstance(item, dict):
                retrieved.append(
                    {
                        "doc_id": item.get("source") or item.get("doc_id") or f"doc_{idx}",
                        "chunk_id": item.get("chunk_id") or f"chunk_{idx}",
                        "text_snippet": item.get("text") or item.get("content") or "",
                        "score": item.get("score"),
                        "rank": item.get("rank") or idx + 1,
                    }
                )
    if not retrieved:
        return None
    return EvidenceRAG(retrieved_items=retrieved, citations=None, metadata={})


def build_agent_from_record(record: Dict[str, Any]) -> Optional[EvidenceAgent]:
    steps = record.get("agent_steps") or record.get("steps") or []
    tool_calls = []
    for call in get_tool_calls(record):
        tool_calls.append(
            {
                "name": call.get("tool") or call.get("name"),
                "args": call.get("args") or {},
                "result": call.get("output") or call.get("result"),
                "status": call.get("status") or "ok",
                "latency_ms": call.get("latency_ms"),
                "error": call.get("error"),
            }
        )
    if not steps and not tool_calls:
        return None
    return EvidenceAgent(steps=list(steps or []), tool_calls=tool_calls, metadata={})


def build_trace_stub(trace_id: str, access_mode: str, extra_attrs: Optional[Dict[str, Any]] = None) -> EvidenceTrace:
    span = {
        "span_id": f"{trace_id}_span_1",
        "parent_id": None,
        "name": "model_inference",
        "start_ts": _now_iso(),
        "end_ts": _now_iso(),
        "attrs": extra_attrs or {},
    }
    return EvidenceTrace(trace_id=trace_id, spans=[span], logs=None, metadata={})


def build_request_from_record(
    record: Dict[str, Any],
    system_type: str,
    access_mode: str,
    case_id: Optional[str] = None,
) -> EvidenceRequest:
    case_id = case_id or str(record.get("id") or record.get("case_id") or "case_0")
    return build_request(
        case_id=case_id,
        user_input=get_input_text(record) or "",
        system_type=system_type,
        access_mode=access_mode,
        timestamp=str(record.get("timestamp") or _now_iso()),
        metadata={},
    )


def build_response_from_record(record: Dict[str, Any]) -> EvidenceResponse:
    model = record.get("model") or {}
    return EvidenceResponse(
        output_text=get_output_text(record) or "",
        raw_output=record.get("raw_output"),
        model_id=model.get("name") or model.get("id"),
        model_version=model.get("version"),
        latency_ms=int(get_latency_ms(record) or 0) if get_latency_ms(record) is not None else None,
        token_usage=get_token_usage(record) or None,
        metadata={},
    )


def build_bundle_from_record(
    record: Dict[str, Any],
    system_type: str,
    access_mode: str,
    trace_id: Optional[str] = None,
    config_snapshot: Optional[Dict[str, Any]] = None,
    include_trace: bool = False,
) -> EvidenceBundle:
    trace = None
    if include_trace:
        trace = build_trace_stub(trace_id or f"trace_{record.get('id','0')}", access_mode)
    return EvidenceBundle(
        request=build_request_from_record(record, system_type, access_mode),
        response=build_response_from_record(record),
        rag=build_rag_from_record(record),
        agent=build_agent_from_record(record),
        trace=trace,
        config_snapshot=config_snapshot,
        attachments=None,
    )
