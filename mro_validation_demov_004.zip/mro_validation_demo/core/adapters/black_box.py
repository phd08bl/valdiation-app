from __future__ import annotations

from typing import Any, Dict, Set

from mro_validation_sdk.evidence import EvidenceBundle

from .base import BaseAdapter
from .utils import build_bundle_from_record


class BlackBoxAdapter(BaseAdapter):
    adapter_id = "black_box"
    name = "Black Box Adapter"

    def supported_access_modes(self) -> Set[str]:
        return {"black_box"}

    def build_evidence(
        self,
        *,
        record: Dict[str, Any] | None,
        system_type: str,
        access_mode: str,
        cfg: Dict[str, Any],
    ) -> EvidenceBundle:
        if record is None:
            raise ValueError("BlackBoxAdapter requires a dataset record.")
        bundle = build_bundle_from_record(
            record=record,
            system_type=system_type,
            access_mode=access_mode,
            trace_id=record.get("trace_id"),
            config_snapshot=cfg.get("config_snapshot") if cfg else None,
            include_trace=False,
        )
        ok, msg = bundle.validate()
        if not ok:
            raise ValueError(f"Invalid EvidenceBundle: {msg}")
        return bundle
