from __future__ import annotations

from typing import Any, Dict, Set

from mro_validation_sdk.evidence import EvidenceBundle


class BaseAdapter:
    adapter_id: str = "base"
    name: str = "Base Adapter"

    def supported_access_modes(self) -> Set[str]:
        return set()

    def build_evidence(
        self,
        *,
        record: Dict[str, Any] | None,
        system_type: str,
        access_mode: str,
        cfg: Dict[str, Any],
    ) -> EvidenceBundle:
        raise NotImplementedError
