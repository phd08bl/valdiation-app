from __future__ import annotations

from typing import Dict, List, Tuple

from .base import BaseAdapter
from .black_box import BlackBoxAdapter
from .fixture import FixtureAdapter
from .traced import TracedAdapter
from .white_box import WhiteBoxAdapter


def discover_adapters() -> Tuple[Dict[str, BaseAdapter], List[str]]:
    adapters: Dict[str, BaseAdapter] = {}
    errors: List[str] = []
    for cls in (FixtureAdapter, BlackBoxAdapter, TracedAdapter, WhiteBoxAdapter):
        try:
            inst = cls()
            if inst.adapter_id in adapters:
                errors.append(f"Duplicate adapter_id: {inst.adapter_id}")
                continue
            adapters[inst.adapter_id] = inst
        except Exception as exc:
            errors.append(f"{cls.__name__}: init failed ({type(exc).__name__}: {exc})")
    return adapters, errors
