from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict

from mro_validation_sdk import ToolContext
from mro_validation_sdk.evidence import EvidenceBundle

from core.discovery import discover_tools
from core.store import get_active_tool_preset_config, get_tool_config
from core import config as app_config


def _load_fixture(path: str) -> EvidenceBundle:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    bundle = EvidenceBundle.from_dict(data)
    ok, msg = bundle.validate()
    if not ok:
        raise ValueError(f"Invalid EvidenceBundle: {msg}")
    return bundle


def _resolve_config(project_id: str, tool_id: str, preset: str | None) -> Dict[str, Any]:
    if preset == "active":
        cfg = get_active_tool_preset_config(project_id, tool_id, db_path=app_config.db_path())
        if cfg:
            return cfg
    cfg = get_tool_config(project_id, tool_id, db_path=app_config.db_path())
    if cfg:
        return cfg
    return {}


def run(tool_id: str, fixture_path: str, project_id: str, cfg_preset: str | None) -> int:
    tools, errors = discover_tools("tools")
    if errors:
        print("Tool load errors:")
        for err in errors:
            print(f" - {err}")
    tool = tools.get(tool_id)
    if tool is None:
        print(f"FAIL: tool_id '{tool_id}' not found.")
        return 1

    evidence = _load_fixture(fixture_path)
    cfg = _resolve_config(project_id, tool_id, cfg_preset)
    if not cfg:
        cfg = tool.default_config() if hasattr(tool, "default_config") else {}

    ctx = ToolContext(
        project_id=project_id,
        system_type=evidence.request.system_type,
        access_mode=evidence.request.access_mode,
        api_base_url=None,
        db_path=app_config.db_path(),
    )

    try:
        res = tool.run_on_evidence(evidence, cfg, ctx)
    except Exception as exc:
        print(f"FAIL: tool execution error: {exc}")
        return 1

    passed = str(res.pass_fail).upper() == "PASS"
    status = "PASS" if passed else "FAIL"
    print(f"{status}: {tool_id} on fixture {fixture_path}")
    print(f" - score: {res.overall_score}")
    print(f" - metrics: {res.metrics}")
    return 0 if passed else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a single tool against a MEC fixture.")
    parser.add_argument("--tool_id", required=True, help="Tool ID to run")
    parser.add_argument("--fixture", required=True, help="Path to fixture JSON")
    parser.add_argument("--project_id", required=True, help="Project ID for config lookups")
    parser.add_argument("--cfg_preset", default="active", help="Config preset to apply (default: active)")
    args = parser.parse_args()
    return run(args.tool_id, args.fixture, args.project_id, args.cfg_preset)


if __name__ == "__main__":
    raise SystemExit(main())
