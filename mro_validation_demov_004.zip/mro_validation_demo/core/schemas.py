from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional
import time
import uuid

SCHEMA_VERSION = "0.1"

def now_ms() -> int:
    return int(time.time() * 1000)

def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"

@dataclass
class Project:
    project_id: str
    name: str
    description: str
    created_at: int

@dataclass
class Run:
    run_id: str
    project_id: str
    created_at: int
    status: str
    dataset_path: str
    dataset_hash: str
    model_name: str
    model_version: str
    suite_name: str
    pass_rate: float = 0.0

@dataclass
class Trace:
    trace_id: str
    run_id: str
    project_id: str
    created_at: int
    input_query: str
    input_context: str
    output_text: str
    overall_score: float
    pass_fail: str
    metadata: Dict[str, Any]

@dataclass
class Span:
    span_id: str
    trace_id: str
    parent_span_id: Optional[str]
    name: str
    start_ms: int
    end_ms: int
    payload: Dict[str, Any]

@dataclass
class EvalResult:
    eval_id: str
    trace_id: str
    span_id: Optional[str]
    name: str
    score: float
    passed: bool
    rationale: str
    created_at: int

def to_dict(obj: Any) -> Dict[str, Any]:
    if hasattr(obj, "__dataclass_fields__"):
        return asdict(obj)
    raise TypeError("Unsupported object")
