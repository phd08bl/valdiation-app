from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class JudgeResult:
    name: str
    score: float
    passed: bool
    rationale: str

class StubFaithfulnessJudge:
    """Deterministic demo judge. Replace with real LLM-as-judge later."""
    name: str = "faithfulness_stub"

    def evaluate(self, query: str, context: str, answer: str, expected_contains: Optional[List[str]] = None) -> JudgeResult:
        expected_contains = expected_contains or []
        for kw in expected_contains:
            if kw.lower() not in (answer or "").lower():
                return JudgeResult(self.name, 0.2, False, f"Answer does not contain expected keyword: {kw}")
        if "capital is paris" in (context or "").lower() and "paris" not in (answer or "").lower():
            return JudgeResult(self.name, 0.1, False, "Context implies Paris, but answer did not mention it.")
        return JudgeResult(self.name, 0.9, True, "Answer appears consistent with provided context/expectations.")
