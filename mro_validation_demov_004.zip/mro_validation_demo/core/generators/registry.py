from __future__ import annotations

import importlib
import pkgutil
from dataclasses import dataclass
from typing import Dict, List

from mro_validation_sdk.generators import BaseGenerator


@dataclass
class GeneratorDiscovery:
    generators: Dict[str, BaseGenerator]
    errors: List[str]


def _load_package(package: str):
    try:
        return importlib.import_module(package)
    except Exception as exc:
        if package == "generators":
            try:
                return importlib.import_module("mro_validation_demo.generators")
            except Exception as exc2:
                raise ImportError(f"Failed to import generators package '{package}': {exc} | fallback: {exc2}") from exc2
        raise ImportError(f"Failed to import generators package '{package}': {exc}") from exc


def discover_generators(package: str = "generators") -> GeneratorDiscovery:
    generators: Dict[str, BaseGenerator] = {}
    errors: List[str] = []

    try:
        pkg = _load_package(package)
    except Exception as exc:  # pragma: no cover
        return GeneratorDiscovery(generators={}, errors=[str(exc)])

    for modinfo in pkgutil.iter_modules(pkg.__path__, pkg.__name__ + "."):
        if not modinfo.ispkg:
            continue
        if modinfo.name.endswith(".__pycache__"):
            continue
        module_name = modinfo.name + ".generator"
        try:
            module = importlib.import_module(module_name)
            if not hasattr(module, "GENERATOR"):
                errors.append(f"{module_name}: missing GENERATOR export")
                continue
            gen_obj = getattr(module, "GENERATOR")
            if isinstance(gen_obj, type):
                gen_obj = gen_obj()
            if not isinstance(gen_obj, BaseGenerator):
                errors.append(f"{module_name}: GENERATOR is not a BaseGenerator")
                continue
            gen_id = getattr(gen_obj, "generator_id", None)
            if not gen_id:
                errors.append(f"{module_name}: missing generator_id")
                continue
            if gen_id in generators:
                errors.append(f"{module_name}: duplicate generator_id '{gen_id}'")
                continue

            try:
                schema = gen_obj.config_schema()
                fields = schema.get("fields") if isinstance(schema, dict) else None
                if fields is None or not isinstance(fields, list):
                    errors.append(f"{module_name}: config_schema missing fields list")
            except Exception as exc:
                errors.append(f"{module_name}: config_schema failed ({type(exc).__name__}: {exc})")

            generators[str(gen_id)] = gen_obj
        except Exception as exc:
            errors.append(f"{module_name}: import failed ({type(exc).__name__}: {exc})")

    return GeneratorDiscovery(generators=generators, errors=errors)


_DISCOVERY = discover_generators("generators")
GENERATOR_REGISTRY = _DISCOVERY.generators
GENERATOR_LOAD_ERRORS = _DISCOVERY.errors
