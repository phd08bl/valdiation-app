from __future__ import annotations

import uuid
from typing import Any, Callable, Dict, List, Optional

from mro_validation_sdk.generators import BaseGenerator, GeneratorContext
from mro_validation_sdk.scenarios import ScenarioCase


class WrappedGenerator(BaseGenerator):
    def __init__(
        self,
        *,
        generator_id: str,
        name: str,
        description: str,
        supported_system_types: set[str],
        supported_objectives: set[str],
        base_callable: Callable[[List[Dict[str, Any]], Dict[str, Any]], List[Any]],
        default_objectives: Optional[Dict[str, Any]] = None,
        default_tags: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.generator_id = generator_id
        self.name = name
        self.description = description
        self.supported_system_types = supported_system_types
        self.supported_objectives = supported_objectives
        self._callable = base_callable
        self._default_objectives = default_objectives or {}
        self._default_tags = default_tags or {}
        self._metadata = metadata or {}

    def generate(self, seed_cases: List[ScenarioCase], cfg: Dict[str, Any], ctx: GeneratorContext) -> List[ScenarioCase]:
        seed_inputs = [c.inputs for c in seed_cases]
        outputs = self._callable(seed_inputs, cfg)
        cases: List[ScenarioCase] = []
        for out in outputs or []:
            if isinstance(out, ScenarioCase):
                cases.append(out)
                continue
            if isinstance(out, dict):
                inputs = out.get("inputs") if "inputs" in out else out
            else:
                inputs = {"user_input": str(out)}
            cases.append(
                ScenarioCase(
                    case_id=f"case_{uuid.uuid4().hex[:10]}",
                    system_type=ctx.system_type,
                    interaction_type=str(cfg.get("interaction_type") or "single_turn"),
                    inputs=dict(inputs or {}),
                    source_examples=[s for s in (cfg.get("source_examples") or [])],
                    objectives=dict(cfg.get("objectives") or self._default_objectives),
                    tags=dict(cfg.get("tags") or self._default_tags),
                    difficulty=cfg.get("difficulty"),
                    expected_behavior=cfg.get("expected_behavior"),
                    attachments=cfg.get("attachments"),
                    approved_for_validation=bool(cfg.get("approved_for_validation", True)),
                    metadata={"wrapped_generator": True, **self._metadata},
                )
            )
        return cases

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "interaction_type", "type": "text", "label": "Interaction type"},
                {"key": "approved_for_validation", "type": "bool", "label": "Approved for validation"},
            ]
        }


def wrap_generator(
    *,
    generator_id: str,
    name: str,
    description: str,
    supported_system_types: set[str],
    supported_objectives: set[str],
    base_callable: Callable[[List[Dict[str, Any]], Dict[str, Any]], List[Any]],
    default_objectives: Optional[Dict[str, Any]] = None,
    default_tags: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> BaseGenerator:
    return WrappedGenerator(
        generator_id=generator_id,
        name=name,
        description=description,
        supported_system_types=supported_system_types,
        supported_objectives=supported_objectives,
        base_callable=base_callable,
        default_objectives=default_objectives,
        default_tags=default_tags,
        metadata=metadata,
    )
