from __future__ import annotations
from pathlib import Path
import datetime
import json
import zipfile
from typing import List, Optional

from .store import list_traces_for_run, get_trace, get_run
from . import config as app_config
from .discovery import discover_tools

def generate_report_md(
    run_id: str,
    output_dir: Optional[str] = None,
    db_path: Optional[str] = None,
    selected_trace_ids: Optional[List[str]] = None,
) -> str:
    output_dir = output_dir or app_config.reports_dir()
    db_path = db_path or app_config.db_path()
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    run = get_run(run_id, db_path=db_path)
    run_meta = run.get("run_metadata") or {}
    project_id = run.get("project_id", "Unknown")
    system_type = run_meta.get("system_type", "Unknown")
    access_mode = run_meta.get("access_mode", "Unknown")
    selected_tools = run_meta.get("selected_tools") or []
    adapter_id = run_meta.get("adapter_id", "Unknown")
    discovery = discover_tools("tools")
    tools_registry = discovery.tools

    traces = list_traces_for_run(run_id, db_path=db_path)

    if selected_trace_ids:
        selected_set = set(selected_trace_ids)
        traces = [t for t in traces if t["trace_id"] in selected_set]

    total = len(traces)
    fails = sum(1 for t in traces if t.get("pass_fail") == "FAIL")
    passes = total - fails

    ts = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    path = Path(output_dir) / f"validation_report_{run_id}.md"

    lines: List[str] = []
    lines += ["# MRO GenAI Validation Report (Demo)", ""]
    lines += [f"- **Project ID:** {project_id}",
              f"- **Run ID:** {run_id}",
              f"- **Generated:** {ts}",
              f"- **System Type:** {system_type}",
              f"- **Access Mode:** {access_mode}",
              f"- **Adapter Used:** {adapter_id}",
              f"- **Included traces:** {total}",
              f"- **Pass:** {passes}  |  **Fail:** {fails}", ""]

    lines += ["## Scope (tools + coverage)", ""]
    lines += ["| Tool ID | Name | Coverage | Notes |",
              "|---|---|---|---|"]
    for tool_id in selected_tools:
        tool = tools_registry.get(tool_id)
        if not tool:
            lines.append(f"| {tool_id} | (missing) | unknown | - |")
            continue
        name = getattr(tool, "name", tool_id)
        cov = "unknown"
        note = ""
        try:
            cov = tool.coverage_status(system_type, access_mode)
        except Exception:
            cov = "unknown"
        try:
            note = tool.coverage_notes(system_type, access_mode) or ""
        except Exception:
            note = ""
        lines.append(f"| {tool_id} | {name} | {cov} | {note} |")
    lines.append("")

    lines += ["## Coverage Limitations", ""]
    for tool_id in selected_tools:
        tool = tools_registry.get(tool_id)
        if not tool:
            continue
        try:
            cov = tool.coverage_status(system_type, access_mode)
        except Exception:
            cov = "unknown"
        if cov == "available":
            continue
        try:
            note = tool.coverage_notes(system_type, access_mode) or ""
        except Exception:
            note = ""
        lines.append(f"- {tool_id}: {cov} {('- ' + note) if note else ''}")
    if lines[-1] != "":
        lines.append("")

    lines += ["## Results (summary)", ""]
    lines += ["| Trace ID | Score | Pass/Fail | Input (preview) |",
              "|---|---:|---|---|"]
    for t in traces[:200]:
        preview = (t.get("input_preview") or "").replace("|", " ")
        lines.append(f"| {t['trace_id']} | {float(t['overall_score']):.3f} | {t['pass_fail']} | {preview} |")
    lines.append("")

    lines += ["## Evidence (example failures)", ""]
    fail_count = 0
    for t in traces:
        if t.get("pass_fail") != "FAIL":
            continue
        fail_count += 1
        detail = get_trace(t["trace_id"], db_path=db_path)
        trace = detail.get("trace") or {}
        evidence = trace.get("evidence") or {}
        record = trace.get("record") or {}
        input_text = evidence.get("request", {}).get("user_input") or record.get("input") or record.get("question") or ""
        output_text = evidence.get("response", {}).get("output_text") or record.get("model_output") or record.get("answer") or ""
        lines += [f"### Trace {t['trace_id']}",
                  f"- Score: {detail.get('overall_score')}",
                  f"- Input: {input_text}",
                  f"- Output: {output_text}",
                  "",
                  "**Evaluations:**"]
        for e in detail.get("evaluations", [])[:30]:
            ev = e.get("evaluation") or {}
            lines.append(f"- {e.get('tool_id','')}: score={ev.get('overall_score')}, pass_fail={ev.get('pass_fail')}, metrics={ev.get('metrics')}")
        lines.append("")
        if fail_count >= 5:
            break

    lines += ["## Evidence Pack (selected payloads)", ""]
    for t in traces[:50]:
        detail = get_trace(t["trace_id"], db_path=db_path)
        evals = detail.get("evaluations") or []
        if not evals:
            continue
        lines.append(f"### Trace {t['trace_id']}")
        for e in evals:
            ev = e.get("evaluation") or {}
            evidence = ev.get("evidence") or []
            if evidence:
                lines.append(f"- Tool `{e.get('tool_id','')}` evidence: {json.dumps(evidence)}")
        lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")
    return str(path)

def export_evidence_pack(
    run_id: str,
    output_dir: Optional[str] = None,
    db_path: Optional[str] = None,
    selected_trace_ids: Optional[List[str]] = None,
) -> str:
    output_dir = output_dir or app_config.reports_dir()
    db_path = db_path or app_config.db_path()
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    report_path = generate_report_md(run_id, output_dir=output_dir, db_path=db_path, selected_trace_ids=selected_trace_ids)
    traces = list_traces_for_run(run_id, db_path=db_path)

    if selected_trace_ids:
        selected_set = set(selected_trace_ids)
        traces = [t for t in traces if t["trace_id"] in selected_set]

    zip_path = Path(output_dir) / f"evidence_pack_{run_id}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.write(report_path, arcname=Path(report_path).name)
        for t in traces:
            detail = get_trace(t["trace_id"], db_path=db_path)
            z.writestr(f"traces/{t['trace_id']}.json", json.dumps(detail, indent=2))
    return str(zip_path)
