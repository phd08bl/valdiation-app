from __future__ import annotations
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from .store import init_db, insert_project, list_projects as _list_projects
from . import config as app_config


@dataclass
class Project:
    project_id: str
    name: str
    description: str


def create_project(name: str, description: str, db_path: Optional[str] = None) -> Project:
    db_path = db_path or app_config.db_path()
    init_db(db_path)
    pid = f"proj_{uuid.uuid4().hex[:10]}"
    p = Project(project_id=pid, name=name, description=description)
    persist_project(p, db_path=db_path)
    return p


def persist_project(project: Project, db_path: Optional[str] = None) -> None:
    db_path = db_path or app_config.db_path()
    insert_project(project.project_id, project.name, project.description, db_path=db_path)


def list_projects(db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    db_path = db_path or app_config.db_path()
    init_db(db_path)
    return _list_projects(db_path=db_path)
