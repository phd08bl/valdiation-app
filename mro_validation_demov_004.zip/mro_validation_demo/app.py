﻿
import json
import os
import random
import sys
import uuid
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

import gradio as gr

from core import config as app_config
from core.project import create_project, list_projects
from core.runner import (
    run_suite,
    run_tool_standalone,
    TOOL_REGISTRY,
    TOOL_REGISTRY_OBJ,
    TOOL_LOAD_ERRORS,
    discover_tools,
    discover_adapters,
    ADAPTER_REGISTRY,
    ADAPTER_LOAD_ERRORS,
    list_runs,
    list_traces_for_run,
)
from core.store import (
    get_trace,
    delete_run,
    delete_traces,
    delete_project,
    get_run,
    upsert_run,
    upsert_tool_config,
    get_tool_config,
    upsert_tool_preset,
    list_tool_presets,
    get_tool_preset_config,
    get_active_tool_preset_config,
    delete_tool_preset,
)
from core.report import generate_report_md, export_evidence_pack
from mro_validation_sdk.evidence import EvidenceBundle
from mro_validation_sdk.scenarios import ScenarioCase, ScenarioDataset, iso_utc_now
from core.datasets.store import (
    create_dataset,
    list_datasets as list_scenario_datasets,
    load_dataset as load_scenario_dataset,
    duplicate_dataset as duplicate_scenario_dataset,
    delete_dataset as delete_scenario_dataset,
    export_dataset as export_scenario_dataset,
)
from core.generators.registry import (
    GENERATOR_REGISTRY,
    GENERATOR_LOAD_ERRORS,
    discover_generators,
)


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(BASE_DIR)
for _p in (BASE_DIR, PARENT_DIR):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)
DB_PATH = app_config.db_path()
DATASET_PATH = app_config.dataset_path()
FIXTURES_DIR = app_config.fixtures_dir()

SYSTEM_TYPES = [
    "Foundation LLM (3rd-party)",
    "RAG",
    "Agentic AI",
    "Multi-Agent System",
    "Low/No-code Agent",
]
ACCESS_MODES = ["black_box", "traced", "white_box"]
SCENARIO_SYSTEM_TYPES = {
    "Foundation LLM": "foundation_llm",
    "RAG": "rag",
    "Agentic": "agentic",
    "Multi-Agent": "multi_agent",
}

MODULE_GROUPS_ALL = {
    "Quality, Correctness & Effectiveness": [
        "faithfulness_hallucination",
        "accuracy_groundtruth",
        "answer_relevance",
        "logic_coherence",
        "summarization_faithfulness",
        "summarization_conciseness",
        "efficacy",
    ],
    "Safety & Policy Guardrails": [
        "toxicity_hap",
        "bias_fairness",
    ],
    "Security & Red-Teaming": [
        "pii_confidential_leakage",
        "jailbreak_testing",
        "prompt_injection",
        "data_exfiltration_probe",
    ],
    "RAG & Knowledge Evaluation": [
        "context_retrieval_precision",
        "context_retrieval_recall",
    ],
    "Agent Planning, Control & Tool-Use": [
        "tool_selection",
        "tool_argument_parsing",
        "reasoning_correctness",
        "instruction_adherence",
    ],
    "Multi-Agent Dynamics & Emergent Behaviour": [
        "cross_agent_logic_coherence",
        "agent_conflict",
        "collusion_detection",
        "deadlock_loop_detection",
        "emergent_unsafe_behavior",
    ],
    "Observability, Monitoring & Evidence": [
        "trace_logic_coherence",
        "execution_trace_span_recorder",
        "validation_run_logbook",
        "evidence_pack_generator",
        "audit_ready_artifact_builder",
    ],
    "System Performance, Cost & Efficiency": [
        "efficiency_score",
        "latency_monitor",
        "token_usage",
        "cost_per_task",
        "tool_call_efficiency",
    ],
    "Model Lifecycle, Change Governance & Vendor Assurance": [
        "regulatory_compliance_validator",
        "vendor_model_change_check",
        "material_change_revalidation_trigger",
        "model_change_impact_risk_assessment",
        "model_retirement_evidence_validator",
    ],
}

BADGE = {"available": "✅", "limited": "⚠️", "unavailable": "❌"}
DEFAULT_SYSTEM = "Agentic AI"
DEFAULT_ACCESS = "traced"
SCHEMA_SLOTS = 12


def _ensure_dataset():
    if not os.path.exists(DATASET_PATH):
        raise FileNotFoundError(f"Missing dataset: {DATASET_PATH}")


def _ensure_fixtures():
    if not os.path.exists(FIXTURES_DIR):
        raise FileNotFoundError(f"Missing fixtures directory: {FIXTURES_DIR}")


def _adapter_choices(access_mode: str):
    choices = []
    label_map = {}
    for adapter_id, adapter in ADAPTER_REGISTRY.items():
        try:
            supported = adapter.supported_access_modes() or set()
        except Exception:
            supported = set()
        if access_mode and supported and access_mode not in supported:
            continue
        label = f"{adapter_id} - {getattr(adapter, 'name', adapter_id)}"
        choices.append(label)
        label_map[label] = adapter_id
    return choices, label_map


def ui_adapter_choices(access_mode):
    choices, label_map = _adapter_choices(access_mode)
    value = choices[0] if choices else None
    return gr.update(choices=choices, value=value), label_map


def _fixture_choices(access_mode: str):
    base = os.path.join(FIXTURES_DIR, access_mode)
    if not os.path.isdir(base):
        return [], {}
    files = [f for f in os.listdir(base) if f.lower().endswith('.json')]
    files.sort()
    label_map = {f: os.path.join(base, f) for f in files}
    return files, label_map


def ui_fixture_choices(access_mode):
    choices, label_map = _fixture_choices(access_mode)
    value = choices[0] if choices else None
    return gr.update(choices=choices, value=value), label_map


def _generator_choices():
    choices = []
    label_map = {}
    for gen_id, gen in GENERATOR_REGISTRY.items():
        label = f"{gen_id} - {getattr(gen, 'name', gen_id)}"
        choices.append(label)
        label_map[label] = gen_id
    choices.sort()
    return choices, label_map


def ui_refresh_generators():
    discovery = discover_generators("generators")
    GENERATOR_REGISTRY.clear()
    GENERATOR_REGISTRY.update(discovery.generators)
    GENERATOR_LOAD_ERRORS.clear()
    GENERATOR_LOAD_ERRORS.extend(discovery.errors)
    choices, label_map = _generator_choices()
    value = choices[0] if choices else None
    return gr.update(choices=choices, value=value), label_map, GENERATOR_LOAD_ERRORS


def _scenario_system_type(label: str) -> str:
    return SCENARIO_SYSTEM_TYPES.get(label, "foundation_llm")


def _parse_seed_cases(seed_text: str, system_type: str, objectives: Dict[str, Any], tags: Dict[str, Any]) -> List[ScenarioCase]:
    seeds = []
    lines = [l.strip() for l in (seed_text or "").splitlines() if l.strip()]
    for idx, line in enumerate(lines):
        seeds.append(
            ScenarioCase(
                case_id=f"seed_{idx+1}",
                system_type=system_type,
                interaction_type="single_turn",
                inputs={"user_input": line},
                source_examples=[line],
                objectives=objectives,
                tags=tags,
                approved_for_validation=True,
                metadata={},
            )
        )
    return seeds


def _build_objectives(quality, policy, security, rag_grounding, agent_planning) -> Dict[str, Any]:
    return {
        "quality": bool(quality),
        "policy": bool(policy),
        "security": bool(security),
        "rag_grounding": bool(rag_grounding),
        "agent_planning": bool(agent_planning),
    }


def _build_tags(topic: str, persona: str, channel: str, risk_focus: str) -> Dict[str, Any]:
    tags: Dict[str, Any] = {}
    if topic:
        tags["topic"] = topic.strip()
    if persona:
        tags["persona"] = persona.strip()
    if channel:
        tags["channel"] = channel.strip()
    risks = [r.strip().lower() for r in (risk_focus or "").split(",") if r.strip()]
    if risks:
        tags["risk"] = risks
    return tags


def _case_preview_rows(cases: List[ScenarioCase]) -> List[List[Any]]:
    rows = []
    for c in cases:
        rows.append(
            [
                c.case_id,
                json.dumps(c.inputs, ensure_ascii=True),
                json.dumps(c.tags, ensure_ascii=True),
                json.dumps(c.objectives, ensure_ascii=True),
                json.dumps(c.source_examples, ensure_ascii=True),
            ]
        )
    return rows


def _case_curation_rows(cases: List[ScenarioCase]) -> List[List[Any]]:
    rows = []
    for c in cases:
        rows.append(
            [
                c.case_id,
                "true" if c.approved_for_validation else "false",
                json.dumps(c.inputs, ensure_ascii=True),
                json.dumps(c.tags, ensure_ascii=True),
                json.dumps(c.objectives, ensure_ascii=True),
            ]
        )
    return rows


def _tag_stats(cases: List[ScenarioCase]) -> Dict[str, Any]:
    stats: Dict[str, Any] = {"topics": {}, "personas": {}, "channels": {}, "risks": {}}
    for c in cases:
        tags = c.tags or {}
        topic = tags.get("topic")
        persona = tags.get("persona")
        channel = tags.get("channel")
        risks = tags.get("risk") or []
        if topic:
            stats["topics"][topic] = stats["topics"].get(topic, 0) + 1
        if persona:
            stats["personas"][persona] = stats["personas"].get(persona, 0) + 1
        if channel:
            stats["channels"][channel] = stats["channels"].get(channel, 0) + 1
        for r in risks:
            stats["risks"][r] = stats["risks"].get(r, 0) + 1
    return stats


def ui_generate_scenarios(
    project_id,
    seed_text,
    system_type_label,
    objective_quality,
    objective_policy,
    objective_security,
    objective_rag_grounding,
    objective_agent_planning,
    topic,
    persona,
    channel,
    generator_label,
    generator_label_map,
    backend_id,
    num_cases,
    diversify,
    expand,
    risk_focus,
    dedupe_threshold,
    seed_value,
):
    if not project_id:
        return "Select a project first.", [], [], {}, {}, {}
    if not seed_text or not seed_text.strip():
        return "Provide seed examples first.", [], [], {}, {}, {}
    generator_id = generator_label_map.get(generator_label) if generator_label_map else None
    generator = GENERATOR_REGISTRY.get(generator_id) if generator_id else None
    if generator is None:
        return "Select a generator first.", [], [], {}, {}, {}

    objectives = _build_objectives(
        objective_quality,
        objective_policy,
        objective_security,
        objective_rag_grounding,
        objective_agent_planning,
    )
    tags = _build_tags(topic, persona, channel, risk_focus)
    system_type = _scenario_system_type(system_type_label)

    seed_cases = _parse_seed_cases(seed_text, system_type, objectives, tags)
    cfg = {
        "num_cases": int(num_cases) if num_cases else 12,
        "diversify": bool(diversify),
        "expand": bool(expand),
        "risk_focus": risk_focus or "",
        "dedupe_threshold": float(dedupe_threshold) if dedupe_threshold else 0.86,
        "seed": int(seed_value) if seed_value else 42,
        "objectives": objectives,
        "tags": tags,
        "approved_for_validation": True,
        "backend_id": backend_id,
    }
    ctx = generator_ctx(project_id, system_type, backend_id)
    try:
        cases = generator.generate(seed_cases, cfg, ctx)
    except Exception as exc:
        return f"Generation failed: {exc}", [], [], {}, {}, {}

    preview = _case_preview_rows(cases)
    curation = _case_curation_rows(cases)
    stats = {
        "dedupe": ctx.stats,
        "tags": _tag_stats(cases),
        "total": len(cases),
    }
    return "Generated scenarios.", preview, curation, stats, [c.to_dict() for c in cases], cfg


def generator_ctx(project_id: str, system_type: str, backend_id: str):
    from mro_validation_sdk.generators import GeneratorContext
    return GeneratorContext(
        project_id=project_id,
        system_type=system_type,
        backend_id=backend_id,
        run_id=f"gen_{uuid.uuid4().hex[:8]}",
    )


def ui_apply_curation(curation_rows, cases_state):
    cases_state = cases_state or []
    case_map = {c.get("case_id"): c for c in cases_state if isinstance(c, dict)}
    updated = []
    for row in curation_rows or []:
        if not row or len(row) < 5:
            continue
        case_id = row[0]
        existing = case_map.get(case_id) or {}
        try:
            inputs = json.loads(row[2]) if row[2] else {}
        except Exception:
            inputs = existing.get("inputs") or {}
        try:
            tags = json.loads(row[3]) if row[3] else {}
        except Exception:
            tags = existing.get("tags") or {}
        try:
            objectives = json.loads(row[4]) if row[4] else {}
        except Exception:
            objectives = existing.get("objectives") or {}
        approved = str(row[1]).strip().lower() in ("true", "1", "yes", "y")
        merged = {
            **existing,
            "inputs": inputs,
            "tags": tags,
            "objectives": objectives,
            "approved_for_validation": approved,
        }
        updated.append(merged)
    return "Curation applied.", updated, _case_curation_rows([ScenarioCase.from_dict(c) for c in updated])


def ui_delete_cases(delete_ids_text, cases_state):
    ids = {s.strip() for s in (delete_ids_text or "").replace("\n", ",").split(",") if s.strip()}
    kept = []
    for c in (cases_state or []):
        if c.get("case_id") not in ids:
            kept.append(c)
    cases = [ScenarioCase.from_dict(c) for c in kept]
    return f"Deleted {len(ids)} cases.", kept, _case_preview_rows(cases), _case_curation_rows(cases)


def ui_save_dataset(
    project_id,
    dataset_name,
    dataset_description,
    cases_state,
    generator_label,
    generator_label_map,
    backend_id,
    generator_cfg,
):
    if not project_id:
        return "Select a project first.", ""
    if not dataset_name:
        return "Provide a dataset name.", ""
    cases = [ScenarioCase.from_dict(c) for c in (cases_state or [])]
    if not cases:
        return "Generate or load cases first.", ""
    generator_id = generator_label_map.get(generator_label) if generator_label_map else None
    dataset = ScenarioDataset(
        dataset_id=f"ds_{uuid.uuid4().hex[:10]}",
        project_id=project_id,
        name=dataset_name,
        description=dataset_description or "",
        created_ts=iso_utc_now(),
        cases=cases,
        generator_config={
            "generator_id": generator_id,
            "backend_id": backend_id,
            "params": generator_cfg or {},
        },
        lineage={"source": "scenario_studio"},
    )
    dataset_id = create_dataset(dataset, db_path=DB_PATH)
    return f"Saved dataset {dataset_id} with {len(cases)} cases.", dataset_id


def _scenario_dataset_choices(project_id: str):
    if not project_id:
        return [], {}
    rows = list_scenario_datasets(project_id, db_path=DB_PATH)
    choices = []
    label_map = {}
    for r in rows:
        label = f"{r['name']} ({r['dataset_id']}) | cases={r.get('case_count', 0)}"
        choices.append(label)
        label_map[label] = r["dataset_id"]
    return choices, label_map


def ui_refresh_scenario_datasets(project_id):
    choices, label_map = _scenario_dataset_choices(project_id)
    value = choices[0] if choices else None
    return gr.update(choices=choices, value=value), label_map


def _filter_scenario_cases(
    cases: List[ScenarioCase],
    approved_only: bool,
    topic: str,
    persona: str,
    channel: str,
    risk_focus: str,
    objective_quality: bool,
    objective_policy: bool,
    objective_security: bool,
    objective_rag_grounding: bool,
    objective_agent_planning: bool,
    max_cases: Optional[int],
) -> List[ScenarioCase]:
    risks = [r.strip().lower() for r in (risk_focus or "").split(",") if r.strip()]
    required_objectives = {
        "quality": bool(objective_quality),
        "policy": bool(objective_policy),
        "security": bool(objective_security),
        "rag_grounding": bool(objective_rag_grounding),
        "agent_planning": bool(objective_agent_planning),
    }
    out = []
    for c in cases:
        if approved_only and not c.approved_for_validation:
            continue
        tags = c.tags or {}
        if topic and tags.get("topic") != topic:
            continue
        if persona and tags.get("persona") != persona:
            continue
        if channel and tags.get("channel") != channel:
            continue
        if risks:
            case_risks = [str(r).lower() for r in (tags.get("risk") or [])]
            if not any(r in case_risks for r in risks):
                continue
        objectives = c.objectives or {}
        if any(required_objectives[k] and not objectives.get(k, False) for k in required_objectives):
            continue
        out.append(c)
        if max_cases and len(out) >= max_cases:
            break
    return out


def _adapter_id_from_label(adapter_label, label_map, access_mode):
    if label_map and adapter_label in label_map:
        return label_map.get(adapter_label)
    return access_mode


def _project_choices():
    ps = list_projects(db_path=DB_PATH)
    return {f"{p['name']}  ({p['project_id']})": p["project_id"] for p in ps}


def _project_by_id(project_id: str):
    for p in list_projects(db_path=DB_PATH):
        if p.get("project_id") == project_id:
            return p
    return {}


def _run_choices(project_id: str):
    if not project_id:
        return {}
    runs = list_runs(project_id, db_path=DB_PATH)
    out = {}
    for r in runs:
        meta = r.get("run_metadata", {}) or {}
        st = meta.get("system_type", "?")
        am = meta.get("access_mode", "?")
        tools = meta.get("selected_tools", [])
        label = f"{r['run_id']} | {r['status']} | pass_rate={r['pass_rate']:.2f} | {st}/{am} | tools={len(tools)}"
        out[label] = r["run_id"]
    return out


def ui_create_project(name, description):
    p = create_project(name=name, description=description, db_path=DB_PATH)
    return f"✅ Created project: {p.project_id}", p.project_id


def ui_refresh_projects():
    choices = _project_choices()
    labels = list(choices.keys())
    default_label = labels[0] if labels else None
    default_pid = choices.get(default_label) if default_label else None
    return gr.update(choices=labels, value=default_label), default_pid


def ui_select_project(project_label):
    return _project_choices().get(project_label)


def ui_sync_project_label(project_id):
    return project_id or ""


def ui_project_status(project_id):
    if not project_id:
        return "No project selected yet."
    return f"✅ Active Project: {project_id}"


def ui_project_banner(project_id, last_action):
    pid = project_id or "None"
    action = last_action or "None"
    return f"✅ Active Project: {pid}  |  📝 Last Action: {action}"


def ui_project_summary(project_id):
    if not project_id:
        return (
            '<div class="summary-card">'
            '<div class="summary-title">🔒 Active Validation Project</div>'
            '<div class="helper">All tabs are automatically scoped to the active project.</div>'
            '<div class="muted">No active project selected.</div>'
            '<div class="helper">Select or create a project to define the validation scope.</div>'
            "</div>"
        )
    p = _project_by_id(project_id) or {}
    name = p.get("name") or "—"
    desc = p.get("description") or "—"
    return (
        '<div class="summary-card">'
        '<div class="summary-title">🔒 Active Validation Project</div>'
        '<div class="helper">All tabs are automatically scoped to the active project.</div>'
        f'<div><strong>Project ID:</strong> {project_id}</div>'
        f'<div><strong>Project Name:</strong> {name}</div>'
        f'<div><strong>Description:</strong> {desc}</div>'
        '<div class="helper">All validation runs, results, traces, and reports are scoped to the active project.</div>'
        "</div>"
    )


def ui_project_id_autofill(project_id):
    return project_id or ""


def ui_project_pill(project_id, last_action):
    pid = project_id or "None"
    action = last_action or "None"
    return f'<div class="pill-card">Active Project: {pid} | Last action: {action}</div>'


def ui_toggle_delete_preset(preset_name, confirm_ack):
    return gr.update(interactive=bool(preset_name) and bool(confirm_ack))


def ui_toggle_delete_actions(confirm_ack):
    return gr.update(interactive=bool(confirm_ack)), gr.update(interactive=bool(confirm_ack))


def ui_open_delete_panel(project_id):
    if not project_id:
        return gr.update(visible=False), "⚠️ Select a project before deleting.", "", "", False
    p = _project_by_id(project_id) or {}
    name = p.get("name") or "Unknown"
    confirm_html = (
        '<div class="warning-box">'
        f"<div><strong>Project Name:</strong> {name}</div>"
        f"<div><strong>Project ID:</strong> {project_id}</div>"
        '<div class="warning-text">Deleting a project will permanently remove all validation runs, traces, and evidence associated with it.</div>'
        "</div>"
    )
    return gr.update(visible=True), "", confirm_html, "", False


def ui_cancel_delete_panel():
    return gr.update(visible=False), "ℹ️ Deletion cancelled."


def ui_confirm_delete_project(project_id, confirm_name, confirm_ack):
    if not project_id:
        return gr.update(visible=False), "⚠️ No project selected for deletion.", None, gr.update(), ui_project_summary(None), ""
    p = _project_by_id(project_id) or {}
    expected_name = (p.get("name") or "").strip()
    if not confirm_ack and (confirm_name or "").strip() != expected_name:
        return (
            gr.update(visible=True),
            "⚠️ Type the project name or acknowledge irreversible deletion to proceed.",
            project_id,
            gr.update(),
            ui_project_summary(project_id),
            project_id,
        )

    delete_project(project_id, db_path=DB_PATH)
    choices = _project_choices()
    labels = list(choices.keys())
    return (
        gr.update(visible=False),
        f"✅ Deleted project: {expected_name} ({project_id}). Select or create a new project.",
        None,
        gr.update(choices=labels, value=None),
        ui_project_summary(None),
        "",
    )


def ui_toggle_api_url(access_mode):
    return gr.update(visible=(access_mode == "black_box"))


def ui_toggle_dataset_source(dataset_source: str):
    return gr.update(visible=(dataset_source == "Fixtures")), gr.update(visible=(dataset_source == "Scenario Datasets"))


def _tool_path(tool_id: str) -> str:
    return os.path.join(BASE_DIR, "tools", tool_id, "tool.py")


def _tool_mtime(tool_id: str) -> float:
    try:
        return os.path.getmtime(_tool_path(tool_id))
    except Exception:
        return 0.0


def _registry_summary(tool_ids, new_tools, last_refresh):
    return f"Tools loaded: {len(tool_ids)} | New since last refresh: {len(new_tools)} | Last refresh: {last_refresh}"


def _module_group_counts():
    rows = []
    for group, tool_ids in MODULE_GROUPS_ALL.items():
        rows.append([group, len(tool_ids)])
    rows.sort(key=lambda r: r[0])
    return rows


def _module_group_counts_md():
    rows = _module_group_counts()
    lines = ["| module_group | tool_count |", "|---|---:|"]
    for group, count in rows:
        lines.append(f"| **{group}** | {count} |")
    return "\n".join(lines)


def _coverage_counts(system_type: str, access_mode: str):
    counts = {"available": 0, "limited": 0, "unavailable": 0}
    for tool_id in TOOL_REGISTRY_OBJ.keys():
        st = tool_coverage_status(tool_id, system_type, access_mode)
        counts[st] = counts.get(st, 0) + 1
    return counts


def tool_coverage_status(tool_id: str, system_type: str, access_mode: str) -> str:
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    if tool is None:
        return "unavailable"
    try:
        status = tool.coverage_status(system_type, access_mode)
        if status not in ("available", "limited", "unavailable"):
            return "available"
        return status
    except Exception:
        return "available"


def module_status(module_name: str, system_type: str, access_mode: str) -> str:
    tool_ids = MODULE_GROUPS_ALL.get(module_name, [])
    if not tool_ids:
        return "available"
    statuses = [tool_coverage_status(t, system_type, access_mode) for t in tool_ids]
    if any(s == "available" for s in statuses):
        return "available"
    if any(s == "limited" for s in statuses):
        return "limited"
    return "unavailable"


def ui_status_legend():
    return "Legend: ✅ available | ⚠️ limited (proxy/heuristic) | ❌ unavailable with selected access"


def ui_module_group_choices():
    return ["All"] + list(MODULE_GROUPS_ALL.keys())


def tools_in_module_group(module_group: str):
    if not module_group or module_group == "All":
        s = set()
        out = []
        for _, tool_ids in MODULE_GROUPS_ALL.items():
            for tid in tool_ids:
                if tid not in s:
                    s.add(tid)
                    out.append(tid)
        return out
    return MODULE_GROUPS_ALL.get(module_group, [])


def ui_filtered_tool_ids(system_type: str, access_mode: str, module_group: str):
    tool_ids = tools_in_module_group(module_group)
    out = []
    for tid in tool_ids:
        if tid not in TOOL_REGISTRY_OBJ:
            continue
        cov = tool_coverage_status(tid, system_type, access_mode)
        if cov == "unavailable":
            continue
        out.append(tid)
    return out


def ui_filter_modules_with_badges(system_type, access_mode, current_selection):
    selectable = []
    label_to_key = {}
    for m in MODULE_GROUPS_ALL.keys():
        st = module_status(m, system_type, access_mode)
        if st == "unavailable":
            continue
        lbl = f"{BADGE[st]} {m}"
        selectable.append(lbl)
        label_to_key[lbl] = m

    kept = [lbl for lbl in (current_selection or []) if lbl in label_to_key]
    value = kept if kept else selectable
    return gr.update(choices=selectable, value=value), label_to_key


def ui_filter_tools_with_badges(system_type, access_mode, selected_module_labels, current_tool_labels, module_label_map):
    selected_modules = []
    for lbl in (selected_module_labels or []):
        key = module_label_map.get(lbl)
        if key:
            selected_modules.append(key)

    tool_keys = []
    for m in selected_modules:
        tool_keys += MODULE_GROUPS_ALL.get(m, [])
    seen, uniq = set(), []
    for t in tool_keys:
        if t not in seen:
            seen.add(t)
            uniq.append(t)

    selectable = []
    label_to_tool = {}
    for t in uniq:
        st = tool_coverage_status(t, system_type, access_mode)
        if st == "unavailable":
            continue
        lbl = f"{BADGE[st]} {t} - {TOOL_REGISTRY.get(t,'')}"
        selectable.append(lbl)
        label_to_tool[lbl] = t

    kept = [lbl for lbl in (current_tool_labels or []) if lbl in label_to_tool]
    value = kept if kept else selectable
    return gr.update(choices=selectable, value=value), label_to_tool


def _initial_module_badges(system_type: str, access_mode: str):
    choices = []
    label_map = {}
    for m in MODULE_GROUPS_ALL.keys():
        st = module_status(m, system_type, access_mode)
        if st == "unavailable":
            continue
        lbl = f"{BADGE[st]} {m}"
        choices.append(lbl)
        label_map[lbl] = m
    return choices, label_map


def _initial_tool_badges(system_type: str, access_mode: str, module_labels, module_label_map):
    selected_modules = [module_label_map[lbl] for lbl in module_labels if lbl in module_label_map]
    tool_keys = []
    for m in selected_modules:
        tool_keys += MODULE_GROUPS_ALL.get(m, [])
    seen, uniq = set(), []
    for t in tool_keys:
        if t not in seen:
            seen.add(t)
            uniq.append(t)

    selectable = []
    label_to_tool = {}
    for t in uniq:
        st = tool_coverage_status(t, system_type, access_mode)
        if st == "unavailable":
            continue
        lbl = f"{BADGE[st]} {t} - {TOOL_REGISTRY.get(t,'')}"
        selectable.append(lbl)
        label_to_tool[lbl] = t
    return selectable, label_to_tool


def ui_refresh_modules_and_tools(system_type, access_mode, current_module_labels, current_tool_labels):
    module_choices, module_map = _initial_module_badges(system_type, access_mode)
    kept_modules = [lbl for lbl in (current_module_labels or []) if lbl in module_map]
    module_value = kept_modules if kept_modules else module_choices
    module_update = gr.update(choices=module_choices, value=module_value)

    tool_choices, tool_map = _initial_tool_badges(system_type, access_mode, module_value, module_map)
    kept_tools = [lbl for lbl in (current_tool_labels or []) if lbl in tool_map]
    tool_value = kept_tools if kept_tools else tool_choices
    tool_update = gr.update(choices=tool_choices, value=tool_value)
    return module_update, module_map, tool_update, tool_map


def ui_reload_registry_run(system_type, access_mode, current_module_labels, current_tool_labels, prev_tool_ids):
    tool_ids, summary, last_refresh, new_text, errs = ui_refresh_registry(prev_tool_ids)
    module_update, module_map, tool_update, tool_map = ui_refresh_modules_and_tools(
        system_type, access_mode, current_module_labels, current_tool_labels
    )
    return tool_ids, summary, last_refresh, new_text, errs, module_update, module_map, tool_update, tool_map

def ui_refresh_tools():
    reg, errs = discover_tools("tools")
    TOOL_REGISTRY_OBJ.clear()
    TOOL_REGISTRY_OBJ.update(reg)
    TOOL_REGISTRY.clear()
    TOOL_REGISTRY.update({tid: getattr(t, "description", "") for tid, t in TOOL_REGISTRY_OBJ.items()})
    TOOL_LOAD_ERRORS.clear()
    TOOL_LOAD_ERRORS.extend(errs)
    choices = sorted(list(TOOL_REGISTRY_OBJ.keys()))
    return gr.update(choices=choices, value=(choices[0] if choices else None)), errs


def ui_refresh_tools_filtered(system_type: str, access_mode: str, module_group: str):
    _dd, errs = ui_refresh_tools()
    filtered = ui_filtered_tool_ids(system_type, access_mode, module_group)
    return gr.update(choices=filtered, value=(filtered[0] if filtered else None)), errs


def ui_refresh_registry(prev_tool_ids):
    reg, errs = discover_tools("tools")
    TOOL_REGISTRY_OBJ.clear()
    TOOL_REGISTRY_OBJ.update(reg)
    TOOL_REGISTRY.clear()
    TOOL_REGISTRY.update({tid: getattr(t, "description", "") for tid, t in TOOL_REGISTRY_OBJ.items()})
    TOOL_LOAD_ERRORS.clear()
    TOOL_LOAD_ERRORS.extend(errs)
    tool_ids = sorted(list(TOOL_REGISTRY_OBJ.keys()))
    prev_set = set(prev_tool_ids or [])
    new_tools = sorted(list(set(tool_ids) - prev_set))
    last_refresh = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    summary = _registry_summary(tool_ids, new_tools, last_refresh)
    new_text = ", ".join(new_tools) if new_tools else "None"
    return tool_ids, summary, last_refresh, new_text, errs


def _apply_recency_filter(tool_ids, recency: str):
    if not recency or recency == "All":
        return tool_ids
    now = datetime.now(timezone.utc).timestamp()
    if recency == "Recent (24h)":
        cutoff = now - 24 * 3600
        return [t for t in tool_ids if _tool_mtime(t) >= cutoff]
    if recency == "Recent (7d)":
        cutoff = now - 7 * 24 * 3600
        return [t for t in tool_ids if _tool_mtime(t) >= cutoff]
    if recency == "Newest 5":
        ranked = sorted(tool_ids, key=_tool_mtime, reverse=True)
        return ranked[:5]
    return tool_ids


def ui_tool_catalog_rows(system_type: str, access_mode: str, module_group: str, search: str, tag: str, recency: str):
    search = (search or "").strip().lower()
    tag = (tag or "").strip().lower()
    rows = []
    module_group_tools = set(tools_in_module_group(module_group or "All"))
    module_group_tools = set(_apply_recency_filter(sorted(list(module_group_tools)), recency))
    for tool_id, tool in TOOL_REGISTRY_OBJ.items():
        if tool_id not in module_group_tools:
            continue
        try:
            md = tool.metadata() if hasattr(tool, "metadata") else {}
        except Exception:
            md = {}
        name = getattr(tool, "name", tool_id)
        status = (md.get("status") or "Experimental")
        tags = md.get("tags") or []
        limitations = md.get("limitations") or ""

        cov = tool_coverage_status(tool_id, system_type, access_mode)
        badge = BADGE[cov]
        note = ""
        if hasattr(tool, "coverage_notes"):
            try:
                note = tool.coverage_notes(system_type, access_mode) or ""
            except Exception:
                note = ""
        if cov != "available" and not note:
            note = limitations
        if cov == "limited" and not note:
            note = "Limited coverage (proxy/heuristic)."

        hay = f"{tool_id} {name} {status} {' '.join([str(t) for t in tags])}".lower()
        if search and search not in hay:
            continue
        if tag and tag not in " ".join([str(t).lower() for t in tags]):
            continue

        cov_label = f"{badge} {cov.title()}"
        rows.append([tool_id, name, status, ", ".join(tags), cov_label, note])

    rows.sort(key=lambda r: (0 if "Approved" in r[2] else 1, r[0]))
    return rows


def ui_catalog_tags():
    s = set()
    for tool in TOOL_REGISTRY_OBJ.values():
        try:
            md = tool.metadata() if hasattr(tool, "metadata") else {}
        except Exception:
            md = {}
        for t in (md.get("tags") or []):
            s.add(str(t))
    return sorted(list(s))


def ui_refresh_catalog(system_type: str, access_mode: str, module_group: str, search: str, tag: str, recency: str, prev_tool_ids):
    tool_ids, summary, last_refresh, new_text, errs = ui_refresh_registry(prev_tool_ids)
    tags = ui_catalog_tags()
    rows = ui_tool_catalog_rows(system_type, access_mode, module_group, search, tag, recency)
    tag_value = tag if tag in tags else None
    return tool_ids, gr.update(choices=tags, value=tag_value), rows, errs, summary, last_refresh, new_text


def ui_render_schema(tool_id, cfg_json):
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    cfg = cfg_json if isinstance(cfg_json, dict) else {}
    fields = []
    if tool:
        schema = {}
        try:
            schema = tool.config_schema() or {}
        except Exception:
            schema = {}
        fields = schema.get("fields", []) if isinstance(schema, dict) else []

    if not fields:
        for k, v in cfg.items():
            if isinstance(v, bool):
                fields.append({"key": k, "type": "bool", "label": k})
            elif isinstance(v, (int, float)):
                fields.append({"key": k, "type": "number", "label": k})
            else:
                fields.append({"key": k, "type": "text", "label": k, "lines": 3})

    fields = fields[:SCHEMA_SLOTS]
    updates = []
    for i in range(SCHEMA_SLOTS):
        if i < len(fields):
            f = fields[i]
            key = f.get("key", f"field_{i}")
            ftype = f.get("type", "text")
            label = f.get("label", key)

            updates.append(gr.update(visible=True))
            updates.append(f"**{label}**  (`{key}`)")
            updates.append(gr.update(value=ftype))

            if ftype == "bool":
                updates.append(gr.update(visible=True, value=bool(cfg.get(key, False)), label=key))
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=False))
            elif ftype == "select":
                choices = f.get("choices", [])
                val = cfg.get(key, choices[0] if choices else None)
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=True, choices=choices, value=val, label=key))
            elif ftype == "number":
                val = cfg.get(key, 0)
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=True, value=val, label=key))
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=False))
            else:
                lines = int(f.get("lines", 3))
                val = cfg.get(key, "")
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=False))
                updates.append(gr.update(visible=True, value=val, label=key, lines=lines))
                updates.append(gr.update(visible=False))
        else:
            updates.append(gr.update(visible=False))
            updates.append("")
            updates.append(gr.update(value=""))
            updates.append(gr.update(visible=False))
            updates.append(gr.update(visible=False))
            updates.append(gr.update(visible=False))
            updates.append(gr.update(visible=False))

    return updates, fields


def ui_build_config_from_fields(tool_id, fields, *vals):
    cfg = {}
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    if tool and hasattr(tool, "default_config"):
        cfg.update(tool.default_config())
    for i, f in enumerate(fields[:SCHEMA_SLOTS]):
        key = f.get("key")
        ftype = f.get("type", "text")
        base = i * 4
        b, n, tx, sel = vals[base], vals[base + 1], vals[base + 2], vals[base + 3]
        if ftype == "bool":
            cfg[key] = bool(b)
        elif ftype == "number":
            cfg[key] = n
        elif ftype == "select":
            cfg[key] = sel
        else:
            cfg[key] = tx
    return cfg


def ui_load_tool_with_schema(tool_id, project_id, preset_name, system_type, access_mode):
    name, desc, cfg, ref, dd, card = ui_load_tool(tool_id, project_id, preset_name, system_type, access_mode)
    updates, fields = ui_render_schema(tool_id, cfg)
    return [name, desc, cfg, ref, dd, card] + updates + [fields]


def ui_refresh_tools_and_load(system_type, access_mode, module_group, project_id, preset_name, prev_tool_ids):
    tool_ids, summary, last_refresh, new_text, errs = ui_refresh_registry(prev_tool_ids)
    filtered = ui_filtered_tool_ids(system_type, access_mode, module_group)
    tool_dd_update = gr.update(choices=filtered, value=(filtered[0] if filtered else None))
    tool_id = tool_dd_update.get("value")
    if not tool_id:
        empty_updates, fields = ui_render_schema(None, {})
        return [tool_ids, summary, last_refresh, new_text, tool_dd_update, errs, "", "", {}, "", gr.update(choices=[], value=None), {}] + empty_updates + [fields]
    loaded = ui_load_tool_with_schema(tool_id, project_id, preset_name, system_type, access_mode)
    return [tool_ids, summary, last_refresh, new_text, tool_dd_update, errs] + loaded


def ui_load_tool(tool_id, project_id, preset_name, system_type, access_mode):
    if not tool_id:
        return "", "", {}, "", gr.update(choices=[], value=None), {}
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    if tool is None:
        return "", "", {}, "", gr.update(choices=[], value=None), {}

    presets = list_tool_presets(project_id, tool_id, db_path=DB_PATH) if project_id else []
    preset_labels = [p["preset_name"] + (" (active)" if p["is_active"] else "") for p in presets]
    label_to_name = {lbl: lbl.replace(" (active)", "") for lbl in preset_labels}

    cfg = {}
    chosen = None
    if preset_name and preset_name in label_to_name:
        chosen = label_to_name[preset_name]
        cfg = get_tool_preset_config(project_id, tool_id, chosen, db_path=DB_PATH)
    else:
        active = next((p for p in presets if p["is_active"]), None)
        if active:
            chosen = active["preset_name"]
            cfg = get_tool_preset_config(project_id, tool_id, chosen, db_path=DB_PATH)
        else:
            cfg = get_tool_config(project_id, tool_id, db_path=DB_PATH) if project_id else {}

    if not cfg:
        cfg = tool.default_config() if hasattr(tool, "default_config") else {}

    md = {}
    try:
        md = tool.metadata() or {}
    except Exception:
        md = {}

    cov = tool_coverage_status(tool_id, system_type, access_mode)
    cov_note = ""
    if hasattr(tool, "coverage_notes"):
        cov_note = tool.coverage_notes(system_type, access_mode) or ""

    ref = f"{tool_id}@{getattr(tool,'version','')}"
    dd = gr.update(choices=preset_labels, value=(f"{chosen} (active)" if chosen and any(p["preset_name"] == chosen and p["is_active"] for p in presets) else chosen))
    card = {
        "tool_id": getattr(tool, "tool_id", tool_id),
        "name": getattr(tool, "name", ""),
        "module_group": getattr(tool, "module_group", ""),
        "owner": md.get("owner", "TBD"),
        "status": md.get("status", "Experimental"),
        "tags": md.get("tags", []),
        "limitations": md.get("limitations", ""),
        "coverage_status": cov,
        "coverage_notes": cov_note,
        "loaded_from": os.path.relpath(_tool_path(tool_id), BASE_DIR),
    }
    return getattr(tool, "name", tool_id), getattr(tool, "description", ""), cfg, ref, dd, card


def ui_save_preset(project_id, tool_id, preset_name_new, set_active, cfg_json):
    if not project_id or not tool_id:
        return "Select a project and a tool first."
    if not preset_name_new:
        return "Provide a preset name (e.g., baseline / strict / pilot)."
    cfg = cfg_json if isinstance(cfg_json, dict) else {}
    upsert_tool_preset(project_id, tool_id, preset_name_new, cfg, bool(set_active), db_path=DB_PATH)
    return f"Saved preset '{preset_name_new}'{' and set active' if set_active else ''}."


def ui_delete_preset(project_id, tool_id, preset_label):
    if not project_id or not tool_id or not preset_label:
        return "Select a project, tool, and preset."
    pname = preset_label.replace(" (active)", "")
    delete_tool_preset(project_id, tool_id, pname, db_path=DB_PATH)
    return f"Deleted preset '{pname}'."


def ui_validate_tool_config(tool_id, cfg_json):
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    if tool is None:
        return {"ok": False, "error": "Tool not found"}
    if not isinstance(cfg_json, dict):
        return {"ok": False, "error": "Config must be a JSON object"}
    try:
        if hasattr(tool, "validate_config"):
            ok, msg = tool.validate_config(cfg_json)
            return {"ok": bool(ok), "message": msg}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "message": "ok"}


def _sample_dataset(n: int, mode: str):
    with open(DATASET_PATH, "r", encoding="utf-8-sig") as f:
        rows = [json.loads(line) for line in f if line.strip()]
    if not rows:
        return []
    n = max(1, min(int(n), len(rows)))
    if mode == "random":
        return random.sample(rows, n)
    return rows[:n]


def ui_run_smoke_test(project_id, tool_id, system_type, access_mode, adapter_label, adapter_label_map, api_base_url, cfg_json):
    if not project_id:
        return "?? Select a project first.", []
    if not tool_id:
        return "?? Select a tool first.", []
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    if tool is None:
        return "?? Tool not found.", []

    adapter_id = _adapter_id_from_label(adapter_label, adapter_label_map, access_mode)
    adapter = ADAPTER_REGISTRY.get(adapter_id)
    if adapter is None:
        return f"?? Adapter not found: {adapter_id}", []

    records = _sample_dataset(3, "first_n")
    results = []
    for r in records:
        try:
            evidence = adapter.build_evidence(
                record=r,
                system_type=system_type,
                access_mode=access_mode,
                cfg={"api_base_url": (api_base_url or None)},
            )
            res = tool.run_on_evidence(evidence, (cfg_json or {}), tool_ctx(project_id, system_type, access_mode, api_base_url))
            pf = res.pass_fail
            if str(pf).lower() == "pass":
                pf = "? PASS"
            elif str(pf).lower() == "fail":
                pf = "? FAIL"
            results.append([r.get("id", ""), pf, res.overall_score, json.dumps(res.metrics), json.dumps([e.payload for e in res.evidence])])
        except Exception as exc:
            results.append([r.get("id", ""), "?? ERROR", 0.0, json.dumps({"error": str(exc)}), "[]"])

    run = run_tool_standalone(
        project_id=project_id,
        dataset_path=DATASET_PATH,
        db_path=DB_PATH,
        system_type=system_type,
        access_mode=access_mode,
        api_base_url=(api_base_url or None),
        tool_id=tool_id,
        adapter_id=adapter_id,
        adapter_cfg={"api_base_url": (api_base_url or None)},
        limit_records=3,
        override_tool_config=(cfg_json or {}),
    )
    return f"? Standalone run created: {run['run_id']} (tool={tool_id}, n=3)", results
def _load_fixture_bundle(fixture_path: str) -> EvidenceBundle:
    with open(fixture_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    bundle = EvidenceBundle.from_dict(data)
    ok, msg = bundle.validate()
    if not ok:
        raise ValueError(msg)
    return bundle


def ui_run_fixture_test(project_id, tool_id, access_mode, fixture_label, fixture_label_map, cfg_json, save_evidence):
    if not project_id:
        return "?? Select a project first.", {}
    if not tool_id:
        return "?? Select a tool first.", {}
    if not fixture_label:
        return "?? Select a fixture.", {}
    fixture_path = fixture_label_map.get(fixture_label) if fixture_label_map else None
    if not fixture_path:
        return "?? Fixture path not found.", {}
    tool = TOOL_REGISTRY_OBJ.get(tool_id)
    if tool is None:
        return "?? Tool not found.", {}

    try:
        evidence = _load_fixture_bundle(fixture_path)
    except Exception as exc:
        return f"?? Failed to load fixture: {exc}", {}

    if access_mode and evidence.request.access_mode != access_mode:
        return f"?? Fixture access_mode mismatch: {evidence.request.access_mode}", {}

    try:
        res = tool.run_on_evidence(evidence, (cfg_json or {}), tool_ctx(project_id, evidence.request.system_type, evidence.request.access_mode, None))
    except Exception as exc:
        return f"?? Tool execution failed: {exc}", {}

    status = "PASS" if str(res.pass_fail).upper() == "PASS" else "FAIL"
    summary = f"{status}: {tool_id} on {fixture_label}"

    if save_evidence:
        tmp_path = os.path.join(app_config.runs_dir(), f"fixture_{tool_id}_{int(datetime.now(timezone.utc).timestamp())}.jsonl")
        os.makedirs(app_config.runs_dir(), exist_ok=True)
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(json.dumps({"id": evidence.request.case_id, "fixture_path": fixture_path}) + "\\n")
        run = run_tool_standalone(
            project_id=project_id,
            dataset_path=tmp_path,
            db_path=DB_PATH,
            system_type=evidence.request.system_type,
            access_mode=evidence.request.access_mode,
            api_base_url=None,
            tool_id=tool_id,
            adapter_id="fixture",
            adapter_cfg={"fixture_path": fixture_path},
            limit_records=1,
            override_tool_config=(cfg_json or {}),
        )
        summary = f"{summary} | saved run {run['run_id']}"

    return summary, {
        "pass_fail": res.pass_fail,
        "overall_score": res.overall_score,
        "metrics": res.metrics,
        "evidence": [e.payload for e in res.evidence],
    }


def tool_ctx(project_id, system_type, access_mode, api_base_url):
    from mro_validation_sdk import ToolContext
    return ToolContext(
        project_id=project_id,
        system_type=system_type,
        access_mode=access_mode,
        api_base_url=(api_base_url or None),
        db_path=DB_PATH,
    )


def ui_run_suite(
    project_id,
    system_type,
    access_mode,
    adapter_label,
    adapter_label_map,
    api_base_url,
    use_saved_presets,
    selected_tool_labels,
    tool_label_map,
    dataset_source,
    scenario_dataset_label,
    scenario_dataset_label_map,
    scenario_approved_only,
    scenario_topic,
    scenario_persona,
    scenario_channel,
    scenario_risk_focus,
    scenario_obj_quality,
    scenario_obj_policy,
    scenario_obj_security,
    scenario_obj_rag_grounding,
    scenario_obj_agent_planning,
    scenario_limit,
    sample_n,
    sample_mode,
    override_tool_id1,
    override_cfg1,
    override_tool_id2,
    override_cfg2,
):
    if not project_id:
        return "Please select a project first (Project tab).", None, {}, [], ""

    selected_tools = []
    for lbl in (selected_tool_labels or []):
        key = tool_label_map.get(lbl)
        if key:
            selected_tools.append(key)

    if not selected_tools:
        return "No tools selected. Please select at least one tool.", None, {}, [], ""

    override_tool_configs = {}
    if override_tool_id1:
        override_tool_configs[override_tool_id1] = override_cfg1 if isinstance(override_cfg1, dict) else {}
    if override_tool_id2:
        override_tool_configs[override_tool_id2] = override_cfg2 if isinstance(override_cfg2, dict) else {}

    api_url = api_base_url.strip() if api_base_url else None
    limit_records = int(sample_n) if sample_n else None
    adapter_id = _adapter_id_from_label(adapter_label, adapter_label_map, access_mode)

    scenario_cases = None
    scenario_dataset_id = None
    dataset_path = DATASET_PATH
    if dataset_source == "Scenario Datasets":
        scenario_dataset_id = scenario_dataset_label_map.get(scenario_dataset_label) if scenario_dataset_label_map else None
        if not scenario_dataset_id:
            return "Select a scenario dataset first.", None, {}, [], ""
        ds = load_scenario_dataset(scenario_dataset_id, db_path=DB_PATH)
        filtered = _filter_scenario_cases(
            ds.cases,
            bool(scenario_approved_only),
            scenario_topic or "",
            scenario_persona or "",
            scenario_channel or "",
            scenario_risk_focus or "",
            bool(scenario_obj_quality),
            bool(scenario_obj_policy),
            bool(scenario_obj_security),
            bool(scenario_obj_rag_grounding),
            bool(scenario_obj_agent_planning),
            int(scenario_limit) if scenario_limit else None,
        )
        if not filtered:
            return "No scenario cases matched the selected filters.", None, {}, [], ""
        scenario_cases = [c.to_dict() for c in filtered]
        limit_records = None
        dataset_path = None
    else:
        if sample_mode == "random":
            records = _sample_dataset(limit_records, "random")
            tmp_path = os.path.join(app_config.runs_dir(), "tmp_sample.jsonl")
            os.makedirs(app_config.runs_dir(), exist_ok=True)
            with open(tmp_path, "w", encoding="utf-8") as f:
                for r in records:
                    f.write(json.dumps(r) + "\n")
            dataset_path = tmp_path

    run = run_suite(
        project_id=project_id,
        dataset_path=dataset_path,
        scenario_dataset_id=scenario_dataset_id,
        scenario_cases=scenario_cases,
        db_path=DB_PATH,
        system_type=system_type,
        access_mode=access_mode,
        api_base_url=api_url,
        selected_tools=selected_tools,
        adapter_id=adapter_id,
        adapter_cfg={"api_base_url": api_url},
        use_saved_presets=bool(use_saved_presets),
        override_tool_configs=override_tool_configs or None,
        run_mode="suite",
        limit_records=limit_records,
    )
    status = f"Run completed: {run['run_id']} | {run['system_type']}/{run['access_mode']} | adapter={adapter_id} | pass_rate={run['pass_rate']:.2f} | total={run['total']}"
    run_meta = get_run(run["run_id"], db_path=DB_PATH).get("run_metadata") or {}
    status_rows = _tool_status_table(run_meta)
    run_log = "\n".join(run_meta.get("run_log") or [])
    summary_rows = _run_summary_table(run["run_id"])
    combined = _combine_status_and_summary(status_rows, summary_rows)
    return status, run["run_id"], _current_run_panel(run["run_id"]), combined, run_log

def _tool_status_table(run_meta: dict):
    tool_status = run_meta.get("tool_status") or {}
    tool_errors = run_meta.get("tool_errors") or {}
    rows = []
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    for tool_id, status in tool_status.items():
        rows.append([tool_id, status, ts, tool_errors.get(tool_id, "")])
    return rows


def _current_run_panel(run_id: str):
    if not run_id:
        return {}
    run = get_run(run_id, db_path=DB_PATH)
    meta = run.get("run_metadata") or {}
    return {
        "run_id": run.get("run_id"),
        "status": run.get("status"),
        "progress": f"{meta.get('records_processed', 0)}/{meta.get('records_total', 0)}",
        "pass_rate": run.get("pass_rate"),
        "total": run.get("total"),
        "run_mode": meta.get("run_mode"),
        "adapter_id": meta.get("adapter_id"),
        "access_mode": meta.get("access_mode"),
    }

def _run_summary_table(run_id: str):
    if not run_id:
        return []
    traces = list_traces_for_run(run_id, db_path=DB_PATH)
    tool_stats = {}
    for t in traces:
        detail = get_trace(t["trace_id"], db_path=DB_PATH)
        for e in detail.get("evaluations", []):
            tid = e.get("tool_id")
            ev = e.get("evaluation") or {}
            tool_stats.setdefault(tid, {"scores": [], "fails": 0, "findings": 0})
            tool_stats[tid]["scores"].append(float(ev.get("overall_score", 0.0)))
            if str(ev.get("pass_fail", "")).upper() != "PASS":
                tool_stats[tid]["fails"] += 1
            evidence = ev.get("evidence") or []
            tool_stats[tid]["findings"] += len(evidence)

    rows = []
    for tid, stats in tool_stats.items():
        avg = sum(stats["scores"]) / len(stats["scores"]) if stats["scores"] else 0.0
        rows.append([tid, round(avg, 3), stats["fails"], stats["findings"]])
    rows.sort(key=lambda r: r[0])
    return rows


def _combine_status_and_summary(status_rows, summary_rows):
    summary_map = {row[0]: row[1:] for row in (summary_rows or []) if row}
    combined = []
    for row in (status_rows or []):
        tool_id = row[0] if row else ""
        summary = summary_map.get(tool_id, ["", "", ""])
        combined.append(list(row) + list(summary))
    for tool_id, summary in summary_map.items():
        if not any(r and r[0] == tool_id for r in combined):
            combined.append([tool_id, "", "", ""] + list(summary))
    return combined


def ui_refresh_run_status(run_id):
    if not run_id:
        return {}, [], ""
    run = get_run(run_id, db_path=DB_PATH)
    run_meta = run.get("run_metadata") or {}
    status_rows = _tool_status_table(run_meta)
    summary_rows = _run_summary_table(run_id)
    combined = _combine_status_and_summary(status_rows, summary_rows)
    return _current_run_panel(run_id), combined, "\n".join(run_meta.get("run_log") or [])


def ui_cancel_run(run_id):
    if not run_id:
        return "No run selected."
    run = get_run(run_id, db_path=DB_PATH)
    if not run:
        return "Run not found."
    run_meta = run.get("run_metadata") or {}
    upsert_run(
        project_id=run.get("project_id"),
        run_id=run_id,
        status="cancelled",
        pass_rate=run.get("pass_rate", 0.0),
        total=run.get("total", 0),
        run_metadata=run_meta,
        db_path=DB_PATH,
    )
    return f"Marked run as cancelled: {run_id}"


def ui_refresh_runs(project_id):
    choices = _run_choices(project_id)
    labels = list(choices.keys())
    return gr.update(choices=labels, value=(labels[0] if labels else None))


def ui_refresh_runs_multi(project_id):
    choices = _run_choices(project_id)
    labels = list(choices.keys())
    return gr.update(choices=labels, value=[])


def ui_select_run(run_label, project_id):
    return _run_choices(project_id).get(run_label)


def ui_run_labels_to_ids(project_id, run_labels):
    label_map = _run_choices(project_id)
    return [label_map[lbl] for lbl in (run_labels or []) if lbl in label_map]


def ui_run_metadata(run_id):
    return get_run(run_id, db_path=DB_PATH) if run_id else {}


def ui_list_traces(run_id):
    if not run_id:
        return []
    traces = list_traces_for_run(run_id, db_path=DB_PATH)
    rows = []
    for t in traces:
        pf = t.get("pass_fail")
        if str(pf).lower() == "pass":
            pf = "✅ PASS"
        elif str(pf).lower() == "fail":
            pf = "❌ FAIL"
        rows.append([t["trace_id"], t["input_preview"], t["overall_score"], pf, t["created_at"]])
    return rows


def ui_trace_ids_for_run(run_id):
    traces = list_traces_for_run(run_id, db_path=DB_PATH) if run_id else []
    ids = [t["trace_id"] for t in traces]
    return (
        gr.update(choices=ids, value=(ids[0] if ids else None)),
        gr.update(choices=ids, value=[]),
        gr.update(choices=ids, value=[]),
    )


def ui_trace_detail(trace_id):
    return get_trace(trace_id, db_path=DB_PATH) if trace_id else {}


def ui_trace_evidence_sections(trace_id):
    if not trace_id:
        return {}, {}, {}, {}, {}
    detail = get_trace(trace_id, db_path=DB_PATH) or {}
    trace = detail.get("trace") or {}
    evidence = trace.get("evidence") or {}
    return (
        evidence.get("request") or {},
        evidence.get("response") or {},
        evidence.get("rag") or {},
        evidence.get("agent") or {},
        evidence.get("trace") or {},
    )


def ui_delete_run(run_id):
    if not run_id:
        return "No run selected."
    delete_run(run_id, db_path=DB_PATH)
    return f"Deleted run: {run_id}"


def ui_delete_traces(run_id, trace_ids):
    if not run_id or not trace_ids:
        return "Select a run and one or more traces to delete."
    delete_traces(trace_ids, db_path=DB_PATH)
    return f"Deleted {len(trace_ids)} trace(s)."


def ui_generate_report(run_id, selected_trace_ids, evidence_pack):
    if not run_id:
        return None
    path = generate_report_md(run_id=run_id, output_dir=app_config.reports_dir(), db_path=DB_PATH, selected_trace_ids=selected_trace_ids or None)
    if evidence_pack:
        with open(path, "a", encoding="utf-8") as f:
            f.write("\n## Curated Evidence Pack\n\n")
            f.write(json.dumps(evidence_pack, indent=2))
            f.write("\n")
    return path


def ui_generate_report_with_preview(run_id, selected_trace_ids, evidence_pack):
    path = ui_generate_report(run_id, selected_trace_ids, evidence_pack)
    if not path:
        return None, "No report generated yet."
    with open(path, "r", encoding="utf-8") as f:
        md = f.read()
    return path, md


def ui_export_evidence(run_id, selected_trace_ids):
    if not run_id:
        return None
    return export_evidence_pack(run_id=run_id, output_dir=app_config.reports_dir(), db_path=DB_PATH, selected_trace_ids=selected_trace_ids or None)


def ui_add_evidence_pack(run_id, trace_ids, tool_filter, evidence_pack):
    if not run_id:
        return evidence_pack or []
    evidence_pack = list(evidence_pack or [])
    for tid in (trace_ids or []):
        detail = get_trace(tid, db_path=DB_PATH)
        for e in detail.get("evaluations", []):
            tool_id = e.get("tool_id")
            if tool_filter and tool_id not in tool_filter:
                continue
            ev = e.get("evaluation") or {}
            evidence = ev.get("evidence") or []
            if evidence:
                evidence_pack.append({"trace_id": tid, "tool_id": tool_id, "evidence": evidence})
    return evidence_pack


def ui_add_evidence_pack_for_runs(run_ids, tool_filter, evidence_pack):
    evidence_pack = list(evidence_pack or [])
    for rid in (run_ids or []):
        traces = list_traces_for_run(rid, db_path=DB_PATH)
        for t in traces:
            detail = get_trace(t["trace_id"], db_path=DB_PATH)
            for e in detail.get("evaluations", []):
                tool_id = e.get("tool_id")
                if tool_filter and tool_id not in tool_filter:
                    continue
                ev = e.get("evaluation") or {}
                evidence = ev.get("evidence") or []
                if evidence:
                    evidence_pack.append({"run_id": rid, "trace_id": t["trace_id"], "tool_id": tool_id, "evidence": evidence})
    return evidence_pack


def ui_traces_for_run(run_id):
    traces = list_traces_for_run(run_id, db_path=DB_PATH) if run_id else []
    labels = [f"{t['trace_id']} | {t['input_preview']}" for t in traces]
    return gr.update(choices=labels, value=[])


def ui_trace_labels_to_ids(run_id, trace_labels):
    if not run_id or not trace_labels:
        return []
    traces = list_traces_for_run(run_id, db_path=DB_PATH)
    label_map = {f"{t['trace_id']} | {t['input_preview']}": t["trace_id"] for t in traces}
    return [label_map[lbl] for lbl in trace_labels if lbl in label_map]


def ui_clear_evidence_pack():
    return []


def ui_tool_filter_options(run_id):
    if not run_id:
        return gr.update(choices=[], value=[])
    traces = list_traces_for_run(run_id, db_path=DB_PATH)
    tools = set()
    for t in traces:
        detail = get_trace(t["trace_id"], db_path=DB_PATH)
        for e in detail.get("evaluations", []):
            tools.add(e.get("tool_id"))
    return gr.update(choices=sorted(list(tools)), value=[])


def ui_run_table(project_id):
    if not project_id:
        return []
    runs = list_runs(project_id, db_path=DB_PATH)
    rows = []
    for r in runs:
        meta = r.get("run_metadata") or {}
        rows.append([
            r.get("run_id"),
            r.get("created_at"),
            r.get("status"),
            meta.get("run_mode"),
            meta.get("system_type"),
            meta.get("access_mode"),
            r.get("pass_rate"),
            r.get("total"),
        ])
    return rows


def ui_tool_preset_status(project_id, tool_labels, tool_label_map):
    rows = []
    if not project_id:
        return rows
    tool_ids = []
    for lbl in (tool_labels or []):
        tid = tool_label_map.get(lbl)
        if tid:
            tool_ids.append(tid)
    for tid in tool_ids:
        cfg = get_active_tool_preset_config(project_id, tid, db_path=DB_PATH)
        status = "active preset" if cfg else "default config"
        rows.append([tid, status])
    return rows


def _preview_rows(rows, limit=5):
    return list(rows or [])[:limit]


def _preview_log(text, limit=5):
    lines = (text or "").splitlines()
    return "\n".join(lines[:limit])


def ui_tool_preset_status_with_preview(project_id, tool_labels, tool_label_map):
    rows = ui_tool_preset_status(project_id, tool_labels, tool_label_map)
    return _preview_rows(rows, 5), rows


def ui_run_suite_with_preview(
    project_id,
    system_type,
    access_mode,
    adapter_label,
    adapter_label_map,
    api_base_url,
    use_saved_presets,
    selected_tool_labels,
    tool_label_map,
    dataset_source,
    scenario_dataset_label,
    scenario_dataset_label_map,
    scenario_approved_only,
    scenario_topic,
    scenario_persona,
    scenario_channel,
    scenario_risk_focus,
    scenario_obj_quality,
    scenario_obj_policy,
    scenario_obj_security,
    scenario_obj_rag_grounding,
    scenario_obj_agent_planning,
    scenario_limit,
    sample_n,
    sample_mode,
    override_tool_id1,
    override_cfg1,
    override_tool_id2,
    override_cfg2,
):
    status, run_id, panel, combined, run_log = ui_run_suite(
        project_id,
        system_type,
        access_mode,
        adapter_label,
        adapter_label_map,
        api_base_url,
        use_saved_presets,
        selected_tool_labels,
        tool_label_map,
        dataset_source,
        scenario_dataset_label,
        scenario_dataset_label_map,
        scenario_approved_only,
        scenario_topic,
        scenario_persona,
        scenario_channel,
        scenario_risk_focus,
        scenario_obj_quality,
        scenario_obj_policy,
        scenario_obj_security,
        scenario_obj_rag_grounding,
        scenario_obj_agent_planning,
        scenario_limit,
        sample_n,
        sample_mode,
        override_tool_id1,
        override_cfg1,
        override_tool_id2,
        override_cfg2,
    )
    return status, run_id, panel, combined, _preview_log(run_log, 5), run_log


def ui_refresh_run_status_with_preview(run_id):
    panel, combined, run_log = ui_refresh_run_status(run_id)
    return panel, combined, _preview_log(run_log, 5), run_log


_ensure_dataset()
_ensure_fixtures()
_dd, _errs = ui_refresh_tools()
TOOL_LOAD_ERRORS.clear()
TOOL_LOAD_ERRORS.extend(_errs)
INITIAL_MODULE_CHOICES, INITIAL_MODULE_MAP = _initial_module_badges(DEFAULT_SYSTEM, DEFAULT_ACCESS)
INITIAL_TOOL_CHOICES, INITIAL_TOOL_MAP = _initial_tool_badges(
    DEFAULT_SYSTEM, DEFAULT_ACCESS, INITIAL_MODULE_CHOICES, INITIAL_MODULE_MAP
)


with gr.Blocks(title="MRO GenAI & Agentic AI Validation Platform (Demo)") as demo:
    # Global styling for enterprise-grade visual hierarchy and spacing.
    gr.HTML(
        """
        <style>
            :root {
                --primary: #0f2a4a;
                --secondary: #2f6f6a;
                --warning: #c9872b;
                --error: #b42318;
                --btn-primary: #f97316;
                --bg: #f5f7fa;
                --card: #ffffff;
                --border: #d7dee7;
                --muted: #5b6b7c;
            }
            .gradio-container {
                font-family: "Source Sans 3", "Segoe UI", Arial, sans-serif;
                background: var(--bg);
            }
            .section-card {
                border: 1px solid var(--border);
                background: var(--card);
                padding: 16px;
                border-radius: 10px;
                box-shadow: 0 1px 2px rgba(16, 24, 40, 0.06);
            }
            .section-card .gr-panel,
            .section-card .gr-box,
            .section-card .gr-form,
            .section-card .gr-group,
            .section-card .gr-row,
            .section-card .gr-column {
                background: var(--card);
                border-color: var(--border);
            }
            .section-card .gr-row,
            .section-card .gr-column {
                padding: 0;
                margin: 0;
            }
            .info-box {
                border-left: 4px solid var(--secondary);
                background: #eef6f5;
                padding: 10px 12px;
                border-radius: 8px;
                color: var(--primary);
            }
            .summary-card {
                border: 1px solid #c8d7ea;
                background: #eef4fb;
                padding: 14px 16px;
                border-radius: 10px;
                color: var(--primary);
            }
            .summary-title {
                font-weight: 700;
                margin-bottom: 6px;
            }
            .muted {
                color: var(--muted);
            }
            .warning-box {
                border-left: 4px solid var(--warning);
                background: #fff6e8;
                padding: 10px 12px;
                border-radius: 8px;
                color: #5b3b00;
            }
            .warning-text {
                margin-top: 6px;
                color: #8a5b00;
                font-size: 12px;
            }
            .action-box {
                border: 1px dashed var(--primary);
                background: #f0f4f9;
                padding: 12px;
                border-radius: 8px;
            }
            .status-pill {
                display: inline-block;
                padding: 2px 8px;
                border-radius: 999px;
                font-size: 12px;
                font-weight: 600;
            }
            .status-pill.ok {
                background: #e8f5ef;
                color: #1a7f5a;
                border: 1px solid #bde6d3;
            }
            .status-pill.warn {
                background: #fff4e5;
                color: #8a5b00;
                border: 1px solid #ffdba6;
            }
            .status-pill.err {
                background: #ffe7e7;
                color: #b42318;
                border: 1px solid #f4b7b7;
            }
            .helper {
                color: var(--muted);
                font-size: 12px;
                margin-top: 6px;
            }
            .log-box textarea {
                height: 180px;
                overflow-y: auto;
            }
            .json-box {
                border: 1px solid var(--border);
                padding: 10px;
                border-radius: 8px;
                background: #fbfcfe;
            }
            .gr-button-primary {
                background: var(--btn-primary);
                border-color: var(--btn-primary);
                color: #ffffff;
            }
            .gr-button-secondary {
                background: transparent;
                border: 1px solid var(--primary);
                color: var(--primary);
            }
            .gr-button-stop {
                background: var(--error);
                border-color: var(--error);
                color: #ffffff;
            }
            .btn-warning {
                background: var(--warning);
                border-color: var(--warning);
                color: #ffffff;
            }
            .btn-neutral {
                background: #f1f5f9;
                border-color: #cbd5e1;
                color: var(--primary);
            }
            .btn-danger-outline {
                background: transparent;
                border: 1px solid var(--error);
                color: var(--error);
            }
            .btn-success-outline {
                background: transparent;
                border: 1px solid #1a7f5a;
                color: #1a7f5a;
            }
            .btn-tertiary {
                background: transparent;
                border: none;
                color: var(--primary);
            }
            .btn-destructive {
                background: transparent;
                border: 1px solid var(--error);
                color: var(--error);
            }
            .btn-icon {
                min-width: 42px;
                padding: 0 8px;
            }
            .tight-row {
                gap: 12px;
            }
            .clean-panel {
                background: var(--card);
                border: 1px solid var(--border);
                box-shadow: none;
            }
            .full-width-btn .gr-button {
                width: 100%;
            }
            .card-title {
                font-weight: 700;
                margin-bottom: 8px;
                color: var(--primary);
            }
            .subtle {
                color: var(--muted);
                font-size: 13px;
            }
            .pill-card {
                display: inline-block;
                background: #eef4fb;
                border: 1px solid #c8d7ea;
                color: var(--primary);
                padding: 6px 10px;
                border-radius: 999px;
                font-size: 12px;
            }
            .section-title {
                font-weight: 700;
                color: var(--primary);
                margin-bottom: 8px;
            }
            .muted-text {
                color: var(--muted);
                font-size: 13px;
            }
            .card {
                border: 1px solid var(--border);
                background: var(--card);
                padding: 14px 16px;
                border-radius: 10px;
                box-shadow: 0 1px 2px rgba(16, 24, 40, 0.06);
                margin-bottom: 12px;
            }
            .compact-row {
                gap: 8px;
                align-items: center;
            }
            .align-right {
                display: flex;
                justify-content: flex-end;
            }
            .card-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 12px;
                margin-bottom: 8px;
            }
            .context-card {
                border: 1px solid var(--border);
                background: #f7f9fc;
                padding: 12px 14px;
                border-radius: 10px;
                margin-bottom: 12px;
            }
            .danger-card {
                border: 1px solid #f4b7b7;
                background: #fff1f1;
                padding: 12px 14px;
                border-radius: 10px;
            }
            .actions-panel {
                border: 1px solid var(--border);
                background: #f7f9fc;
                padding: 12px;
                border-radius: 10px;
            }
            .table-scroll .gr-table {
                max-height: 240px;
                overflow: auto;
            }
            .btn-md .gr-button {
                min-width: 180px;
            }
            .btn-sm .gr-button {
                min-width: 90px;
            }
            .btn-inline .gr-button {
                width: auto;
                min-width: 180px;
            }
            .compact-multiselect .wrap {
                height: 220px;
                overflow-y: auto;
            }
            .action-row {
                display: flex;
                gap: 12px;
                align-items: center;
            }
            .action-spacer {
                margin-left: auto;
            }
            .action-help {
                font-size: 12px;
                color: var(--muted);
                margin-top: 6px;
            }
            .legend-box {
                border: 1px solid var(--border);
                background: #f7f9fc;
                padding: 8px 10px;
                border-radius: 8px;
                margin-bottom: 8px;
            }
            .filter-card {
                border: 1px solid var(--border);
                background: var(--card);
                padding: 12px;
                border-radius: 10px;
                margin-bottom: 10px;
            }
            .table-card {
                border: 1px solid var(--border);
                background: var(--card);
                padding: 12px;
                border-radius: 10px;
            }
            .df-mute-status td:nth-child(3),
            .df-mute-status th:nth-child(3) {
                color: var(--muted);
            }
            .df-roomy td,
            .df-roomy th {
                padding-top: 8px;
                padding-bottom: 8px;
            }
            .module-table table td,
            .module-table table th {
                padding-top: 6px;
                padding-bottom: 6px;
            }
            .module-table table td:last-child,
            .module-table table th:last-child {
                text-align: right;
            }
        </style>
        """
    )
    project_state = gr.State(value=None)
    last_action_state = gr.State(value=None)
    run_state = gr.State(value=None)
    module_label_map_state = gr.State(value=INITIAL_MODULE_MAP)
    tool_label_map_state = gr.State(value=INITIAL_TOOL_MAP)
    tool_ids_state = gr.State(value=sorted(list(TOOL_REGISTRY_OBJ.keys())))

    # Page header and concise intro for non-technical stakeholders.
    gr.Markdown("# 🏦 MRO GenAI & Agentic AI Validation Platform")
    gr.Markdown("Enterprise demo for tool coverage, validation execution, and evidence-ready reporting.")

    # UI: Governance-first project entry point with explicit scoping and deletion safeguards.
    with gr.Tab("📁 1) Project"):
        gr.Markdown("## 📁 Project Setup & Governance Scope")
        gr.Markdown("Step 1 of 6: Define the active validation project.")
        gr.Markdown("Projects represent formal validation engagements and define the audit-ready validation scope.")
        project_summary = gr.HTML(ui_project_summary(None))
        selected_project_id = gr.Textbox(label="Project ID (read-only)", interactive=False)
        gr.HTML('<div class="helper">Auto-filled from the active project.</div>')
        project_state.change(ui_project_id_autofill, inputs=[project_state], outputs=[selected_project_id])
        project_state.change(ui_project_summary, inputs=[project_state], outputs=[project_summary])

        with gr.Row(elem_classes=["tight-row"]):
            with gr.Column(scale=2, min_width=420):
                gr.Markdown("### 📁 Existing Projects")
                with gr.Group(elem_classes=["section-card"]):
                    project_dd = gr.Dropdown(label="Project list", choices=[], value=None)
                    refresh_projects_btn = gr.Button(
                        "🔄 Refresh Projects",
                        variant="primary",
                    )
                    gr.HTML('<div class="helper">Selecting a project automatically scopes all other tabs.</div>')

                    delete_project_btn = gr.Button(
                        "🗑️ Delete Project",
                        variant="secondary",
                        elem_classes=["btn-destructive"],
                    )
                    delete_status = gr.Textbox(label="Deletion status", interactive=False)

                    delete_confirm_group = gr.Group(visible=False, elem_classes=["section-card", "clean-panel"])
                    with delete_confirm_group:
                        delete_confirm_html = gr.HTML("")
                        delete_confirm_name = gr.Textbox(label="Type project name to confirm", value="")
                        delete_confirm_ack = gr.Checkbox(label="I understand this action is irreversible", value=False)
                        with gr.Row():
                            confirm_delete_btn = gr.Button("🗑️ Confirm Delete", variant="secondary", elem_classes=["btn-destructive"])
                            cancel_delete_btn = gr.Button("↩️ Cancel Delete", variant="secondary", elem_classes=["btn-tertiary"])
            with gr.Column(scale=1, min_width=360):
                gr.Markdown("### ➕ Create New Project")
                with gr.Group(elem_classes=["section-card"]):
                    project_name = gr.Textbox(label="Project name", value="Demo Project")
                    project_desc = gr.Textbox(label="Project description", value="MRO validation demo")
                    gr.HTML('<div class="helper">Use clear, audit-ready naming for validation tracking.</div>')
                    create_project_btn = gr.Button("➕ Create Project", variant="primary")
                    create_out = gr.Textbox(label="Creation status", interactive=False)

        refresh_projects_btn.click(ui_refresh_projects, inputs=[], outputs=[project_dd, project_state])
        project_dd.change(ui_select_project, inputs=[project_dd], outputs=[project_state])
        create_project_btn.click(ui_create_project, inputs=[project_name, project_desc], outputs=[create_out, project_state])
        create_project_btn.click(lambda: "Created project", inputs=[], outputs=[last_action_state])
        create_project_btn.click(ui_refresh_projects, inputs=[], outputs=[project_dd, project_state])
        project_dd.change(lambda: "Selected project", inputs=[], outputs=[last_action_state])

        delete_project_btn.click(
            ui_open_delete_panel,
            inputs=[project_state],
            outputs=[delete_confirm_group, delete_status, delete_confirm_html, delete_confirm_name, delete_confirm_ack],
        )
        cancel_delete_btn.click(ui_cancel_delete_panel, inputs=[], outputs=[delete_confirm_group, delete_status])
        confirm_delete_btn.click(
            ui_confirm_delete_project,
            inputs=[project_state, delete_confirm_name, delete_confirm_ack],
            outputs=[delete_confirm_group, delete_status, project_state, project_dd, project_summary, selected_project_id],
        )

    # UI: Read-only catalog view with coverage legend and filter row.
    with gr.Tab("🧭 2) Tool Catalog (Browse & Coverage)"):
        gr.Markdown("## 📚 Tool Catalog - Coverage Overview")
        gr.Markdown("Step 2 of 6: Browse available tools before configuration.")
        gr.HTML('<div class="subtle">Read-only view of available validation tools and their coverage by system type and access mode.</div>')
        project_banner_2 = gr.HTML(ui_project_pill(None, None))
        selected_project_id2 = gr.Textbox(label="Selected Project ID (auto)", interactive=False)
        project_state.change(ui_sync_project_label, inputs=[project_state], outputs=[selected_project_id2])
        project_state.change(ui_project_pill, inputs=[project_state, last_action_state], outputs=[project_banner_2])
        last_action_state.change(ui_project_pill, inputs=[project_state, last_action_state], outputs=[project_banner_2])

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("**Summary**")
            registry_summary_cat = gr.Markdown("Tools loaded: 0 | New since last refresh: 0 | Last refresh: -")
            refresh_cat = gr.Button("🔄 Refresh Tool Registry", variant="primary")
            registry_time_cat = gr.Markdown("Registry last refreshed: -")
            registry_new_cat = gr.Markdown("New tools: None")

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("**Module Coverage Summary**")
            registry_module_counts = gr.Markdown(_module_group_counts_md(), elem_classes=["module-table"])

        with gr.Accordion("Advanced details (debug info)", open=False):
            registry_coverage_counts = gr.JSON(
                label="Coverage counts for selected system/access (non-primary)",
                value=_coverage_counts("Agentic AI", "traced"),
            )

        with gr.Group(elem_classes=["section-card", "filter-card"]):
            gr.Markdown("**Coverage Filters**")
            with gr.Row():
                system_type_cat = gr.Dropdown(label="System Type", choices=SYSTEM_TYPES, value="Agentic AI")
                access_mode_cat = gr.Dropdown(label="Access Mode", choices=ACCESS_MODES, value="traced")
                module_group_cat = gr.Dropdown(label="Module Group", choices=ui_module_group_choices(), value="All")
            gr.HTML('<div class="helper">Coverage availability updates dynamically based on selected system type and access mode.</div>')
            with gr.Row():
                search_cat = gr.Textbox(label="Search", value="", placeholder="Search tool name or description...")
                tag_cat = gr.Dropdown(label="Tag filter", choices=ui_catalog_tags(), value=None)
                recency_cat = gr.Dropdown(label="Recently added", choices=["All", "Recent (24h)", "Recent (7d)", "Newest 5"], value="All")
            gr.HTML('<div class="helper">Tag filter hint: Filter by tag...</div>')

        gr.Markdown('<div class="legend-box">✅ Available &nbsp; | &nbsp; ⚠️ Limited &nbsp; | &nbsp; ❌ Unavailable</div>')
        with gr.Group(elem_classes=["section-card", "table-card"]):
            gr.Markdown("**Validation Tools**")
            catalog_tbl = gr.Dataframe(
                headers=["tool_id", "name", "status", "tags", "coverage", "notes"],
                value=ui_tool_catalog_rows(system_type_cat.value, access_mode_cat.value, module_group_cat.value, "", None, "All"),
                interactive=False,
                elem_classes=["df-roomy", "df-mute-status"],
            )
        registry_errors = gr.JSON(label="Registry load errors (if any)", value=TOOL_LOAD_ERRORS)

        def _refresh_catalog(system_type, access_mode, module_group, search, tag, recency):
            return ui_tool_catalog_rows(system_type, access_mode, module_group, search, tag, recency)

        refresh_cat.click(
            ui_refresh_catalog,
            inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat, tool_ids_state],
            outputs=[tool_ids_state, tag_cat, catalog_tbl, registry_errors, registry_summary_cat, registry_time_cat, registry_new_cat],
        )
        refresh_cat.click(lambda: _module_group_counts_md(), inputs=[], outputs=[registry_module_counts])
        refresh_cat.click(lambda st, am: _coverage_counts(st, am), inputs=[system_type_cat, access_mode_cat], outputs=[registry_coverage_counts])
        refresh_cat.click(_refresh_catalog, inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat], outputs=[catalog_tbl])
        system_type_cat.change(_refresh_catalog, inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat], outputs=[catalog_tbl])
        access_mode_cat.change(_refresh_catalog, inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat], outputs=[catalog_tbl])
        module_group_cat.change(_refresh_catalog, inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat], outputs=[catalog_tbl])
        search_cat.change(_refresh_catalog, inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat], outputs=[catalog_tbl])
        tag_cat.change(_refresh_catalog, inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat], outputs=[catalog_tbl])
        recency_cat.change(_refresh_catalog, inputs=[system_type_cat, access_mode_cat, module_group_cat, search_cat, tag_cat, recency_cat], outputs=[catalog_tbl])

        registry_module_counts.value = _module_group_counts_md()
        registry_coverage_counts.value = _coverage_counts(system_type_cat.value, access_mode_cat.value)

    # UI: Guided setup workspace for single-tool configuration and smoke testing.
    with gr.Tab("🛠️ 2) Tool Workbench (Configure & Trial Run)"):
        gr.Markdown("## 🛠️ Tool Workbench - Configure & Test")
        gr.Markdown("Step 2 of 6: Select and configure validation tools for your project.")
        gr.HTML('<div class="muted-text">Configure a validation tool, save presets, and run a quick smoke test.</div>')
        with gr.Row(elem_classes=["compact-row"]):
            project_banner_3 = gr.HTML(ui_project_pill(None, None))
        project_state.change(ui_project_pill, inputs=[project_state, last_action_state], outputs=[project_banner_3])
        last_action_state.change(ui_project_pill, inputs=[project_state, last_action_state], outputs=[project_banner_3])

        with gr.Row():
            with gr.Column(scale=2):
                with gr.Group(elem_classes=["card"]):
                    gr.Markdown("Quick Start", elem_classes=["section-title"])
                    adapter_choices_wb, adapter_label_map_default = _adapter_choices(DEFAULT_ACCESS)
                    with gr.Row():
                        system_type_wb = gr.Dropdown(label="System Type", choices=SYSTEM_TYPES, value="Agentic AI")
                        access_mode_wb = gr.Dropdown(label="Access Mode", choices=ACCESS_MODES, value="traced")
                        adapter_wb = gr.Dropdown(label="Adapter", choices=adapter_choices_wb, value=(adapter_choices_wb[0] if adapter_choices_wb else None))
                        module_group_wb = gr.Dropdown(label="Module Group", choices=ui_module_group_choices(), value="All")
                    adapter_label_map_state_wb = gr.State(value=adapter_label_map_default)
                    tool_dd = gr.Dropdown(label="Tool", choices=sorted(list(TOOL_REGISTRY_OBJ.keys())), value=None)
                    gr.HTML('<div class="helper">Pick System Type + Access Mode to filter tool coverage.</div>')
                    refresh_tools_btn = gr.Button("🔄 Refresh tool registry", variant="primary")
                    registry_refresh_status = gr.Markdown("Registry refreshed at -")

                    with gr.Row():
                        preset_dd = gr.Dropdown(label="Load preset", choices=[], value=None)
                        load_tool_btn = gr.Button("📥 Load tool + presets", variant="secondary")

                    api_base_url_box = gr.Group(visible=False)
                    with api_base_url_box:
                        api_base_url_wb = gr.Textbox(label="Model API base URL (black-box)", value="http://127.0.0.1:8000")
                        gr.HTML('<div class="helper">Only required for black-box access.</div>')

                    smoke_btn = gr.Button("▶️ Run Smoke Test (3 samples)", variant="primary")
                    smoke_out = gr.Textbox(label="ℹ️ Smoke test summary")
                    smoke_tbl = gr.Dataframe(headers=["record_id", "pass_fail", "score", "metrics_json", "evidence_json"], interactive=False)

                with gr.Group(elem_classes=["card"]):
                    gr.Markdown("Fixture Unit Tests", elem_classes=["section-title"])
                    fixture_access_mode = gr.Dropdown(label="Access Mode", choices=ACCESS_MODES, value="traced")
                    fixture_choices, fixture_label_map_default = _fixture_choices("traced")
                    fixture_dd = gr.Dropdown(label="Fixture", choices=fixture_choices, value=(fixture_choices[0] if fixture_choices else None))
                    fixture_label_map_state = gr.State(value=fixture_label_map_default)
                    save_fixture_evidence = gr.Checkbox(label="Save as evidence", value=False)
                    run_fixture_btn = gr.Button("Run Fixture Test", variant="primary")
                    fixture_status = gr.Textbox(label="Fixture test status")
                    fixture_result = gr.JSON(label="Fixture result", value={})


                with gr.Group(elem_classes=["card"]):
                    gr.Markdown("Presets & Configuration", elem_classes=["section-title"])
                    with gr.Row():
                        preset_name_new = gr.Textbox(label="Preset name to save (e.g., baseline/strict/pilot)", value="baseline")
                        set_active = gr.Checkbox(label="⭐ Set Active Preset", value=True)
                    gr.HTML('<div class="helper">Active preset is used by the suite runner.</div>')
                    with gr.Row(elem_classes=["action-row"]):
                        save_preset_btn = gr.Button("💾 Save preset", variant="primary")
                        validate_cfg_btn = gr.Button("✅ Validate config", variant="secondary", elem_classes=["btn-success-outline"])
                        delete_preset_btn = gr.Button("🗑️ Delete preset", variant="secondary", elem_classes=["btn-destructive", "action-spacer"], interactive=False)
                    confirm_delete_preset = gr.Checkbox(label="I understand this action is irreversible", value=False)
                    gr.Markdown("Deletes the selected preset. This cannot be undone.", elem_classes=["action-help"])
                    preset_out = gr.Textbox(label="ℹ️ Preset status", interactive=False)
                    validate_out = gr.JSON(label="ℹ️ Validation result")

            with gr.Column(scale=1):
                with gr.Accordion("Tool Details", open=True):
                    tool_name = gr.Textbox(label="Tool name", value="", interactive=False)
                    tool_desc = gr.Textbox(label="Tool description", value="", lines=2, interactive=False)
                    tool_ref = gr.Textbox(label="Tool reference", value="", interactive=False)
                    with gr.Accordion("Metadata (read-only)", open=False):
                        tool_card = gr.JSON(label="Tool card (metadata)", value={})

                with gr.Accordion("Advanced Configuration (JSON)", open=True):
                    field_state = gr.State(value=[])

                    field_labels = []
                    field_types = []
                    field_bool = []
                    field_num = []
                    field_text = []
                    field_sel = []

                    for i in range(SCHEMA_SLOTS):
                        with gr.Row(visible=False) as row:
                            lbl = gr.Markdown(f"**Field {i+1}**")
                            t = gr.Textbox(label="type", value="", visible=False)
                            b = gr.Checkbox(label="value", value=False, visible=False)
                            n = gr.Number(label="value", value=0, visible=False)
                            tx = gr.Textbox(label="value", value="", visible=False, lines=2)
                            sel = gr.Dropdown(label="value", choices=[], value=None, visible=False)
                        field_labels.append((row, lbl))
                        field_types.append(t)
                        field_bool.append(b)
                        field_num.append(n)
                        field_text.append(tx)
                        field_sel.append(sel)

                    with gr.Row(elem_classes=["align-right"]):
                        build_cfg_btn = gr.Button("🔁 Sync JSON Fields", variant="secondary")
                    tool_cfg = gr.JSON(label="Tool config JSON (synced)", value={})

                with gr.Accordion("🧩 Diagnostics", open=False):
                    selected_project_id3 = gr.Textbox(label="Selected Project ID (auto)", interactive=False)
                    registry_summary_wb = gr.Markdown("Tools loaded: 0 | New since last refresh: 0 | Last refresh: -")
                    registry_time_wb = gr.Markdown("Registry last refreshed: -")
                    registry_new_wb = gr.Markdown("New tools: None")
                    registry_errors_wb = gr.JSON(label="Registry load errors (if any)", value=[])
                    adapter_errors_wb = gr.JSON(label="Adapter load errors (if any)", value=ADAPTER_LOAD_ERRORS)
        project_state.change(ui_sync_project_label, inputs=[project_state], outputs=[selected_project_id3])

        schema_outputs = []
        for i in range(SCHEMA_SLOTS):
            schema_outputs += [field_labels[i][0], field_labels[i][1], field_types[i], field_bool[i], field_num[i], field_text[i], field_sel[i]]

        load_outputs = [tool_name, tool_desc, tool_cfg, tool_ref, preset_dd, tool_card] + schema_outputs + [field_state]
        load_tool_btn.click(ui_load_tool_with_schema, inputs=[tool_dd, project_state, preset_dd, system_type_wb, access_mode_wb], outputs=load_outputs)
        preset_dd.change(ui_load_tool_with_schema, inputs=[tool_dd, project_state, preset_dd, system_type_wb, access_mode_wb], outputs=load_outputs)
        tool_dd.change(ui_load_tool_with_schema, inputs=[tool_dd, project_state, preset_dd, system_type_wb, access_mode_wb], outputs=load_outputs)

        refresh_tools_btn.click(
            ui_refresh_tools_and_load,
            inputs=[system_type_wb, access_mode_wb, module_group_wb, project_state, preset_dd, tool_ids_state],
            outputs=[tool_ids_state, registry_summary_wb, registry_time_wb, registry_new_wb, tool_dd, registry_errors_wb] + load_outputs,
        )
        registry_time_wb.change(lambda t: t.replace("Registry last refreshed:", "Registry refreshed at"), inputs=[registry_time_wb], outputs=[registry_refresh_status])
        access_mode_wb.change(ui_toggle_api_url, inputs=[access_mode_wb], outputs=[api_base_url_box])
        access_mode_wb.change(ui_adapter_choices, inputs=[access_mode_wb], outputs=[adapter_wb, adapter_label_map_state_wb])

        value_inputs = []
        for i in range(SCHEMA_SLOTS):
            value_inputs += [field_bool[i], field_num[i], field_text[i], field_sel[i]]

        build_cfg_btn.click(
            ui_build_config_from_fields,
            inputs=[tool_dd, field_state] + value_inputs,
            outputs=[tool_cfg],
        )

        preset_dd.change(ui_toggle_delete_preset, inputs=[preset_dd, confirm_delete_preset], outputs=[delete_preset_btn])
        confirm_delete_preset.change(ui_toggle_delete_preset, inputs=[preset_dd, confirm_delete_preset], outputs=[delete_preset_btn])

        save_preset_btn.click(ui_save_preset, inputs=[project_state, tool_dd, preset_name_new, set_active, tool_cfg], outputs=[preset_out])
        save_preset_btn.click(ui_load_tool_with_schema, inputs=[tool_dd, project_state, preset_dd, system_type_wb, access_mode_wb], outputs=load_outputs)

        delete_preset_btn.click(ui_delete_preset, inputs=[project_state, tool_dd, preset_dd], outputs=[preset_out])
        delete_preset_btn.click(ui_load_tool_with_schema, inputs=[tool_dd, project_state, preset_dd, system_type_wb, access_mode_wb], outputs=load_outputs)

        validate_cfg_btn.click(ui_validate_tool_config, inputs=[tool_dd, tool_cfg], outputs=[validate_out])

        smoke_btn.click(ui_run_smoke_test, inputs=[project_state, tool_dd, system_type_wb, access_mode_wb, adapter_wb, adapter_label_map_state_wb, api_base_url_wb, tool_cfg], outputs=[smoke_out, smoke_tbl])

        fixture_access_mode.change(ui_fixture_choices, inputs=[fixture_access_mode], outputs=[fixture_dd, fixture_label_map_state])
        run_fixture_btn.click(ui_run_fixture_test, inputs=[project_state, tool_dd, fixture_access_mode, fixture_dd, fixture_label_map_state, tool_cfg, save_fixture_evidence], outputs=[fixture_status, fixture_result])

        system_type_wb.change(
            ui_refresh_tools_and_load,
            inputs=[system_type_wb, access_mode_wb, module_group_wb, project_state, preset_dd, tool_ids_state],
            outputs=[tool_ids_state, registry_summary_wb, registry_time_wb, registry_new_wb, tool_dd, registry_errors_wb] + load_outputs,
        )
        access_mode_wb.change(
            ui_refresh_tools_and_load,
            inputs=[system_type_wb, access_mode_wb, module_group_wb, project_state, preset_dd, tool_ids_state],
            outputs=[tool_ids_state, registry_summary_wb, registry_time_wb, registry_new_wb, tool_dd, registry_errors_wb] + load_outputs,
        )
        module_group_wb.change(
            ui_refresh_tools_and_load,
            inputs=[system_type_wb, access_mode_wb, module_group_wb, project_state, preset_dd, tool_ids_state],
            outputs=[tool_ids_state, registry_summary_wb, registry_time_wb, registry_new_wb, tool_dd, registry_errors_wb] + load_outputs,
        )

    # UI: Scenario generation and curation workflow.
    with gr.Tab("🧪 3) Scenario Studio"):
        gr.Markdown("## Scenario Studio")
        gr.Markdown("Step 3 of 6: Create scenarios to test your selected system.")

        with gr.Group(elem_classes=["context-card"]):
            project_banner_3b = gr.Markdown(ui_project_banner(None, None))
            project_warning_3b = gr.Markdown("No active project selected - go to Project tab.")
            selected_project_id3b = gr.Textbox(label="Selected Project ID (auto)", interactive=False)
            project_state.change(ui_sync_project_label, inputs=[project_state], outputs=[selected_project_id3b])
            project_state.change(ui_project_banner, inputs=[project_state, last_action_state], outputs=[project_banner_3b])
            project_state.change(lambda pid: "" if pid else "No active project selected - go to Project tab.", inputs=[project_state], outputs=[project_warning_3b])
            last_action_state.change(ui_project_banner, inputs=[project_state, last_action_state], outputs=[project_banner_3b])

        cases_state = gr.State(value=[])
        generator_cfg_state = gr.State(value={})

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("### 1) Seed Input")
            gr.HTML('<div class="helper">Paste business examples and define objectives/risk focus.</div>')
            with gr.Row():
                with gr.Column():
                    seed_text = gr.Textbox(label="Seed examples (one per line)", lines=6, placeholder="Paste examples here...")
                with gr.Column():
                    scenario_system_type = gr.Dropdown(
                        label="System type",
                        choices=list(SCENARIO_SYSTEM_TYPES.keys()),
                        value=list(SCENARIO_SYSTEM_TYPES.keys())[0],
                    )
                    with gr.Group(elem_classes=["compact-card"]):
                        gr.Markdown("Objectives")
                        objective_quality = gr.Checkbox(label="quality", value=True)
                        objective_policy = gr.Checkbox(label="policy", value=True)
                        objective_security = gr.Checkbox(label="security", value=False)
                        objective_rag_grounding = gr.Checkbox(label="rag_grounding", value=False)
                        objective_agent_planning = gr.Checkbox(label="agent_planning", value=False)
            with gr.Row():
                topic_tag = gr.Textbox(label="Topic tag", placeholder="payments / onboarding / ...")
                persona_tag = gr.Textbox(label="Persona tag", placeholder="customer / analyst / ...")
                channel_tag = gr.Textbox(label="Channel tag", placeholder="web / chat / email / ...")
                risk_focus = gr.Textbox(label="Risk focus (comma separated)", placeholder="pii, policy, injection")

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("### 2) Generator Selection")
            gr.HTML('<div class="helper">Pick a generator and configure parameters.</div>')
            with gr.Row():
                generator_choices, generator_label_map_default = _generator_choices()
                generator_dd = gr.Dropdown(label="Generator", choices=generator_choices, value=(generator_choices[0] if generator_choices else None))
                refresh_generators_btn = gr.Button("Refresh generators", variant="secondary")
            generator_label_map_state = gr.State(value=generator_label_map_default)
            with gr.Row():
                backend_dd = gr.Dropdown(label="Generator backend", choices=["stub", "workbench_llm"], value="stub")
                num_cases = gr.Number(label="Target cases", value=12, precision=0)
                diversify = gr.Checkbox(label="Diversify", value=True)
                expand = gr.Checkbox(label="Expand", value=True)
                dedupe_threshold = gr.Number(label="Near-dupe threshold", value=0.86, precision=2)
                seed_value = gr.Number(label="Random seed", value=42, precision=0)
            with gr.Accordion("Generator diagnostics", open=False):
                generator_errors = gr.JSON(label="Generator load errors", value=GENERATOR_LOAD_ERRORS)

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("### 3) Generate Preview")
            gr.HTML('<div class="helper">Review generated cases and dedupe/tag stats.</div>')
            generate_btn = gr.Button("Generate scenarios", variant="primary")
            gen_status = gr.Textbox(label="Generation status")
            preview_tbl = gr.Dataframe(
                headers=["case_id", "inputs", "tags", "objectives", "source_examples"],
                interactive=False,
            )
            gen_stats = gr.JSON(label="Generation stats", value={})

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("### 4) Curation")
            gr.HTML('<div class="helper">Edit tags/objectives, approve cases, or remove them.</div>')
            curation_tbl = gr.Dataframe(
                headers=["case_id", "approved_for_validation", "inputs", "tags", "objectives"],
                interactive=True,
            )
            with gr.Row():
                apply_curation_btn = gr.Button("Apply curation", variant="secondary")
                delete_ids = gr.Textbox(label="Delete case_ids (comma separated)")
                delete_cases_btn = gr.Button("Delete cases", variant="secondary", elem_classes=["btn-destructive"])
            curation_status = gr.Textbox(label="Curation status")

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("### 5) Save Dataset")
            gr.HTML('<div class="helper">Save curated cases under the active project.</div>')
            with gr.Row():
                dataset_name = gr.Textbox(label="Dataset name")
                dataset_desc = gr.Textbox(label="Dataset description")
            save_dataset_btn = gr.Button("Save dataset", variant="primary")
            dataset_status = gr.Textbox(label="Save status")
            dataset_id_out = gr.Textbox(label="Dataset ID", interactive=False)

        refresh_generators_btn.click(ui_refresh_generators, inputs=[], outputs=[generator_dd, generator_label_map_state, generator_errors])
        generate_btn.click(
            ui_generate_scenarios,
            inputs=[
                project_state,
                seed_text,
                scenario_system_type,
                objective_quality,
                objective_policy,
                objective_security,
                objective_rag_grounding,
                objective_agent_planning,
                topic_tag,
                persona_tag,
                channel_tag,
                generator_dd,
                generator_label_map_state,
                backend_dd,
                num_cases,
                diversify,
                expand,
                risk_focus,
                dedupe_threshold,
                seed_value,
            ],
            outputs=[gen_status, preview_tbl, curation_tbl, gen_stats, cases_state, generator_cfg_state],
        )
        apply_curation_btn.click(ui_apply_curation, inputs=[curation_tbl, cases_state], outputs=[curation_status, cases_state, curation_tbl])
        delete_cases_btn.click(ui_delete_cases, inputs=[delete_ids, cases_state], outputs=[curation_status, cases_state, preview_tbl, curation_tbl])
        save_dataset_btn.click(
            ui_save_dataset,
            inputs=[project_state, dataset_name, dataset_desc, cases_state, generator_dd, generator_label_map_state, backend_dd, generator_cfg_state],
            outputs=[dataset_status, dataset_id_out],
        )

    # UI: Emphasize scope -> tools -> execution flow and a status panel.
    with gr.Tab("🚀 4) Run Tests (Suite Runner)"):
        gr.Markdown("## Run Validation Tests")
        gr.Markdown("Step 4 of 6: Execute selected tools against fixtures or scenario datasets.")
        gr.Markdown("Follow the flow: 1) Scope 2) Select coverage 3) Run suite 4) Monitor status.")
        project_banner_4 = gr.Markdown("No active project selected — go to Project tab to select one.")
        project_state.change(
            lambda pid, act: (
                "No active project selected — go to Project tab to select one."
                if not pid
                else f"Active Project: {pid} | Last action: {act or 'None'}"
            ),
            inputs=[project_state, last_action_state],
            outputs=[project_banner_4],
        )

        gr.Markdown("### 1) Scope")
        with gr.Group(elem_classes=["section-card"]):
            gr.HTML('<div class="helper">Define the system type and access mode for this suite run.</div>')
            adapter_choices_run, adapter_label_map_default_run = _adapter_choices(DEFAULT_ACCESS)
            with gr.Row():
                system_type_run = gr.Dropdown(label="System Type", choices=SYSTEM_TYPES, value="Agentic AI")
                access_mode_run = gr.Dropdown(label="Access Mode", choices=ACCESS_MODES, value="traced")
                adapter_run = gr.Dropdown(label="Adapter", choices=adapter_choices_run, value=(adapter_choices_run[0] if adapter_choices_run else None))
            adapter_label_map_state_run = gr.State(value=adapter_label_map_default_run)
            gr.HTML('<div class="helper">black_box uses API-only access; traced/white_box require instrumentation via adapters.</div>')
            api_base_url_box_run = gr.Group(visible=False)
            with api_base_url_box_run:
                api_base_url_run = gr.Textbox(label="Model API base URL (black-box)", value="http://127.0.0.1:8000")
                gr.HTML('<div class="helper">Only required for black-box access.</div>')

        gr.Markdown("### 2) Select Coverage")
        with gr.Group(elem_classes=["section-card"]):
            gr.HTML('<div class="legend-box">✅ Available | ⚠️ Limited | ❌ Unavailable</div>')
            gr.HTML('<div class="helper">Pick module groups and tools to include in this run.</div>')
            with gr.Row():
                with gr.Column():
                    module_group_ms = gr.Dropdown(
                        label="Module Groups (with coverage badges)",
                        choices=INITIAL_MODULE_CHOICES,
                        value=INITIAL_MODULE_CHOICES,
                        multiselect=True,
                        elem_classes=["compact-multiselect"],
                    )
                with gr.Column():
                    tool_ms = gr.Dropdown(
                        label="Tools (filtered + coverage badges)",
                        choices=INITIAL_TOOL_CHOICES,
                        value=INITIAL_TOOL_CHOICES,
                        multiselect=True,
                        elem_classes=["compact-multiselect"],
                    )
            gr.HTML('<div class="helper">Select tools to include in this run.</div>')
            gr.HTML('<div class="helper">Tools are constrained by System Type + Access Mode.</div>')
            reload_registry_run_btn = gr.Button("Refresh tool registry", variant="secondary")

        gr.Markdown("### 3) Dataset Source")
        with gr.Group(elem_classes=["section-card"]):
            gr.HTML('<div class="helper">Choose fixture data or project-scoped scenario datasets.</div>')
            dataset_source = gr.Dropdown(label="Dataset source", choices=["Fixtures", "Scenario Datasets"], value="Fixtures")
            fixtures_group = gr.Group(visible=True)
            with fixtures_group:
                with gr.Row():
                    sample_n = gr.Number(label="Sample size (n)", value=6, precision=0)
                    sample_mode = gr.Dropdown(label="Sampling mode", choices=["first_n", "random"], value="first_n")
            scenario_group = gr.Group(visible=False)
            with scenario_group:
                scenario_dataset_choices, scenario_dataset_label_map_default = _scenario_dataset_choices(None)
                scenario_dataset_dd = gr.Dropdown(label="Scenario dataset", choices=scenario_dataset_choices, value=None)
                scenario_dataset_label_map_state = gr.State(value=scenario_dataset_label_map_default)
                refresh_datasets_btn = gr.Button("Refresh datasets", variant="secondary")
                scenario_approved_only = gr.Checkbox(label="Approved for validation only", value=True)
                with gr.Row():
                    scenario_topic = gr.Textbox(label="Topic tag filter", placeholder="payments")
                    scenario_persona = gr.Textbox(label="Persona tag filter", placeholder="customer")
                    scenario_channel = gr.Textbox(label="Channel tag filter", placeholder="web")
                    scenario_risk_focus = gr.Textbox(label="Risk tag filter (comma separated)", placeholder="pii, injection")
                with gr.Row():
                    scenario_obj_quality = gr.Checkbox(label="quality", value=False)
                    scenario_obj_policy = gr.Checkbox(label="policy", value=False)
                    scenario_obj_security = gr.Checkbox(label="security", value=False)
                    scenario_obj_rag_grounding = gr.Checkbox(label="rag_grounding", value=False)
                    scenario_obj_agent_planning = gr.Checkbox(label="agent_planning", value=False)
                scenario_limit = gr.Number(label="Case limit (first N)", value=20, precision=0)

        gr.Markdown("### 4) Run Suite")
        with gr.Group(elem_classes=["section-card"]):
            gr.HTML('<div class="helper">Execute the selected tools using the configured scope and options.</div>')
            use_presets = gr.Checkbox(label="Apply active presets (recommended)", value=True)
            with gr.Row(elem_classes=["action-row"]):
                run_btn = gr.Button("Run Suite", variant="primary")
                cancel_btn = gr.Button("Cancel Run", variant="secondary", elem_classes=["btn-destructive", "action-spacer"])
            with gr.Group(elem_classes=["section-card"]):
                gr.Markdown("Run Options (optional)")
                with gr.Accordion("Overrides (advanced)", open=False):
                    with gr.Row():
                        override_tool_id1 = gr.Dropdown(label="Tool to override (1)", choices=sorted(list(TOOL_REGISTRY_OBJ.keys())), value=None)
                        override_cfg1 = gr.JSON(label="Override config JSON (1)", value={})
                    with gr.Row():
                        override_tool_id2 = gr.Dropdown(label="Tool to override (2)", choices=sorted(list(TOOL_REGISTRY_OBJ.keys())), value=None)
                        override_cfg2 = gr.JSON(label="Override config JSON (2)", value={})
            preset_status_preview = gr.Dataframe(headers=["tool_id", "preset_status"], interactive=False)
            with gr.Accordion("Full preset status (all tools)", open=False):
                preset_status_tbl = gr.Dataframe(headers=["tool_id", "preset_status"], interactive=False)

        gr.Markdown("### 5) Run Status & Logs")
        with gr.Group(elem_classes=["section-card"]):
            with gr.Row():
                with gr.Column():
                    gr.Markdown("Suite execution status")
                    gr.HTML('<div class="helper">Monitor progress and review output for each tool.</div>')
                with gr.Column():
                    with gr.Row(elem_classes=["align-right"]):
                        refresh_status_btn = gr.Button("Refresh status", variant="secondary")
                        auto_refresh = gr.Checkbox(label="Auto-refresh every 5s", value=False)
            run_status_out = gr.Textbox(label="Run status")
            current_run_panel = gr.JSON(label="Current run")
            run_status_tbl = gr.Dataframe(
                headers=["tool_id", "status", "last_update", "error", "avg_score", "fail_count", "finding_count"],
                interactive=False,
            )
            run_log_preview = gr.Textbox(label="Execution log (latest 5 lines)", lines=5, elem_classes=["log-box"])
            with gr.Accordion("Show run logs (advanced)", open=False):
                run_log = gr.Textbox(label="Execution log (per tool)", lines=6, elem_classes=["log-box"])

        open_results_btn = gr.Button("Open Results", variant="secondary", elem_classes=["btn-tertiary"])

        with gr.Accordion("Diagnostics", open=False):
            selected_project_id4 = gr.Textbox(label="Selected Project ID (auto)", interactive=False)
            registry_summary_run = gr.Markdown("Tools loaded: 0 | New since last refresh: 0 | Last refresh: -")
            registry_new_run = gr.Markdown("New tools: None")
            registry_time_run = gr.Markdown("Registry last refreshed: -")
            registry_errors_run = gr.JSON(label="Registry load errors (if any)", value=[])
            adapter_errors_run = gr.JSON(label="Adapter load errors (if any)", value=ADAPTER_LOAD_ERRORS)
        project_state.change(ui_sync_project_label, inputs=[project_state], outputs=[selected_project_id4])

        reload_registry_run_btn.click(
            ui_reload_registry_run,
            inputs=[system_type_run, access_mode_run, module_group_ms, tool_ms, tool_ids_state],
            outputs=[tool_ids_state, registry_summary_run, registry_time_run, registry_new_run, registry_errors_run, module_group_ms, module_label_map_state, tool_ms, tool_label_map_state],
        )
        reload_registry_run_btn.click(ui_tool_preset_status_with_preview, inputs=[project_state, tool_ms, tool_label_map_state], outputs=[preset_status_preview, preset_status_tbl])

        system_type_run.change(
            ui_refresh_modules_and_tools,
            inputs=[system_type_run, access_mode_run, module_group_ms, tool_ms],
            outputs=[module_group_ms, module_label_map_state, tool_ms, tool_label_map_state],
        )
        access_mode_run.change(
            ui_refresh_modules_and_tools,
            inputs=[system_type_run, access_mode_run, module_group_ms, tool_ms],
            outputs=[module_group_ms, module_label_map_state, tool_ms, tool_label_map_state],
        )
        access_mode_run.change(ui_toggle_api_url, inputs=[access_mode_run], outputs=[api_base_url_box_run])
        access_mode_run.change(ui_adapter_choices, inputs=[access_mode_run], outputs=[adapter_run, adapter_label_map_state_run])
        dataset_source.change(ui_toggle_dataset_source, inputs=[dataset_source], outputs=[fixtures_group, scenario_group])
        refresh_datasets_btn.click(ui_refresh_scenario_datasets, inputs=[project_state], outputs=[scenario_dataset_dd, scenario_dataset_label_map_state])
        project_state.change(ui_refresh_scenario_datasets, inputs=[project_state], outputs=[scenario_dataset_dd, scenario_dataset_label_map_state])

        module_group_ms.change(
            ui_filter_tools_with_badges,
            inputs=[system_type_run, access_mode_run, module_group_ms, tool_ms, module_label_map_state],
            outputs=[tool_ms, tool_label_map_state],
        )
        module_group_ms.change(ui_tool_preset_status_with_preview, inputs=[project_state, tool_ms, tool_label_map_state], outputs=[preset_status_preview, preset_status_tbl])
        tool_ms.change(ui_tool_preset_status_with_preview, inputs=[project_state, tool_ms, tool_label_map_state], outputs=[preset_status_preview, preset_status_tbl])
        project_state.change(ui_tool_preset_status_with_preview, inputs=[project_state, tool_ms, tool_label_map_state], outputs=[preset_status_preview, preset_status_tbl])

        run_btn.click(
            ui_run_suite_with_preview,
            inputs=[
                project_state,
                system_type_run,
                access_mode_run,
                adapter_run,
                adapter_label_map_state_run,
                api_base_url_run,
                use_presets,
                tool_ms,
                tool_label_map_state,
                dataset_source,
                scenario_dataset_dd,
                scenario_dataset_label_map_state,
                scenario_approved_only,
                scenario_topic,
                scenario_persona,
                scenario_channel,
                scenario_risk_focus,
                scenario_obj_quality,
                scenario_obj_policy,
                scenario_obj_security,
                scenario_obj_rag_grounding,
                scenario_obj_agent_planning,
                scenario_limit,
                sample_n,
                sample_mode,
                override_tool_id1,
                override_cfg1,
                override_tool_id2,
                override_cfg2,
            ],
            outputs=[run_status_out, run_state, current_run_panel, run_status_tbl, run_log_preview, run_log],
        )

        refresh_status_btn.click(ui_refresh_run_status_with_preview, inputs=[run_state], outputs=[current_run_panel, run_status_tbl, run_log_preview, run_log])
        cancel_btn.click(ui_cancel_run, inputs=[run_state], outputs=[run_status_out])
        open_results_btn.click(lambda rid: rid, inputs=[run_state], outputs=[run_state])

    # UI: Two-column layout for run list (left) and trace details (right).
    with gr.Tab("📊 5) Results & Traces"):
        gr.Markdown("## Results & Traces")
        gr.Markdown("Step 5 of 6: Inspect results, traces, and evaluation evidence.")
        gr.Markdown("Browse completed runs, inspect trace evidence, and select items for reporting.")

        with gr.Group(elem_classes=["context-card"]):
            gr.Markdown("### Project Context")
            project_banner_5 = gr.Markdown(ui_project_banner(None, None))
            project_warning_5 = gr.Markdown("No active project selected - go to Project tab.")
            selected_project_id5 = gr.Textbox(label="Selected Project ID (auto)", interactive=False)
            project_state.change(ui_sync_project_label, inputs=[project_state], outputs=[selected_project_id5])
            project_state.change(ui_project_banner, inputs=[project_state, last_action_state], outputs=[project_banner_5])
            project_state.change(lambda pid: "" if pid else "No active project selected - go to Project tab.", inputs=[project_state], outputs=[project_warning_5])
            last_action_state.change(ui_project_banner, inputs=[project_state, last_action_state], outputs=[project_banner_5])

        with gr.Row():
            with gr.Column():
                with gr.Group(elem_classes=["section-card"]):
                    with gr.Row(elem_classes=["card-header"]):
                        gr.Markdown("### Runs")
                        refresh_runs_tbl_btn = gr.Button("Refresh Run Table", variant="primary")
                    runs_tbl = gr.Dataframe(
                        headers=["run_id", "created_at", "status", "run_mode", "system_type", "access_mode", "pass_rate", "total"],
                        interactive=False,
                    )
                    with gr.Row(elem_classes=["align-right"]):
                        refresh_runs_btn = gr.Button("Refresh Run List", variant="primary", elem_classes=["btn-sm"])
                    gr.HTML('<div class="helper">Select a run to browse trace evidence.</div>')
                    run_dd = gr.Dropdown(label="Select Run", choices=[], value=None)
                    selected_run_id2 = gr.Textbox(label="Selected Run ID (auto)", interactive=False)
                    run_state.change(lambda rid: rid or "", inputs=[run_state], outputs=[selected_run_id2])

                    with gr.Accordion("Run Metadata", open=False):
                        run_meta = gr.JSON(label="Run Metadata", value={})

                    refresh_runs_tbl_btn.click(ui_run_table, inputs=[project_state], outputs=[runs_tbl])
                    refresh_runs_btn.click(ui_refresh_runs, inputs=[project_state], outputs=[run_dd])
                    project_state.change(ui_refresh_runs, inputs=[project_state], outputs=[run_dd])
                    run_dd.change(ui_select_run, inputs=[run_dd, project_state], outputs=[run_state])
                    run_state.change(ui_run_metadata, inputs=[run_state], outputs=[run_meta])

                with gr.Group(elem_classes=["section-card"]):
                    with gr.Row(elem_classes=["card-header"]):
                        gr.Markdown("### Traces")
                        with gr.Row(elem_classes=["action-row"]):
                            traces_btn = gr.Button("Load Traces", variant="primary")
                            refresh_choices_btn = gr.Button("Refresh Trace List", variant="primary")
                    gr.HTML('<div class="helper">Trace rows populate the selector below.</div>')
                    traces_tbl = gr.Dataframe(
                        headers=["trace_id", "input", "score", "pass/fail", "created_at"],
                        interactive=False,
                    )
                    traces_btn.click(ui_list_traces, inputs=[run_state], outputs=[traces_tbl])
                    trace_dd = gr.Dropdown(label="Trace ID (Detail)", choices=[], value=None)
                    trace_delete_select = gr.Dropdown(label="Traces to delete (multi-select)", choices=[], multiselect=True, value=[])
                    trace_report_select = gr.Dropdown(label="Traces to include in report (multi-select)", choices=[], multiselect=True, value=[], visible=False)
                    gr.HTML('<div class="helper">Pick traces to inspect or delete from this run.</div>')

            with gr.Column():
                with gr.Group(elem_classes=["section-card"]):
                    with gr.Row(elem_classes=["card-header"]):
                        gr.Markdown("### Trace Details")
                        trace_detail_btn = gr.Button("View Trace Detail", variant="primary")
                    with gr.Accordion("Evidence Request", open=False):
                        evidence_request_json = gr.JSON(label="Evidence request", elem_classes=["json-box"])
                    with gr.Accordion("Evidence Response", open=False):
                        evidence_response_json = gr.JSON(label="Evidence response", elem_classes=["json-box"])
                    with gr.Accordion("Evidence RAG", open=False):
                        evidence_rag_json = gr.JSON(label="Evidence RAG", elem_classes=["json-box"])
                    with gr.Accordion("Evidence Agent", open=False):
                        evidence_agent_json = gr.JSON(label="Evidence agent", elem_classes=["json-box"])
                    with gr.Accordion("Evidence Trace", open=False):
                        evidence_trace_json = gr.JSON(label="Evidence trace", elem_classes=["json-box"])
                    with gr.Accordion("Trace JSON Record", open=True):
                        trace_json = gr.JSON(label="Trace detail (record + evals)", elem_classes=["json-box"])
                    with gr.Accordion("Raw trace detail", open=False):
                        gr.Markdown("Expanded trace detail is available in the JSON record.")
                    trace_detail_btn.click(ui_trace_detail, inputs=[trace_dd], outputs=[trace_json])
                    trace_detail_btn.click(ui_trace_evidence_sections, inputs=[trace_dd], outputs=[evidence_request_json, evidence_response_json, evidence_rag_json, evidence_agent_json, evidence_trace_json])

                with gr.Group(elem_classes=["danger-card"]):
                    gr.Markdown("### Danger Zone")
                    gr.HTML('<div class="helper">Use only to remove test data from the demo.</div>')
                    confirm_delete_runs = gr.Checkbox(label="I understand this action is irreversible", value=False)
                    with gr.Row(elem_classes=["action-row"]):
                        del_run_btn = gr.Button("Delete Run", variant="secondary", elem_classes=["btn-destructive"], interactive=False)
                        del_traces_btn = gr.Button("Delete Traces", variant="secondary", elem_classes=["btn-destructive"], interactive=False)
                    del_run_out = gr.Textbox(label="Delete Run Status")
                    del_traces_out = gr.Textbox(label="Delete Traces Status")
        refresh_choices_btn.click(ui_trace_ids_for_run, inputs=[run_state], outputs=[trace_dd, trace_delete_select, trace_report_select])
        del_run_btn.click(ui_delete_run, inputs=[run_state], outputs=[del_run_out])
        del_traces_btn.click(ui_delete_traces, inputs=[run_state, trace_delete_select], outputs=[del_traces_out])
        confirm_delete_runs.change(ui_toggle_delete_actions, inputs=[confirm_delete_runs], outputs=[del_run_btn, del_traces_btn])

    # UI: Step-by-step evidence workflow with report preview and download.
    with gr.Tab("📄 6) Report & Evidence"):
        gr.Markdown("## Validation Report & Evidence Pack")
        gr.Markdown("Step 6 of 6: Generate reports and evidence packs.")
        gr.Markdown("Curate evidence and generate an audit-ready report for stakeholders.")
        with gr.Group(elem_classes=["context-card"]):
            project_banner_6 = gr.Markdown(ui_project_banner(None, None))
            selected_project_id6 = gr.Textbox(label="Selected Project ID (auto)", interactive=False)
        project_state.change(ui_sync_project_label, inputs=[project_state], outputs=[selected_project_id6])
        project_state.change(ui_project_banner, inputs=[project_state, last_action_state], outputs=[project_banner_6])
        last_action_state.change(ui_project_banner, inputs=[project_state, last_action_state], outputs=[project_banner_6])

        report_run_state = gr.State(value=None)

        with gr.Group(elem_classes=["section-card"]):
            with gr.Row(elem_classes=["card-header"]):
                gr.Markdown("### 1) Select Run")
            gr.HTML('<div class="helper">Select a run and preview available traces.</div>')
            with gr.Row():
                refresh_report_results_btn = gr.Button("Refresh Results", variant="primary", elem_classes=["btn-md"])
                with gr.Row(elem_classes=["align-right"]):
                    refresh_runs_for_report = gr.Button("Refresh Runs", variant="primary", elem_classes=["btn-inline"])
            report_runs_tbl = gr.Dataframe(
                headers=["run_id", "created_at", "status", "run_mode", "system_type", "access_mode", "pass_rate", "total"],
                interactive=False,
                elem_classes=["table-scroll"],
            )
            run_active_for_traces = gr.Dropdown(label="Select run to pick traces", choices=[], value=None)
            gr.HTML('<div class="helper">Pick a run to load its trace list.</div>')
            with gr.Accordion("Trace Preview (optional)", open=False):
                report_traces_tbl = gr.Dataframe(headers=["trace_id", "input", "score", "pass/fail", "created_at"], interactive=False)
            refresh_report_results_btn.click(ui_run_table, inputs=[project_state], outputs=[report_runs_tbl])
            refresh_report_results_btn.click(ui_list_traces, inputs=[report_run_state], outputs=[report_traces_tbl])

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("### 2) Select Evidence")
            gr.HTML('<div class="helper">Choose runs and traces to build the evidence pack.</div>')
            with gr.Row():
                with gr.Column():
                    run_ids_all = gr.Dropdown(label="Runs (multi-select)", choices=[], multiselect=True, value=[])
                    run_ids_state = gr.State(value=[])
                    trace_labels_dd = gr.Dropdown(label="Traces for selected run (optional, multi-select)", choices=[], multiselect=True, value=[])
                    trace_ids_state = gr.State(value=[])
                    tool_filter_dd = gr.Dropdown(label="Tool evaluations to include (optional)", choices=[], multiselect=True, value=[])
                with gr.Column():
                    with gr.Group(elem_classes=["actions-panel"]):
                        gr.Markdown("**Evidence Actions**")
                        add_runs_btn = gr.Button("Add Runs (All Traces)", variant="primary", elem_classes=["btn-md"])
                        add_traces_btn = gr.Button("Add Traces", variant="primary")
                        clear_evidence_btn = gr.Button("Clear Evidence", variant="secondary", elem_classes=["btn-destructive"])

            with gr.Accordion("Evidence Preview (JSON)", open=False):
                evidence_pack_state = gr.State(value=[])
                evidence_pack_view = gr.JSON(label="Evidence pack (editable)", value=[])

            refresh_runs_for_report.click(ui_refresh_runs, inputs=[project_state], outputs=[run_active_for_traces])
            refresh_runs_for_report.click(ui_refresh_runs_multi, inputs=[project_state], outputs=[run_ids_all])
            refresh_runs_for_report.click(ui_tool_filter_options, inputs=[report_run_state], outputs=[tool_filter_dd])

            run_active_for_traces.change(ui_select_run, inputs=[run_active_for_traces, project_state], outputs=[report_run_state])
            run_active_for_traces.change(ui_traces_for_run, inputs=[report_run_state], outputs=[trace_labels_dd])
            run_active_for_traces.change(ui_list_traces, inputs=[report_run_state], outputs=[report_traces_tbl])
            run_active_for_traces.change(ui_tool_filter_options, inputs=[report_run_state], outputs=[tool_filter_dd])
            run_active_for_traces.change(lambda: [], inputs=[], outputs=[trace_ids_state])

            add_runs_btn.click(ui_run_labels_to_ids, inputs=[project_state, run_ids_all], outputs=[run_ids_state])
            add_runs_btn.click(ui_add_evidence_pack_for_runs, inputs=[run_ids_state, tool_filter_dd, evidence_pack_state], outputs=[evidence_pack_state])
            add_runs_btn.click(lambda pack: pack, inputs=[evidence_pack_state], outputs=[evidence_pack_view])

            add_traces_btn.click(ui_trace_labels_to_ids, inputs=[report_run_state, trace_labels_dd], outputs=[trace_ids_state])
            add_traces_btn.click(ui_add_evidence_pack, inputs=[report_run_state, trace_ids_state, tool_filter_dd, evidence_pack_state], outputs=[evidence_pack_state])
            add_traces_btn.click(lambda pack: pack, inputs=[evidence_pack_state], outputs=[evidence_pack_view])

            clear_evidence_btn.click(ui_clear_evidence_pack, inputs=[], outputs=[evidence_pack_state])
            clear_evidence_btn.click(lambda pack: pack, inputs=[evidence_pack_state], outputs=[evidence_pack_view])

        with gr.Group(elem_classes=["section-card"]):
            gr.Markdown("### 3) Generate Report")
            gr.HTML('<div class="helper">Generate a report and download the evidence pack.</div>')
            with gr.Row(elem_classes=["action-row"]):
                rep_btn = gr.Button("Generate Report", variant="primary")
                download_report_btn = gr.Button("Download Report", variant="primary")
            rep_out = gr.File(label="Report file")
            report_preview = gr.Markdown("No report generated yet.", elem_classes=["json-box"])
            rep_btn.click(ui_generate_report_with_preview, inputs=[report_run_state, trace_ids_state, evidence_pack_state], outputs=[rep_out, report_preview])
            download_report_btn.click(ui_generate_report_with_preview, inputs=[report_run_state, trace_ids_state, evidence_pack_state], outputs=[rep_out, report_preview])

            with gr.Row(elem_classes=["action-row"]):
                zip_btn = gr.Button("Export Evidence Pack", variant="secondary")
            zip_out = gr.File(label="Evidence pack path")
            zip_btn.click(ui_export_evidence, inputs=[report_run_state, trace_ids_state], outputs=[zip_out])

demo.launch()










































