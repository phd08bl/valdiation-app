# MRO GenAI Validation Report (Demo)

- **Project ID:** proj_2f052f1868
- **Run ID:** run_4473158476
- **Generated:** 2025-12-27 18:46 UTC
- **System Type:** Agentic AI
- **Access Mode:** traced
- **Adapter Used:** fixture
- **Included traces:** 0
- **Pass:** 0  |  **Fail:** 0

## Scope (tools + coverage)

| Tool ID | Name | Coverage | Notes |
|---|---|---|---|
| faithfulness_hallucination | Faithfulness (Hallucination) | available |  |
| accuracy_groundtruth | Accuracy (Ground-truth / Labelled dataset) | available |  |
| answer_relevance | Answer Relevance | available |  |
| logic_coherence | Logic & Coherence | available |  |
| summarization_faithfulness | Summarisation Faithfulness | available |  |
| summarization_conciseness | Summarisation Conciseness | available |  |
| efficacy | Efficacy | available |  |
| toxicity_hap | Toxicity / HAP | available |  |
| bias_fairness | Bias & Fairness | available |  |
| pii_confidential_leakage | PII & Confidential Data Leakage | available |  |
| jailbreak_testing | Jailbreak Testing | available |  |
| prompt_injection | Prompt Injection | available |  |
| data_exfiltration_probe | Data Exfiltration Probes | available |  |
| context_retrieval_precision | Context Retrieval Precision | available |  |
| context_retrieval_recall | Context Retrieval Recall | available |  |
| tool_selection | Tool Selection | available |  |
| tool_argument_parsing | Argument Parsing (Tool Arguments) | available |  |
| reasoning_correctness | Reasoning Correctness | available |  |
| instruction_adherence | Instruction Adherence | available |  |
| cross_agent_logic_coherence | Logic & Coherence (cross-step / cross-agent) | available |  |
| agent_conflict | Agent Conflict | available |  |
| collusion_detection | Collusion | available |  |
| deadlock_loop_detection | Deadlock / Infinite Loops | available |  |
| emergent_unsafe_behavior | Emergent Unsafe Behaviour | available |  |
| trace_logic_coherence | Logic & Coherence (trace-based reasoning inspection) | available |  |
| execution_trace_span_recorder | Execution Trace & Span Recorder | available |  |
| validation_run_logbook | Validation Run Logbook | available |  |
| evidence_pack_generator | Validation Evidence Pack Generator | available |  |
| audit_ready_artifact_builder | Audit-Ready Validation Artefact Builder | available |  |
| efficiency_score | Efficacy (efficiency of output vs input) | available |  |
| latency_monitor | Latency | available |  |
| token_usage | Token Usage | available |  |
| cost_per_task | Cost per Task | available |  |
| tool_call_efficiency | Tool Call Efficiency | available |  |
| regulatory_compliance_validator | Regulatory / Policy Compliance Validator | available |  |
| vendor_model_change_check | Vendor Model Change Check Tool | available |  |
| material_change_revalidation_trigger | Material Change & Re-validation Trigger Engine | available |  |
| model_change_impact_risk_assessment | Model Change Impact & Risk Assessment Tool | available |  |
| model_retirement_evidence_validator | Model Decommissioning & Retirement Evidence Validator | available |  |

## Coverage Limitations

## Results (summary)

| Trace ID | Score | Pass/Fail | Input (preview) |
|---|---:|---|---|

## Evidence (example failures)

## Evidence Pack (selected payloads)
