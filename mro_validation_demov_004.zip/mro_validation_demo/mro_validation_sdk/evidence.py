﻿from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


ACCESS_MODES = ("black_box", "traced", "white_box")


class EVIDENCE:
    REQUEST_CASE_ID = "request.case_id"
    REQUEST_USER_INPUT = "request.user_input"
    REQUEST_SYSTEM_TYPE = "request.system_type"
    REQUEST_ACCESS_MODE = "request.access_mode"
    REQUEST_TIMESTAMP = "request.timestamp"
    REQUEST_METADATA = "request.metadata"

    RESPONSE_TEXT = "response.output_text"
    RESPONSE_RAW_OUTPUT = "response.raw_output"
    RESPONSE_MODEL_ID = "response.model_id"
    RESPONSE_MODEL_VERSION = "response.model_version"
    RESPONSE_LATENCY_MS = "response.latency_ms"
    RESPONSE_TOKEN_USAGE = "response.token_usage"
    RESPONSE_METADATA = "response.metadata"

    RAG_RETRIEVED_ITEMS = "rag.retrieved_items"
    RAG_CITATIONS = "rag.citations"
    RAG_METADATA = "rag.metadata"

    AGENT_STEPS = "agent.steps"
    AGENT_TOOL_CALLS = "agent.tool_calls"
    AGENT_METADATA = "agent.metadata"

    TRACE_ID = "trace.trace_id"
    TRACE_SPANS = "trace.spans"
    TRACE_LOGS = "trace.logs"
    TRACE_METADATA = "trace.metadata"

    CONFIG_SNAPSHOT = "config_snapshot"
    ATTACHMENTS = "attachments"


ALL_EVIDENCE_PATHS = {
    EVIDENCE.REQUEST_CASE_ID,
    EVIDENCE.REQUEST_USER_INPUT,
    EVIDENCE.REQUEST_SYSTEM_TYPE,
    EVIDENCE.REQUEST_ACCESS_MODE,
    EVIDENCE.REQUEST_TIMESTAMP,
    EVIDENCE.REQUEST_METADATA,
    EVIDENCE.RESPONSE_TEXT,
    EVIDENCE.RESPONSE_RAW_OUTPUT,
    EVIDENCE.RESPONSE_MODEL_ID,
    EVIDENCE.RESPONSE_MODEL_VERSION,
    EVIDENCE.RESPONSE_LATENCY_MS,
    EVIDENCE.RESPONSE_TOKEN_USAGE,
    EVIDENCE.RESPONSE_METADATA,
    EVIDENCE.RAG_RETRIEVED_ITEMS,
    EVIDENCE.RAG_CITATIONS,
    EVIDENCE.RAG_METADATA,
    EVIDENCE.AGENT_STEPS,
    EVIDENCE.AGENT_TOOL_CALLS,
    EVIDENCE.AGENT_METADATA,
    EVIDENCE.TRACE_ID,
    EVIDENCE.TRACE_SPANS,
    EVIDENCE.TRACE_LOGS,
    EVIDENCE.TRACE_METADATA,
    EVIDENCE.CONFIG_SNAPSHOT,
    EVIDENCE.ATTACHMENTS,
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def validate_access_mode(access_mode: str) -> bool:
    return access_mode in ACCESS_MODES


def _safe_copy(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _safe_copy(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_safe_copy(v) for v in value]
    return value


def _truncate_text(value: Any, limit: int = 500) -> Any:
    if not isinstance(value, str):
        return value
    if len(value) <= limit:
        return value
    return value[:limit] + "..."


def get_evidence_value(bundle: "EvidenceBundle", path: str) -> Any:
    if path not in ALL_EVIDENCE_PATHS:
        raise KeyError(f"Unsupported evidence path: {path}")
    parts = path.split(".")
    current: Any = bundle
    for part in parts:
        if current is None:
            return None
        if hasattr(current, part):
            current = getattr(current, part)
        elif isinstance(current, dict):
            current = current.get(part)
        else:
            return None
    return current


@dataclass
class EvidenceRequest:
    case_id: str
    user_input: str
    system_type: str
    access_mode: str
    timestamp: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "case_id": self.case_id,
            "user_input": self.user_input,
            "system_type": self.system_type,
            "access_mode": self.access_mode,
            "timestamp": self.timestamp,
            "metadata": _safe_copy(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidenceRequest":
        return cls(
            case_id=str(data.get("case_id", "")),
            user_input=str(data.get("user_input", "")),
            system_type=str(data.get("system_type", "")),
            access_mode=str(data.get("access_mode", "")),
            timestamp=str(data.get("timestamp", "")),
            metadata=dict(data.get("metadata") or {}),
        )


@dataclass
class EvidenceResponse:
    output_text: str
    raw_output: Optional[Dict[str, Any]] = None
    model_id: Optional[str] = None
    model_version: Optional[str] = None
    latency_ms: Optional[int] = None
    token_usage: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "output_text": self.output_text,
            "raw_output": _safe_copy(self.raw_output),
            "model_id": self.model_id,
            "model_version": self.model_version,
            "latency_ms": self.latency_ms,
            "token_usage": _safe_copy(self.token_usage),
            "metadata": _safe_copy(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidenceResponse":
        return cls(
            output_text=str(data.get("output_text", "")),
            raw_output=data.get("raw_output"),
            model_id=data.get("model_id"),
            model_version=data.get("model_version"),
            latency_ms=data.get("latency_ms"),
            token_usage=data.get("token_usage"),
            metadata=dict(data.get("metadata") or {}),
        )


@dataclass
class EvidenceRAG:
    retrieved_items: List[Dict[str, Any]] = field(default_factory=list)
    citations: Optional[List[Dict[str, Any]]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "retrieved_items": _safe_copy(self.retrieved_items),
            "citations": _safe_copy(self.citations),
            "metadata": _safe_copy(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidenceRAG":
        return cls(
            retrieved_items=list(data.get("retrieved_items") or []),
            citations=data.get("citations"),
            metadata=dict(data.get("metadata") or {}),
        )


@dataclass
class EvidenceAgent:
    steps: List[Dict[str, Any]] = field(default_factory=list)
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "steps": _safe_copy(self.steps),
            "tool_calls": _safe_copy(self.tool_calls),
            "metadata": _safe_copy(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidenceAgent":
        return cls(
            steps=list(data.get("steps") or []),
            tool_calls=list(data.get("tool_calls") or []),
            metadata=dict(data.get("metadata") or {}),
        )


@dataclass
class EvidenceTrace:
    trace_id: str
    spans: List[Dict[str, Any]] = field(default_factory=list)
    logs: Optional[List[Dict[str, Any]]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "spans": _safe_copy(self.spans),
            "logs": _safe_copy(self.logs),
            "metadata": _safe_copy(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidenceTrace":
        return cls(
            trace_id=str(data.get("trace_id", "")),
            spans=list(data.get("spans") or []),
            logs=data.get("logs"),
            metadata=dict(data.get("metadata") or {}),
        )


@dataclass
class EvidenceBundle:
    request: EvidenceRequest
    response: EvidenceResponse
    rag: Optional[EvidenceRAG] = None
    agent: Optional[EvidenceAgent] = None
    trace: Optional[EvidenceTrace] = None
    config_snapshot: Optional[Dict[str, Any]] = None
    attachments: Optional[List[Dict[str, Any]]] = None
    version: str = "mec.v0"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request": self.request.to_dict(),
            "response": self.response.to_dict(),
            "rag": self.rag.to_dict() if self.rag else None,
            "agent": self.agent.to_dict() if self.agent else None,
            "trace": self.trace.to_dict() if self.trace else None,
            "config_snapshot": _safe_copy(self.config_snapshot),
            "attachments": _safe_copy(self.attachments),
            "version": self.version,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidenceBundle":
        request = EvidenceRequest.from_dict(data.get("request") or {})
        response = EvidenceResponse.from_dict(data.get("response") or {})
        rag = EvidenceRAG.from_dict(data["rag"]) if data.get("rag") else None
        agent = EvidenceAgent.from_dict(data["agent"]) if data.get("agent") else None
        trace = EvidenceTrace.from_dict(data["trace"]) if data.get("trace") else None
        return cls(
            request=request,
            response=response,
            rag=rag,
            agent=agent,
            trace=trace,
            config_snapshot=data.get("config_snapshot"),
            attachments=data.get("attachments"),
            version=str(data.get("version", "mec.v0")),
        )

    def validate(self) -> tuple[bool, str]:
        access_mode = self.request.access_mode
        if not validate_access_mode(access_mode):
            return False, f"Invalid access_mode: {access_mode}"
        if access_mode in ("traced", "white_box"):
            if not self.trace:
                return False, "EvidenceTrace required for traced/white_box access modes."
            if not self.trace.trace_id:
                return False, "EvidenceTrace.trace_id required."
        return True, "ok"

    def to_redacted_dict(self, text_limit: int = 500) -> Dict[str, Any]:
        data = self.to_dict()
        if data.get("response"):
            data["response"]["raw_output"] = None
        if data.get("trace") and data["trace"].get("logs"):
            data["trace"]["logs"] = None
        if data.get("attachments"):
            data["attachments"] = None
        # Truncate long text fields for UI safety.
        data["request"]["user_input"] = _truncate_text(data["request"].get("user_input", ""), text_limit)
        data["response"]["output_text"] = _truncate_text(data["response"].get("output_text", ""), text_limit)
        return data

    def to_legacy_record(self) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "id": self.request.case_id,
            "input": self.request.user_input,
            "prompt": self.request.user_input,
            "answer": self.response.output_text,
            "output": self.response.output_text,
            "response": self.response.output_text,
            "latency_ms": self.response.latency_ms,
            "token_usage": self.response.token_usage or {},
            "model": {
                "name": self.response.model_id,
                "version": self.response.model_version,
            },
            "expected": {},
        }
        if self.rag and self.rag.retrieved_items:
            record["retrieved_contexts"] = [
                {
                    "text": item.get("text_snippet", ""),
                    "source": item.get("doc_id", ""),
                    "score": item.get("score"),
                }
                for item in self.rag.retrieved_items
            ]
            record["context"] = "\n\n".join([item.get("text_snippet", "") for item in self.rag.retrieved_items if item.get("text_snippet")])
        if self.agent:
            record["agent_steps"] = self.agent.steps
            record["tool_calls"] = [
                {
                    "tool": call.get("name"),
                    "args": call.get("args"),
                    "output": call.get("result"),
                    "status": call.get("status"),
                    "latency_ms": call.get("latency_ms"),
                    "error": call.get("error"),
                }
                for call in self.agent.tool_calls
            ]
        return record


def build_request(
    *,
    case_id: str,
    user_input: str,
    system_type: str,
    access_mode: str,
    timestamp: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> EvidenceRequest:
    return EvidenceRequest(
        case_id=case_id,
        user_input=user_input,
        system_type=system_type,
        access_mode=access_mode,
        timestamp=timestamp or _now_iso(),
        metadata=metadata or {},
    )

