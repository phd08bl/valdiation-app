from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .scenarios import ScenarioCase


@dataclass
class GeneratorContext:
    project_id: str
    system_type: str
    backend_id: str
    run_id: str
    stats: Dict[str, Any] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)


class BaseGenerator:
    generator_id: str = "base"
    name: str = "Base Generator"
    description: str = ""
    supported_system_types: Set[str] = set()
    supported_objectives: Set[str] = set()

    def config_schema(self) -> Dict[str, Any]:
        return {"fields": []}

    def generate(
        self,
        seed_cases: List[ScenarioCase],
        cfg: Dict[str, Any],
        ctx: GeneratorContext,
    ) -> List[ScenarioCase]:
        raise NotImplementedError

    def validate_config(self, cfg: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        return True, None
