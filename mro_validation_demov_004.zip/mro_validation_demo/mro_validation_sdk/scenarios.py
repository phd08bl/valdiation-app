from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _iso_utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class ScenarioCase:
    case_id: str
    system_type: str
    interaction_type: str
    inputs: Dict[str, Any]
    source_examples: List[str]
    objectives: Dict[str, Any]
    tags: Dict[str, Any]
    difficulty: Optional[str] = None
    expected_behavior: Optional[Dict[str, Any]] = None
    attachments: Optional[List[Dict[str, Any]]] = None
    approved_for_validation: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    version: str = "scenario.v0"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "ScenarioCase":
        return ScenarioCase(
            case_id=str(data.get("case_id", "")),
            system_type=str(data.get("system_type", "")),
            interaction_type=str(data.get("interaction_type", "")),
            inputs=dict(data.get("inputs") or {}),
            source_examples=list(data.get("source_examples") or []),
            objectives=dict(data.get("objectives") or {}),
            tags=dict(data.get("tags") or {}),
            difficulty=data.get("difficulty"),
            expected_behavior=data.get("expected_behavior"),
            attachments=data.get("attachments"),
            approved_for_validation=bool(data.get("approved_for_validation", False)),
            metadata=dict(data.get("metadata") or {}),
            version=str(data.get("version", "scenario.v0")),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @staticmethod
    def from_json(payload: str) -> "ScenarioCase":
        return ScenarioCase.from_dict(json.loads(payload))


@dataclass
class ScenarioDataset:
    dataset_id: str
    project_id: str
    name: str
    description: str
    created_ts: str
    cases: List[ScenarioCase]
    generator_config: Dict[str, Any]
    lineage: Dict[str, Any]
    version: str = "dataset.v0"

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["cases"] = [c.to_dict() for c in self.cases]
        return data

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "ScenarioDataset":
        return ScenarioDataset(
            dataset_id=str(data.get("dataset_id", "")),
            project_id=str(data.get("project_id", "")),
            name=str(data.get("name", "")),
            description=str(data.get("description", "")),
            created_ts=str(data.get("created_ts", _iso_utc_now())),
            cases=[ScenarioCase.from_dict(c) for c in (data.get("cases") or [])],
            generator_config=dict(data.get("generator_config") or {}),
            lineage=dict(data.get("lineage") or {}),
            version=str(data.get("version", "dataset.v0")),
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @staticmethod
    def from_json(payload: str) -> "ScenarioDataset":
        return ScenarioDataset.from_dict(json.loads(payload))


def iso_utc_now() -> str:
    return _iso_utc_now()
