from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional


def _first_value(record: Dict[str, Any], keys: Iterable[str]) -> Optional[Any]:
    for key in keys:
        if key in record and record.get(key) not in (None, ""):
            return record.get(key)
    return None


def _text_from_messages(messages: Any, role_preference: List[str]) -> str:
    if not isinstance(messages, list):
        return ""
    for role in role_preference:
        for msg in reversed(messages):
            if not isinstance(msg, dict):
                continue
            if str(msg.get("role", "")).lower() == role and msg.get("content"):
                return str(msg.get("content"))
    for msg in reversed(messages):
        if isinstance(msg, dict) and msg.get("content"):
            return str(msg.get("content"))
    return ""


def get_input_text(record: Dict[str, Any]) -> str:
    val = _first_value(record, ["input", "user_input", "query", "prompt", "user_prompt"])
    if val:
        return str(val)
    return _text_from_messages(record.get("messages"), ["user", "human"])


def get_output_text(record: Dict[str, Any]) -> str:
    val = _first_value(record, ["answer", "output", "response", "model_output", "assistant_response"])
    if val:
        return str(val)
    return _text_from_messages(record.get("messages"), ["assistant", "ai"])


def _join_text_items(items: List[Any]) -> str:
    parts: List[str] = []
    for item in items:
        if isinstance(item, str):
            parts.append(item)
            continue
        if isinstance(item, dict):
            if item.get("text"):
                parts.append(str(item.get("text")))
            elif item.get("content"):
                parts.append(str(item.get("content")))
    return "\n\n".join([p for p in parts if p])


def get_context_text(record: Dict[str, Any]) -> str:
    val = _first_value(record, ["context", "retrieved_context"])
    if val:
        return str(val)
    for key in ["retrieved_contexts", "contexts", "documents", "sources"]:
        items = record.get(key)
        if isinstance(items, list) and items:
            joined = _join_text_items(items)
            if joined:
                return joined
    return ""


def get_latency_ms(record: Dict[str, Any]) -> Optional[float]:
    for key in ["latency_ms", "latency"]:
        if key in record and record.get(key) is not None:
            try:
                return float(record.get(key))
            except Exception:
                return None
    metrics = record.get("metrics") or {}
    performance = record.get("performance") or {}
    timings = record.get("timings") or {}
    for obj in (metrics, performance, timings):
        if isinstance(obj, dict) and obj.get("latency_ms") is not None:
            try:
                return float(obj.get("latency_ms"))
            except Exception:
                return None
        if isinstance(obj, dict) and obj.get("total_ms") is not None:
            try:
                return float(obj.get("total_ms"))
            except Exception:
                return None
    return None


def get_token_usage(record: Dict[str, Any]) -> Dict[str, Any]:
    usage = record.get("token_usage") or record.get("usage") or {}
    if not usage:
        metrics = record.get("metrics") or {}
        usage = metrics.get("token_usage") or {}
    if isinstance(usage, dict):
        return usage
    return {}


def get_tool_calls(record: Dict[str, Any]) -> List[Dict[str, Any]]:
    calls = record.get("tool_calls") or record.get("tools") or []
    if isinstance(calls, list):
        return [c for c in calls if isinstance(c, dict)]
    return []


def get_agent_plan_text(record: Dict[str, Any]) -> str:
    val = _first_value(record, ["plan", "agent_plan", "plan_text"])
    if val:
        return str(val)
    steps = record.get("agent_steps")
    if isinstance(steps, list) and steps:
        actions = []
        for s in steps:
            if isinstance(s, dict) and s.get("action"):
                actions.append(str(s.get("action")))
        if actions:
            return "\n".join(actions)
    return get_output_text(record)

