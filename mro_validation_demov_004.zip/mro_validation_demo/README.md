# MRO GenAI & Agentic AI Validation Platform (Demo)

Fully runnable local demo built with Python + Gradio. The app simulates IVT and Risk Oversight workflows:
1) Project, 2) Tool Workbench (catalog + configuration), 3) Scenario Studio, 4) Run Tests,
5) Results & traces, 6) Report & evidence.

## How to run

```bash
pip install -r requirements.txt
python app.py
```

## Notes
- Local persistence uses SQLite at `runs/mro_demo.sqlite` by default.
- Override paths with env vars: `MRO_DB_PATH`, `MRO_DATASET_PATH`, `MRO_RUNS_DIR`, `MRO_REPORTS_DIR`, `MRO_FIXTURES_DIR`.
- Tool plugins live under `tools/<tool_id>/tool.py` and export `TOOL`.
- Dataset is a small JSONL file at `data/dataset.jsonl`.
- Scenario datasets are stored in SQLite alongside runs.

## Evidence Contract (MEC v0)
The platform uses a Minimum Evidence Contract (MEC) for deterministic testing and reporting.

- Evidence bundles live in `mro_validation_sdk/evidence.py` and serialize as `mec.v0`.
- Canonical `access_mode` values are `black_box`, `traced`, and `white_box`.
- Traced and white_box access require an `EvidenceTrace` payload.
- UI uses redacted evidence summaries for display safety.

## Scenario concepts
Scenario generation is a pre-evaluation step:
ScenarioCase -> Adapter builds EvidenceBundle -> Tools evaluate -> Results & evidence stored -> Reports generated.

Scenario generators:
- Do NOT call models under test.
- Do NOT create EvidenceBundle.
- ONLY generate test cases (ScenarioCase objects).

## Scenario Studio
Use **Scenario Studio** to create and curate project-scoped scenario datasets:
1) Paste seed examples.
2) Select a generator + configure parameters.
3) Preview, dedupe, and tag scenarios.
4) Curate and mark `approved_for_validation`.
5) Save as a dataset under the active project.

## How scenarios feed validation
In **Run Tests (Suite Runner)**, choose Dataset Source = "Scenario Datasets" to:
- Filter by approval, tags, and objectives.
- Select the first N cases.
- Execute tools on adapter-built evidence from each case input.

Results are stored with `project_id`, `dataset_id`, `case_id`, selected tool IDs, access_mode, and adapter_id.

## How to add a tool
Use the generator to scaffold a new tool and register metadata.

```bash
python scripts/create_tool.py --tool_id my_tool --name "My Tool" --description "Checks X" --module_group "Quality, Correctness & Effectiveness"
```

Then edit `tools/my_tool/tool.py`:
- Implement `run_on_evidence(...)`.
- Declare `required_evidence()` and `supported_access_modes()`.
- Keep tool logic pure (no DB writes, no API calls).

## How to add a generator
Scenario generators live under `generators/<generator_id>/generator.py` and export `GENERATOR`.

Scaffold a new generator:
```bash
python scripts/create_generator.py --id my_generator_v0 --name "My Generator" --description "Creates domain scenarios"
```

Run a generator against seed examples:
```bash
python -m core.generator_test_runner --generator_id basic_scenario_v0 --seed_file fixtures/seeds/business_examples_sample.json
```

## How to run fixture tests
Fixtures live under `fixtures/<access_mode>/`.

CLI:
```bash
python -m core.unit_test_runner --tool_id my_tool --fixture fixtures/traced/fixture_traced_001.json --project_id demo --cfg_preset active
```

UI:
- Open **Tool Workbench** -> **Fixture Unit Tests**, select access_mode + fixture, and run.

## How to add an adapter
Adapters live in `core/adapters/` and are the only place that touch model-owner integrations.

Steps:
1) Create a new adapter in `core/adapters/` implementing `BaseAdapter.build_evidence(...)`.
2) Register it in `core/adapters/__init__.py` by adding it to `discover_adapters()`.
3) Ensure `supported_access_modes()` returns only the canonical modes.
