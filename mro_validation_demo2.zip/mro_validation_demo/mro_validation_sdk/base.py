from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Literal, Tuple


CoverageStatus = Literal["available", "limited", "unavailable"]


@dataclass
class EvidenceItem:
    kind: str
    title: str
    payload: Dict[str, Any]


@dataclass
class ToolResult:
    tool_id: str
    pass_fail: str
    overall_score: float
    metrics: Dict[str, Any] = field(default_factory=dict)
    evidence: List[EvidenceItem] = field(default_factory=list)
    tool_version: str = ""


@dataclass
class ToolContext:
    project_id: str
    system_type: str
    access_mode: str
    api_base_url: Optional[str]
    db_path: str


# -----------------------------
# Tool Contract
# -----------------------------
class BaseTool:
    """Plugin contract for validation tools.

    Required:
      - tool_id / name / version / description (attributes)
      - run_one(record, config, ctx) -> ToolResult
      - default_config() -> dict

    Optional (v3 upgrade):
      - metadata() -> dict (owner/status/tags/limitations)
      - config_schema() -> dict (declarative UI schema for config)
      - coverage_status(system_type, access_mode) -> CoverageStatus
    """

    tool_id: str = "base"
    name: str = "Base Tool"
    version: str = "0.0"
    description: str = ""
    module_group: str = ""

    supported_system_types: List[str] = []
    supported_access_modes: List[str] = []

    def default_config(self) -> dict:
        return {}

    def metadata(self) -> Dict[str, Any]:
        """Governance + catalog metadata for Tool Catalog cards."""
        return {
            "owner": "TBD",
            "status": "Experimental",  # Draft/Experimental/Approved/Deprecated
            "tags": [],
            "limitations": "",
        }

    def config_schema(self) -> Dict[str, Any]:
        """Declarative schema for user-friendly config UI.

        Format:
        {
          "fields": [
            {"key": "threshold", "type": "number", "label": "Threshold", "min": 0, "max": 1, "step": 0.05},
            {"key": "enabled", "type": "bool", "label": "Enable"},
            {"key": "mode", "type": "select", "label": "Mode", "choices": ["light","strict"]},
            {"key": "prompt", "type": "text", "label": "Judge prompt", "lines": 4},
          ]
        }
        If empty, platform falls back to auto-deriving fields from the config dict.
        """
        return {"fields": []}

    def validate_config(self, cfg: Dict[str, Any]) -> Tuple[bool, str]:
        return True, "ok"

    def coverage_status(self, system_type: str, access_mode: str) -> CoverageStatus:
        # default permissive
        return "available"

    def coverage_notes(self, system_type: str, access_mode: str) -> str:
        """Optional human-readable note shown in Tool Catalog when coverage is limited/unavailable."""
        return ""

    def run_one(self, record: dict, config: dict, ctx: ToolContext) -> ToolResult:
        raise NotImplementedError
