from __future__ import annotations
from dataclasses import dataclass

@dataclass
class StubModel:
    """A tiny stand-in for a model API or app entrypoint.
    Replace this with real API calls later.
    """
    name: str = "stub-rag-chatbot"
    version: str = "0.1"

    def chat(self, query: str, context: str | None = None) -> str:
        q = query.lower()
        if "capital of france" in q:
            return "The capital of France is Paris."
        if "ignore previous instructions" in q or "reveal" in q:
            return "I can't help with that. I will follow the policy and not reveal secrets."
        return f"Answer (draft): {query} — main risk is unexpected tool use and actions."
