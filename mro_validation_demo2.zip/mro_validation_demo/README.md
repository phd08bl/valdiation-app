# MRO GenAI & Agentic AI Validation Platform (Demo)

Fully runnable local demo built with Python + Gradio. The app simulates IVT and Risk Oversight workflows:
1) Project selection, 2) Tool catalog + coverage, 3) Tool configuration + presets, 4) Suite runs,
5) Results & traces, 6) Report & evidence.

## How to run

```bash
pip install -r requirements.txt
python app.py
```

## Notes
- Local persistence uses SQLite at `runs/mro_demo.sqlite` by default.
- Override paths with env vars: `MRO_DB_PATH`, `MRO_DATASET_PATH`, `MRO_RUNS_DIR`, `MRO_REPORTS_DIR`.
- Tool plugins live under `tools/<tool_id>/tool.py` and export `TOOL`.
- Dataset is a small JSONL file at `data/dataset.jsonl`.
