"""Tool discovery.

Demo convention:
  - Each tool lives under: tools/<tool_id>/tool.py
  - Each tool module exports: TOOL (subclass or instance of BaseTool)

The platform will import each tool module and register it by TOOL.tool_id.
"""

from __future__ import annotations

import importlib
import pkgutil
from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class DiscoveryResult:
    tools: Dict[str, object]
    errors: List[str]


def discover_tools(package: str = "mro_validation_demo.tools") -> DiscoveryResult:
    """Discover TOOL exports under the given tools package."""
    tools: Dict[str, object] = {}
    errors: List[str] = []

    try:
        pkg = importlib.import_module(package)
    except Exception as e:  # pragma: no cover
        if package == "tools":
            try:
                pkg = importlib.import_module("mro_validation_demo.tools")
            except Exception as e2:  # pragma: no cover
                return DiscoveryResult(tools={}, errors=[f"Failed to import tools package '{package}': {e}", f"Fallback import failed: {e2}"])
        else:
            return DiscoveryResult(tools={}, errors=[f"Failed to import tools package '{package}': {e}"])

    # Iterate subpackages under tools/*
    for modinfo in pkgutil.iter_modules(pkg.__path__, pkg.__name__ + "."):
        # We only want modules named '<tool_pkg>.tool'
        if not modinfo.ispkg:
            continue
        if modinfo.name.endswith(".__pycache__"):
            continue
        tool_module = modinfo.name + ".tool"
        try:
            m = importlib.import_module(tool_module)
            if not hasattr(m, "TOOL"):
                errors.append(f"{tool_module}: missing TOOL export")
                continue
            tool_obj = getattr(m, "TOOL")

            # TOOL can be a class or instance. Normalize to instance.
            if isinstance(tool_obj, type):
                tool_obj = tool_obj()

            tool_id = getattr(tool_obj, "tool_id", None)
            if not tool_id:
                errors.append(f"{tool_module}: TOOL missing tool_id")
                continue
            tools[str(tool_id)] = tool_obj
        except Exception as e:
            errors.append(f"{tool_module}: import failed ({type(e).__name__}: {e})")

    return DiscoveryResult(tools=tools, errors=errors)
