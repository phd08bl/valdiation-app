from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional


from . import config as app_config

DEFAULT_DB = app_config.db_path()


def _connect(db_path: str = DEFAULT_DB) -> sqlite3.Connection:
    dir_name = os.path.dirname(db_path)
    if dir_name:
        os.makedirs(dir_name, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


SCHEMA_SQL: List[str] = [
    """
    CREATE TABLE IF NOT EXISTS projects (
        project_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        created_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS runs (
        run_id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        status TEXT NOT NULL,
        pass_rate REAL NOT NULL,
        total INTEGER NOT NULL,
        run_metadata_json TEXT,
        FOREIGN KEY(project_id) REFERENCES projects(project_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS traces (
        trace_id TEXT PRIMARY KEY,
        run_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        input_preview TEXT,
        overall_score REAL NOT NULL,
        pass_fail TEXT NOT NULL,
        trace_json TEXT NOT NULL,
        FOREIGN KEY(run_id) REFERENCES runs(run_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS evaluations (
        evaluation_id INTEGER PRIMARY KEY AUTOINCREMENT,
        trace_id TEXT NOT NULL,
        tool_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        evaluation_json TEXT NOT NULL,
        FOREIGN KEY(trace_id) REFERENCES traces(trace_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS tool_configs (
        project_id TEXT NOT NULL,
        tool_id TEXT NOT NULL,
        config_json TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY(project_id, tool_id),
        FOREIGN KEY(project_id) REFERENCES projects(project_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS tool_config_presets (
        project_id TEXT NOT NULL,
        tool_id TEXT NOT NULL,
        preset_name TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 0,
        config_json TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (project_id, tool_id, preset_name),
        FOREIGN KEY(project_id) REFERENCES projects(project_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS tool_test_cases (
        project_id TEXT NOT NULL,
        tool_id TEXT NOT NULL,
        case_id TEXT NOT NULL,
        case_name TEXT,
        case_json TEXT NOT NULL,
        expected_json TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (project_id, tool_id, case_id),
        FOREIGN KEY(project_id) REFERENCES projects(project_id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_runs_project_id ON runs(project_id)",
    "CREATE INDEX IF NOT EXISTS idx_traces_run_id ON traces(run_id)",
    "CREATE INDEX IF NOT EXISTS idx_evaluations_trace_id ON evaluations(trace_id)",
    "CREATE INDEX IF NOT EXISTS idx_tool_presets_active ON tool_config_presets(project_id, tool_id, is_active)",
]


def init_db(db_path: str = DEFAULT_DB) -> None:
    with _connect(db_path) as conn:
        for stmt in SCHEMA_SQL:
            conn.execute(stmt)
        conn.commit()


# -----------------------------
# Projects
# -----------------------------
def insert_project(project_id: str, name: str, description: str = "", db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO projects(project_id,name,description,created_at) VALUES (?,?,?,?)",
            (project_id, name, description, datetime.utcnow().isoformat()),
        )
        conn.commit()


def list_projects(db_path: str = DEFAULT_DB) -> List[Dict[str, Any]]:
    init_db(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute("SELECT * FROM projects ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]


def delete_project(project_id: str, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        # Delete runs and related traces/evaluations.
        run_rows = conn.execute("SELECT run_id FROM runs WHERE project_id=?", (project_id,)).fetchall()
        run_ids = [r["run_id"] for r in run_rows]
        for run_id in run_ids:
            trace_rows = conn.execute("SELECT trace_id FROM traces WHERE run_id=?", (run_id,)).fetchall()
            trace_ids = [tr["trace_id"] for tr in trace_rows]
            if trace_ids:
                conn.executemany("DELETE FROM evaluations WHERE trace_id=?", [(tid,) for tid in trace_ids])
                conn.executemany("DELETE FROM traces WHERE trace_id=?", [(tid,) for tid in trace_ids])
            conn.execute("DELETE FROM runs WHERE run_id=?", (run_id,))

        # Delete project-scoped tool data.
        conn.execute("DELETE FROM tool_configs WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM tool_config_presets WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM tool_test_cases WHERE project_id=?", (project_id,))

        # Delete the project record.
        conn.execute("DELETE FROM projects WHERE project_id=?", (project_id,))
        conn.commit()


def delete_project(project_id: str, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        # Delete runs and related traces/evaluations.
        run_rows = conn.execute("SELECT run_id FROM runs WHERE project_id=?", (project_id,)).fetchall()
        run_ids = [r["run_id"] for r in run_rows]
        for run_id in run_ids:
            trace_rows = conn.execute("SELECT trace_id FROM traces WHERE run_id=?", (run_id,)).fetchall()
            trace_ids = [tr["trace_id"] for tr in trace_rows]
            if trace_ids:
                conn.executemany("DELETE FROM evaluations WHERE trace_id=?", [(tid,) for tid in trace_ids])
                conn.executemany("DELETE FROM traces WHERE trace_id=?", [(tid,) for tid in trace_ids])
            conn.execute("DELETE FROM runs WHERE run_id=?", (run_id,))

        # Delete project-scoped tool data.
        conn.execute("DELETE FROM tool_configs WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM tool_config_presets WHERE project_id=?", (project_id,))
        conn.execute("DELETE FROM tool_test_cases WHERE project_id=?", (project_id,))

        # Delete the project record.
        conn.execute("DELETE FROM projects WHERE project_id=?", (project_id,))
        conn.commit()


# -----------------------------
# Runs
# -----------------------------
def upsert_run(
    project_id: str,
    run_id: str,
    status: str,
    pass_rate: float,
    total: int,
    run_metadata: Optional[Dict[str, Any]],
    db_path: str = DEFAULT_DB,
) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO runs(run_id, project_id, created_at, status, pass_rate, total, run_metadata_json)
            VALUES (?,?,?,?,?,?,?)
            ON CONFLICT(run_id) DO UPDATE SET
              status=excluded.status,
              pass_rate=excluded.pass_rate,
              total=excluded.total,
              run_metadata_json=excluded.run_metadata_json
            """,
            (
                run_id,
                project_id,
                datetime.utcnow().isoformat(),
                status,
                float(pass_rate),
                int(total),
                json.dumps(run_metadata or {}),
            ),
        )
        conn.commit()


def list_runs(project_id: str, db_path: str = DEFAULT_DB) -> List[Dict[str, Any]]:
    init_db(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT * FROM runs WHERE project_id=? ORDER BY created_at DESC",
            (project_id,),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["run_metadata"] = json.loads(d.get("run_metadata_json") or "{}")
            out.append(d)
        return out


def get_run(run_id: str, db_path: str = DEFAULT_DB) -> Dict[str, Any]:
    init_db(db_path)
    with _connect(db_path) as conn:
        r = conn.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
        if not r:
            return {}
        d = dict(r)
        d["run_metadata"] = json.loads(d.get("run_metadata_json") or "{}")
        return d


def delete_run(run_id: str, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        # cascade manually
        trace_rows = conn.execute("SELECT trace_id FROM traces WHERE run_id=?", (run_id,)).fetchall()
        trace_ids = [tr["trace_id"] for tr in trace_rows]
        if trace_ids:
            conn.executemany("DELETE FROM evaluations WHERE trace_id=?", [(tid,) for tid in trace_ids])
            conn.executemany("DELETE FROM traces WHERE trace_id=?", [(tid,) for tid in trace_ids])
        conn.execute("DELETE FROM runs WHERE run_id=?", (run_id,))
        conn.commit()


# -----------------------------
# Traces + Evaluations
# -----------------------------
def upsert_trace(
    run_id: str,
    trace_id: str,
    input_preview: str,
    overall_score: float,
    pass_fail: str,
    trace_json: Dict[str, Any],
    db_path: str = DEFAULT_DB,
) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO traces(trace_id, run_id, created_at, input_preview, overall_score, pass_fail, trace_json)
            VALUES (?,?,?,?,?,?,?)
            ON CONFLICT(trace_id) DO UPDATE SET
              input_preview=excluded.input_preview,
              overall_score=excluded.overall_score,
              pass_fail=excluded.pass_fail,
              trace_json=excluded.trace_json
            """,
            (
                trace_id,
                run_id,
                datetime.utcnow().isoformat(),
                input_preview,
                float(overall_score),
                pass_fail,
                json.dumps(trace_json),
            ),
        )
        conn.commit()


def add_evaluation(trace_id: str, tool_id: str, evaluation_json: Dict[str, Any], db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            "INSERT INTO evaluations(trace_id, tool_id, created_at, evaluation_json) VALUES (?,?,?,?)",
            (trace_id, tool_id, datetime.utcnow().isoformat(), json.dumps(evaluation_json)),
        )
        conn.commit()


def list_traces_for_run(run_id: str, db_path: str = DEFAULT_DB) -> List[Dict[str, Any]]:
    init_db(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT trace_id, input_preview, overall_score, pass_fail, created_at FROM traces WHERE run_id=? ORDER BY created_at ASC",
            (run_id,),
        ).fetchall()
        return [dict(r) for r in rows]


def get_trace(trace_id: str, db_path: str = DEFAULT_DB) -> Dict[str, Any]:
    init_db(db_path)
    with _connect(db_path) as conn:
        tr = conn.execute("SELECT * FROM traces WHERE trace_id=?", (trace_id,)).fetchone()
        if not tr:
            return {}
        d = dict(tr)
        d["trace"] = json.loads(d.get("trace_json") or "{}")
        evals = conn.execute("SELECT tool_id, evaluation_json, created_at FROM evaluations WHERE trace_id=? ORDER BY created_at ASC", (trace_id,)).fetchall()
        d["evaluations"] = [{"tool_id": e["tool_id"], "evaluation": json.loads(e["evaluation_json"]), "created_at": e["created_at"]} for e in evals]
        return d


def delete_traces(trace_ids: List[str], db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.executemany("DELETE FROM evaluations WHERE trace_id=?", [(tid,) for tid in trace_ids])
        conn.executemany("DELETE FROM traces WHERE trace_id=?", [(tid,) for tid in trace_ids])
        conn.commit()


# -----------------------------
# Tool configs (legacy single)
# -----------------------------
def upsert_tool_config(project_id: str, tool_id: str, config: Dict[str, Any], db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO tool_configs(project_id, tool_id, config_json, updated_at)
            VALUES (?,?,?,?)
            ON CONFLICT(project_id, tool_id) DO UPDATE SET
              config_json=excluded.config_json,
              updated_at=excluded.updated_at
            """,
            (project_id, tool_id, json.dumps(config), datetime.utcnow().isoformat()),
        )
        conn.commit()


def get_tool_config(project_id: str, tool_id: str, db_path: str = DEFAULT_DB) -> Dict[str, Any]:
    init_db(db_path)
    with _connect(db_path) as conn:
        r = conn.execute("SELECT config_json FROM tool_configs WHERE project_id=? AND tool_id=?", (project_id, tool_id)).fetchone()
        if not r:
            return {}
        return json.loads(r["config_json"])


# -----------------------------
# Tool config presets (versioned)
# -----------------------------
def upsert_tool_preset(project_id: str, tool_id: str, preset_name: str, config: Dict[str, Any], set_active: bool, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO tool_config_presets (project_id, tool_id, preset_name, is_active, config_json, updated_at)
            VALUES (?,?,?,?,?,?)
            ON CONFLICT(project_id, tool_id, preset_name) DO UPDATE SET
              is_active=excluded.is_active,
              config_json=excluded.config_json,
              updated_at=excluded.updated_at
            """,
            (project_id, tool_id, preset_name, 1 if set_active else 0, json.dumps(config), datetime.utcnow().isoformat()),
        )
        if set_active:
            conn.execute(
                """
                UPDATE tool_config_presets SET is_active=0
                WHERE project_id=? AND tool_id=? AND preset_name<>?
                """,
                (project_id, tool_id, preset_name),
            )
        conn.commit()


def list_tool_presets(project_id: str, tool_id: str, db_path: str = DEFAULT_DB) -> List[Dict[str, Any]]:
    init_db(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT preset_name, is_active, updated_at
            FROM tool_config_presets
            WHERE project_id=? AND tool_id=?
            ORDER BY is_active DESC, updated_at DESC
            """,
            (project_id, tool_id),
        ).fetchall()
        return [{"preset_name": r["preset_name"], "is_active": bool(r["is_active"]), "updated_at": r["updated_at"]} for r in rows]


def get_tool_preset_config(project_id: str, tool_id: str, preset_name: str, db_path: str = DEFAULT_DB) -> Dict[str, Any]:
    init_db(db_path)
    with _connect(db_path) as conn:
        r = conn.execute(
            "SELECT config_json FROM tool_config_presets WHERE project_id=? AND tool_id=? AND preset_name=?",
            (project_id, tool_id, preset_name),
        ).fetchone()
        if not r:
            return {}
        return json.loads(r["config_json"])


def get_active_tool_preset_config(project_id: str, tool_id: str, db_path: str = DEFAULT_DB) -> Dict[str, Any]:
    init_db(db_path)
    with _connect(db_path) as conn:
        r = conn.execute(
            """
            SELECT config_json FROM tool_config_presets
            WHERE project_id=? AND tool_id=? AND is_active=1
            ORDER BY updated_at DESC LIMIT 1
            """,
            (project_id, tool_id),
        ).fetchone()
        if not r:
            return {}
        return json.loads(r["config_json"])


def delete_tool_preset(project_id: str, tool_id: str, preset_name: str, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            "DELETE FROM tool_config_presets WHERE project_id=? AND tool_id=? AND preset_name=?",
            (project_id, tool_id, preset_name),
        )
        conn.commit()


# -----------------------------
# Tool unit test cases (per project)
# -----------------------------
def upsert_tool_test_case(
    project_id: str,
    tool_id: str,
    case_id: str,
    case_name: str,
    case: Dict[str, Any],
    expected: Dict[str, Any],
    db_path: str = DEFAULT_DB,
) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO tool_test_cases(project_id, tool_id, case_id, case_name, case_json, expected_json, updated_at)
            VALUES (?,?,?,?,?,?,?)
            ON CONFLICT(project_id, tool_id, case_id) DO UPDATE SET
              case_name=excluded.case_name,
              case_json=excluded.case_json,
              expected_json=excluded.expected_json,
              updated_at=excluded.updated_at
            """,
            (
                project_id,
                tool_id,
                case_id,
                case_name,
                json.dumps(case),
                json.dumps(expected),
                datetime.utcnow().isoformat(),
            ),
        )
        conn.commit()


def list_tool_test_cases(project_id: str, tool_id: str, db_path: str = DEFAULT_DB) -> List[Dict[str, Any]]:
    init_db(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT case_id, case_name, case_json, expected_json, updated_at
            FROM tool_test_cases
            WHERE project_id=? AND tool_id=?
            ORDER BY updated_at DESC
            """,
            (project_id, tool_id),
        ).fetchall()
        out = []
        for r in rows:
            out.append(
                {
                    "case_id": r["case_id"],
                    "case_name": r["case_name"] or "",
                    "case": json.loads(r["case_json"]),
                    "expected": json.loads(r["expected_json"]),
                    "updated_at": r["updated_at"],
                }
            )
        return out


def delete_tool_test_case(project_id: str, tool_id: str, case_id: str, db_path: str = DEFAULT_DB) -> None:
    init_db(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            "DELETE FROM tool_test_cases WHERE project_id=? AND tool_id=? AND case_id=?",
            (project_id, tool_id, case_id),
        )
        conn.commit()
