from __future__ import annotations
import hashlib
import re
from typing import Any, Dict, List
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext
from mro_validation_sdk.record_utils import get_agent_plan_text, get_tool_calls


class AgentPlanConsistencyTool(BaseTool):
    tool_id = "agent_plan_consistency"
    name = "Agent Plan Consistency"
    version = "0.1"
    description = "Checks whether the agent plan includes ordered steps and tool references."
    module_group = "Agent Planning, Control & Tool-Use"

    def metadata(self) -> Dict[str, Any]:
        return {
            "owner": "Agentic Ops",
            "status": "Experimental",
            "tags": ["agent", "planning", "control"],
            "limitations": "Pattern-based step detection; not a full plan validator.",
        }

    def coverage_status(self, system_type: str, access_mode: str) -> str:
        if system_type not in ("Agentic AI", "Multi-Agent System", "Low/No-code Agent"):
            return "unavailable"
        if access_mode == "blackbox_api":
            return "limited"
        return "available"

    def coverage_notes(self, system_type: str, access_mode: str) -> str:
        if system_type not in ("Agentic AI", "Multi-Agent System", "Low/No-code Agent"):
            return "Only applicable to agentic systems."
        if access_mode == "blackbox_api":
            return "Limited to output-only plan parsing."
        return ""

    def default_config(self) -> Dict[str, Any]:
        return {"min_steps": 2, "require_tool_mentions": False}

    def config_schema(self) -> Dict[str, Any]:
        return {
            "fields": [
                {"key": "min_steps", "type": "number", "label": "Minimum steps", "min": 1, "max": 10, "step": 1},
                {"key": "require_tool_mentions", "type": "bool", "label": "Require tool mentions"},
            ]
        }

    def _score_from_id(self, record_id: str, salt: str) -> float:
        digest = hashlib.md5(f"{record_id}:{salt}".encode("utf-8")).hexdigest()
        bucket = int(digest[:6], 16) % 1000
        return 0.6 + (bucket / 1000.0) * 0.35

    def _count_steps(self, text: str) -> int:
        steps = re.findall(r"(^|\n)\s*\d+[\).\s]", text or "")
        if steps:
            return len(steps)
        return len(re.findall(r"\b(step|first|second|third)\b", (text or "").lower()))

    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        plan_text = get_agent_plan_text(record)
        steps = self._count_steps(plan_text)
        require_tools = bool(config.get("require_tool_mentions", False))
        calls = get_tool_calls(record)
        tool_mentions = bool(calls) or "tool" in plan_text.lower() or "api" in plan_text.lower()
        min_steps = int(config.get("min_steps", 2))
        fail = steps < min_steps or (require_tools and not tool_mentions)
        score = 0.35 if fail else self._score_from_id(record.get("id", "0"), self.tool_id)

        payload = {"steps_detected": steps, "tool_mentions": tool_mentions}
        return ToolResult(
            tool_id=self.tool_id,
            tool_version=self.version,
            overall_score=score,
            pass_fail="FAIL" if fail else "PASS",
            metrics=payload,
            evidence=[EvidenceItem(kind="finding", title="Plan consistency", payload=payload)],
        )


TOOL: BaseTool = AgentPlanConsistencyTool()
