from __future__ import annotations
from typing import Any, Dict, List
from mro_validation_sdk import BaseTool, ToolResult, EvidenceItem, ToolContext

class _Tool:
    tool_id = "multi_agent_conflict_stub"
    name = "multi_agent_conflict_stub"
    version = "0.1"
    description = "Multi-agent conflict proxy (stub)."
    supported_system_types: List[str] = ["ALL"]
    supported_access_modes: List[str] = ["ALL"]
    def coverage_status(self, system_type: str, access_mode: str) -> str:
        # keep some as limited for blackbox in demo
        if self.tool_id in ("tool_use_stub","loop_detector_stub","multi_agent_conflict_stub","rag_groundedness_stub") and access_mode == "blackbox_api":
            return "limited"
        return "available"
    def default_config(self) -> Dict[str, Any]:
        return {"threshold": 0.5}
    def run_one(self, record: Dict[str, Any], config: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        payload = {"note":"stub tool", "coverage": self.coverage_status(ctx.system_type, ctx.access_mode)}
        return ToolResult(tool_id=self.tool_id, tool_version=self.version, overall_score=1.0, pass_fail="PASS", metrics=payload, evidence=[EvidenceItem(kind="stub", title=self.description, payload=payload)])

TOOL: BaseTool = _Tool()
